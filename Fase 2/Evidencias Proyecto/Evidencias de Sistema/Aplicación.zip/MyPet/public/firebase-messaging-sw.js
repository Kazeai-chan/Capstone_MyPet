
// public/firebase-messaging-sw.js

// Importa e inicializa el SDK de Firebase
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

// Esta configuración es pública y segura de exponer
const firebaseConfig = {
  apiKey: "AIzaSyC-IQfYVGquGeLgD46equ2MO58Eayeba-A",
  authDomain: "instant-vent-423002-f1.firebaseapp.com",
  projectId: "instant-vent-423002-f1",
  storageBucket: "instant-vent-423002-f1.appspot.com",
  messagingSenderId: "512313065132",
  appId: "1:512313065132:web:21cd578443f1cf5a046909"
};

firebase.initializeApp(firebaseConfig);

// Obtiene una instancia de Firebase Messaging
const messaging = firebase.messaging();

console.log('Service Worker: Firebase inicializado. Listo para mensajes en segundo plano.');

// El manejador onBackgroundMessage se omite intencionadamente.
// Si el payload del mensaje push de tu servidor incluye un objeto "notification",
// el SDK de Firebase mostrará automáticamente una notificación del sistema.
// Esto previene el problema de la notificación duplicada.

// Opcional: Añade un listener 'notificationclick' para manejar los clics en la notificación
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  // Esto abre la URL raíz de la aplicación cuando se hace clic en la notificación.
  event.waitUntil(
    clients.openWindow('/')
  );
});
