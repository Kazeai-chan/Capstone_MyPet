
// Import the Firebase SDK for compatibility
importScripts("https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js");

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-IQfYVGquGeLgD46equ2MO58Eayeba-A",
  authDomain: "instant-vent-423002-f1.firebaseapp.com",
  projectId: "instant-vent-423002-f1",
  storageBucket: "instant-vent-423002-f1.appspot.com",
  messagingSenderId: "512313065132",
  appId: "1:512313065132:web:21cd578443f1cf5a046909"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Retrieve an instance of Firebase Messaging so that it can handle background messages.
const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage((payload) => {
  console.log(
    "[firebase-messaging-sw.js] Received background message ",
    payload
  );
  
  // Customize the notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/logo192.png' // Asegúrate de que este ícono exista en tu carpeta public
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
