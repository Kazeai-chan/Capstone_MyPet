import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as cheerio from 'cheerio';
import fetch from 'node-fetch';
import * as cors from 'cors';


admin.initializeApp();

const corsHandler = cors({origin: true});

const BASE_URL = 'https://www.publimetro.cl';
const FEED_URL = `${BASE_URL}/tags/mascotas/`;
const NEWS_SOURCE = 'Publimetro Chile';

interface NewsItem {
  title: string;
  link: string;
  imageUrl: string;
  source: string;
  pubDate: string;
  updatedAt?: admin.firestore.FieldValue;
}

function normalizeLink(link: string): string {
  let normalized = link.trim();
  if (normalized.endsWith('/')) normalized = normalized.slice(0, -1);
  normalized = normalized.replace(/^https?:\/\/(www\.)?/, 'https://');
  const url = new URL(normalized);
  url.search = '';
  return url.toString();
}

export const getNews = functions.https.onRequest((request, response) => {
  corsHandler(request, response, async () => {
    functions.logger.info('Request received for getNews function');

    try {
      const firestore = admin.firestore();
      const newsRef = firestore.collection('news');
      const controlRef = firestore.collection('scrape_log').doc('last_run');

      const controlDoc = await controlRef.get();
      const now = new Date();
      const oneDay = 24 * 60 * 60 * 1000;

      const lastRun = controlDoc.exists ?
        controlDoc.data()?.updatedAt?.toDate() :
        null;

      const shouldScrape =
        !lastRun || now.getTime() - lastRun.getTime() > oneDay;

      functions.logger.log(
          `Last run: ${lastRun}, Should scrape: ${shouldScrape}`,
      );

      if (shouldScrape) {
        functions.logger.info('Scraping new data...');
        const fetchResponse = await fetch(FEED_URL);

        if (!fetchResponse.ok) {
          throw new Error(`Fetch failed: ${fetchResponse.statusText}`);
        }

        const html = await fetchResponse.text();
        const $ = cheerio.load(html);

        const uniqueNewsItems: Omit<NewsItem, 'updatedAt'>[] = [];
        const seenLinks = new Set<string>();

        $('article').each((_, el) => {
          const title = $(el).find('h2').text().trim();
          const rawLink = $(el).find('a').attr('href');

          if (!title || !rawLink) return;

          let normalizedLink = rawLink.startsWith('http') ?
            rawLink :
            `${BASE_URL}${rawLink}`;
          normalizedLink = normalizeLink(normalizedLink);

          if (
            normalizedLink.includes('/tags/') ||
            normalizedLink.includes('/category/') ||
            normalizedLink === BASE_URL
          ) {
            functions.logger.debug(`Skipping invalid link: ${normalizedLink}`);
            return;
          }

          if (seenLinks.has(normalizedLink)) return;
          seenLinks.add(normalizedLink);

          const rawImage = $(el).find('img').attr('src');
          if (!rawImage) return;

          const imageUrl = rawImage.startsWith('http') ?
            rawImage :
            `${BASE_URL}${rawImage}`;

          const date =
            $(el).find('time').attr('datetime') || new Date().toISOString();

          uniqueNewsItems.push({
            title,
            link: normalizedLink,
            imageUrl,
            source: NEWS_SOURCE,
            pubDate: date,
          });
        });


        functions.logger.info(
            `Found ${uniqueNewsItems.length} unique items to process.`,
        );

        const batch = firestore.batch();
        let itemsAdded = 0;

        for (const item of uniqueNewsItems) {
          const docId = Buffer.from(item.link)
              .toString('base64')
              .replace(/\//g, '_');

          const docRef = newsRef.doc(docId);
          const existingDoc = await docRef.get();

          if (!existingDoc.exists) {
            batch.set(
                docRef,
                {
                  ...item,
                  updatedAt: admin.firestore.FieldValue.serverTimestamp(),
                },
                {merge: false},
            );
            itemsAdded++;
          }
        }

        if (itemsAdded > 0) {
          await batch.commit();
          functions.logger.info(`Added ${itemsAdded} new items to Firestore.`);
        } else {
          functions.logger.info('No new items to add.');
        }

        await controlRef.set({
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });
        functions.logger.info('Scrape timestamp updated.');
      }

      const allNewsSnapshot = await newsRef.orderBy('pubDate', 'desc').get();
      const allNews = allNewsSnapshot.docs.map((doc) => doc.data());

      functions.logger.info(`Returning ${allNews.length} news items.`);
      response.status(200).json(allNews);
    } catch (error) {
      functions.logger.error('Critical error in getNews:', error);
      const err = error as Error;
      response.status(500).send({
        error: 'An internal server error occurred.',
        message: err.message,
      });
    }
  });
});

export const googleMapsProxy = functions.https.onRequest((request, response) => {
  corsHandler(request, response, async () => {
    functions.logger.info('Request to googleMapsProxy', {
      query: request.query,
      method: request.method,
    });

    const {input, latlng, placeid} = request.query;

    if (typeof input !== 'string' && typeof latlng !== 'string' && typeof placeid !== 'string') {
      response.status(400).send('Bad Request: missing \'input\', \'latlng\', or \'placeid\' in query parameters');
      return;
    }

    const apiKey = functions.config().maps.key;
    if (!apiKey) {
      functions.logger.error('Google Maps API key is not configured.');
      response.status(500).send('Internal Server Error: API key not set.');
      return;
    }

    const queryParams = new URLSearchParams();

    // Append all original query params, except for the key the client might have sent.
    for (const key in request.query) {
      if (key !== 'key') {
        const value = request.query[key];
        if (typeof value === 'string') {
          queryParams.set(key, value);
        }
      }
    }
    queryParams.set('key', apiKey);

    let googleApiUrl: string;
    if (input) {
      googleApiUrl = 'https://maps.googleapis.com/maps/api/place/autocomplete/json';
    } else if (latlng) {
      googleApiUrl = 'https://maps.googleapis.com/maps/api/geocode/json';
    } else if (placeid) {
      googleApiUrl = 'https://maps.googleapis.com/maps/api/place/details/json';
    } else {
      response.status(400).send('Bad Request: Invalid parameters.');
      return;
    }

    const url = `${googleApiUrl}?${queryParams.toString()}`;

    try {
      const fetchResponse = await fetch(url);
      const data = await fetchResponse.json();
      response.status(fetchResponse.status).json(data);
    } catch (error) {
      functions.logger.error('Error calling Google Maps API:', error);
      const err = error as Error;
      response.status(500).send({
        error: 'Failed to fetch data from Google Maps API.',
        message: err.message,
      });
    }
  });
});
