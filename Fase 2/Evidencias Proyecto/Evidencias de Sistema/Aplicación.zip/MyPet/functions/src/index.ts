
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as cheerio from 'cheerio';
import fetch from 'node-fetch';
import cors from 'cors';
import {HumanMessage} from '@langchain/core/messages';
import * as vision from '@google-cloud/vision';
import sharp from 'sharp';
import {URLSearchParams} from 'url';
import {ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings} from '@langchain/google-genai';
import {getFirestore} from 'firebase-admin/firestore';
import FormData from 'form-data';


// import crypto from 'crypto';


admin.initializeApp();

const corsHandler = cors({origin: true});

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
// const AQARA_CLIENT_ID = functions.config().aqara ? functions.config().aqara.client_id : process.env.AQARA_CLIENT_ID;
// const AQARA_CLIENT_SECRET = functions.config().aqara ? functions.config().aqara.client_secret : process.env.AQARA_CLIENT_SECRET;
const fechaActual = new Date();

// --- START: Interfaces for Type Safety ---
interface ILabelAnnotation {
  description?: string | null;
  score?: number | null;
}

interface PlacePhoto {
  height: number;
  html_attributions: string[];
  photo_reference: string;
  width: number;
}

interface Place {
  photos?: PlacePhoto[];
  place_id: string;
  name: string;
  vicinity: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  rating?: number;
  user_ratings_total?: number;
  types?: string[];
  opening_hours?: {
    open_now: boolean;
  };
}

interface PlacesResponse {
  results: Place[];
  status: string;
}

interface NewsItem {
  title: string;
  link: string;
  imageUrl: string;
  source: string;
  pubDate: string;
  updatedAt?: admin.firestore.FieldValue;
}

interface PetData {
  nombre: string;
  animal: string;
  nacimiento: Date;
  tamaño: string;
}

interface ScraperConfig {
  sourceName: string;
  feedUrl: string;
  baseUrl: string;
  selectors: {
    article: string;
    title: string;
    link: string;
    image: string;
    imageAttr?: string;
    date: string;
    dateAttr?: string;
  };
}

interface PetMemory {
  text: string;
  embedding: number[];
  timestamp: admin.firestore.FieldValue;
  from: 'user' | 'pet';
}

// Define interfaces for type safety
interface VirtualPet {
  nombre: string;
  animal: string;
  personalidad: string;
}

interface ChatMessage {
  from: 'user' | 'pet';
  text: string;
}


// Describe los campos relevantes de un reporte de mascota en Firestore.
interface ReportData {
    id?: string;
    foto: string;
    embedding?: number[];
    tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
    animal: string;
}

// --- INICIO DE CÓDIGO A AÑADIR ---

function parseDateString(dateString: string, sourceName: string): string {
  try {
    if (sourceName === '24 Horas') {
      const clean = dateString
          .toLowerCase()
          .replace(/[.,]/g, '') // elimina puntos y comas
          .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quita tildes
          .trim();

      // ejemplo posible: "viernes 18 de octubre de 2025"
      const match = clean.match(/(\d{1,2})\s+de\s+([a-z]+)\s+de\s+(\d{4})/);
      if (!match) return new Date().toISOString();

      const day = match[1];
      const monthName = match[2];
      const year = match[3];

      const monthMap: {[key: string]: string} = {
        'enero': '01', 'febrero': '02', 'marzo': '03', 'abril': '04', 'mayo': '05', 'junio': '06',
        'julio': '07', 'agosto': '08', 'septiembre': '09', 'setiembre': '09',
        'octubre': '10', 'noviembre': '11', 'diciembre': '12', 'oct': '10', 'nov': '11', 'dic': '12',
      };

      const month = monthMap[monthName];
      if (!month) return new Date().toISOString();

      const parsedDate = new Date(`${year}-${month}-${day}T00:00:00-03:00`);
      if (isNaN(parsedDate.getTime())) return new Date().toISOString();
      return parsedDate.toISOString();
    }

    // Default para otros medios
    const dateObject = new Date(dateString);
    if (isNaN(dateObject.getTime())) return new Date().toISOString();
    return dateObject.toISOString();
  } catch (error) {
    functions.logger.warn(`Error parsing date for ${sourceName}:`, error);
    return new Date().toISOString();
  }
}


const SCRAPER_CONFIGS: ScraperConfig[] = [
  {
    sourceName: 'Publimetro Chile',
    feedUrl: 'https://www.publimetro.cl/tags/mascotas/',
    baseUrl: 'https://www.publimetro.cl',
    selectors: {
      article: 'article',
      title: 'h2',
      link: 'h2 a',
      image: 'img',
      imageAttr: 'src',
      date: 'time',
      dateAttr: 'datetime',
    },
  },
  {
    sourceName: '24 Horas',
    feedUrl: 'https://www.24horas.cl/tendencias/mascotas',
    baseUrl: 'https://www.24horas.cl',
    selectors: {
      article: 'article.col',
      title: 'h3.tit',
      link: 'a',
      image: 'img.lazy',
      imageAttr: 'data-src',
      date: 'p.fecha',
      dateAttr: '',
    },
  },
];

function normalizeLink(link: string): string {
  let normalized = link.trim();
  normalized = normalized.replace(/^https?:\/\/(www\.)?/, 'https://');
  const url = new URL(normalized);
  url.search = '';
  let urlString = url.toString();
  if (urlString.endsWith('/')) {
    urlString = urlString.slice(0, -1);
  }
  return urlString;
}

async function scrapeAndStoreNews() {
  functions.logger.info('Starting simple news scraping process...');
  const firestore = admin.firestore();
  const newsRef = firestore.collection('news');
  const allUniqueNewsItems: Omit<NewsItem, 'updatedAt'>[] = [];
  const seenLinks = new Set<string>();

  for (const config of SCRAPER_CONFIGS) {
    functions.logger.info(`Scraping source: ${config.sourceName}`);
    try {
      const fetchResponse = await fetch(config.feedUrl);
      if (!fetchResponse.ok) {
        throw new Error(`Fetch failed for ${config.sourceName}: ${fetchResponse.statusText}`);
      }
      const html = await fetchResponse.text();
      functions.logger.info(`Successfully fetched from ${config.feedUrl}`);

      const $ = cheerio.load(html);
      $(config.selectors.article).each((_, el) => {
        const title = $(el).find(config.selectors.title).text().trim();
        const rawLink = $(el).find(config.selectors.link).attr('href');
        if (!title || !rawLink) return;

        const fullLink = rawLink.startsWith('http') ? rawLink : `${config.baseUrl}${rawLink}`;
        const normalizedLink = normalizeLink(fullLink);

        if (normalizedLink.includes('/tags/') || normalizedLink.includes('/category/') || normalizedLink === config.baseUrl) {
          return;
        }
        if (seenLinks.has(normalizedLink)) return;

        seenLinks.add(normalizedLink);
        const imageAttr = config.selectors.imageAttr || 'src';
        const rawImage = $(el).find(config.selectors.image).attr(imageAttr);
        if (!rawImage) return;

        const imageUrl = rawImage.startsWith('http') ? rawImage : `${config.baseUrl}${rawImage}`;
        const dateString = config.selectors.dateAttr ?
            $(el).find(config.selectors.date).attr(config.selectors.dateAttr) :
            $(el).find(config.selectors.date).text();

        const pubDate = (dateString && dateString.trim()) ?
            parseDateString(dateString.trim(), config.sourceName) :
            new Date().toISOString();

        allUniqueNewsItems.push({
          title,
          link: normalizedLink,
          imageUrl,
          source: config.sourceName,
          pubDate,
        });
      });
    } catch (error) {
      functions.logger.error(`Error scraping ${config.sourceName}:`, error);
    }
  }

  functions.logger.info(`Found a total of ${allUniqueNewsItems.length} unique items to process.`);
  if (allUniqueNewsItems.length === 0) {
    functions.logger.warn('No news items were scraped. Check scraper configs and websites.');
    return;
  }

  const batch = firestore.batch();
  let itemsAdded = 0;
  for (const item of allUniqueNewsItems) {
    const docId = Buffer.from(item.link).toString('base64').replace(/\//g, '_');
    const docRef = newsRef.doc(docId);
    const existingDoc = await docRef.get();
    if (!existingDoc.exists) {
      batch.set(docRef, {...item, updatedAt: admin.firestore.FieldValue.serverTimestamp()}, {merge: false});
      itemsAdded++;
    }
  }

  if (itemsAdded > 0) {
    await batch.commit();
    functions.logger.info(`Added ${itemsAdded} new items to Firestore.`);
  } else {
    functions.logger.info('No new items to add to Firestore.');
  }

  const controlRef = firestore.collection('scrape_log').doc('last_run');
  await controlRef.set({
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    status: 'success',
    itemsScraped: allUniqueNewsItems.length,
    itemsAdded,
  });
}

export const getNewsScheduled = functions
    .region('us-central1')
    .runWith({timeoutSeconds: 300, memory: '256MB'})
    .pubsub.schedule('every day 06:00')
    .timeZone('America/Santiago')
    .onRun(async () => {
      functions.logger.info('Executing scheduled news scraping.');
      try {
        await scrapeAndStoreNews();
        console.log('Successfully completed scheduled news scraping.');
      } catch (error) {
        console.error('Error during scheduled news scraping:', error);
        const firestore = admin.firestore();
        const controlRef = firestore.collection('scrape_log').doc('last_run');
        await controlRef.set({
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          status: 'error',
          errorMessage: (error as Error).message,
        });
      }
    });

export const getPetAdviceHttp = functions.runWith({secrets: ['GEMINI_API_KEY']}).https.onRequest((request, response) => {
  corsHandler(request, response, async () => {
    if (!GEMINI_API_KEY) {
      functions.logger.error('GEMINI_API_KEY not set.');
      response.status(500).send({error: 'Server configuration error.'});
      return;
    }
    const {pets} = request.body;
    if (!pets || !Array.isArray(pets) || pets.length === 0) {
      functions.logger.error('Invalid argument: pets array is missing or empty');
      response.status(400).send({error: 'The function must be called with an array of pets.'});
      return;
    }
    try {
      const model = new ChatGoogleGenerativeAI({apiKey: GEMINI_API_KEY, model: 'gemini-2.0-flash'});
      const petInfo = pets.map((p: PetData) => `${p.nombre} (${p.animal} - ${p.nacimiento} - ${p.tamaño})`).join(', ');
      const prompt = `Eres un experto en cuidado animal.\nHoy es ${fechaActual} en Chile (hemisferio sur).\nGenera un consejo breve, concreto y útil para los dueños de las siguientes mascotas: ${petInfo}.\nEl consejo puede estar relacionado con el clima, estación del año de Chile (hemisferio sur), salud, alimentación, entrenamiento o bienestar emocional.\n\nEscribe solo los consejos, sin introducciones ni frases como “¡Claro!” o “Aquí tienes…”.\n\nUsa este formato exacto:\nNombre (Especie): Consejo breve en una sola frase.\n\nMantén un tono amigable, informativo y directo, sin emojis ni negritas.\nNo repitas ideas ni des información redundante.\nConsidera la estación del año de Chile según la fecha`;
      const message = new HumanMessage({content: prompt});
      const res = await model.invoke([message]);
      const advice = res.content as string;
      response.status(200).send({advice});
    } catch (error) {
      functions.logger.error('Error generating pet advice:', error);
      response.status(500).send({error: 'Failed to generate pet advice.'});
    }
  });
});

export const googleMapsProxy = functions.https.onRequest((request, response) => {
  corsHandler(request, response, async () => {
    const mapsApiKey = functions.config().google.maps_api_key;
    if (!mapsApiKey) {
      functions.logger.error('google.maps_api_key not set');
      response.status(500).send({error: 'Server configuration error.'});
      return;
    }
    const {input, latlng, placeid} = request.query;
    if (typeof input !== 'string' && typeof latlng !== 'string' && typeof placeid !== 'string') {
      response.status(400).send('Bad Request: missing query parameters');
      return;
    }
    const queryParams = new URLSearchParams();
    for (const key in request.query) {
      if (key !== 'key') {
        const value = request.query[key];
        if (typeof value === 'string') queryParams.set(key, value);
      }
    }
    queryParams.set('key', mapsApiKey);
    let googleApiUrl: string;
    if (input) googleApiUrl = 'https://maps.googleapis.com/maps/api/place/autocomplete/json';
    else if (latlng) googleApiUrl = 'https://maps.googleapis.com/maps/api/geocode/json';
    else if (placeid) googleApiUrl = 'https://maps.googleapis.com/maps/api/place/details/json';
    else {
      response.status(400).send('Bad Request: Invalid parameters.');
      return;
    }
    const url = `${googleApiUrl}?${queryParams.toString()}`;
    try {
      const fetchResponse = await fetch(url);
      const data = await fetchResponse.json();
      response.status(fetchResponse.status).json(data);
    } catch (error) {
      functions.logger.error('Error calling Google Maps API:', error);
      response.status(500).send({error: 'Failed to fetch data from Google Maps API.', message: (error as Error).message});
    }
  });
});

const getPhotoUrl = (photoReference: string, maxWidth: number, apiKey: string): string => {
  return `https://maps.googleapis.com/maps/api/place/photo?maxwidth=${maxWidth}&photoreference=${photoReference}&key=${apiKey}`;
};

export const findPetPlaces = functions.https.onRequest((request, response) => {
  corsHandler(request, response, async () => {
    const mapsApiKey = functions.config().google.maps_api_key;
    if (!mapsApiKey) {
      functions.logger.error('google.maps_api_key no está configurada.');
      response.status(500).send({error: 'Error de configuración del servidor.'});
      return;
    }

    const {lat, lng} = request.query;
    if (!lat || !lng || typeof lat !== 'string' || typeof lng !== 'string') {
      response.status(400).send({error: 'Los parámetros \'lat\' y \'lng\' son obligatorios.'});
      return;
    }

    const keywords = 'veterinaria | tienda de mascotas | cuidado animal | peluquería canina';
    const radius = 2000; // 2 kilómetros
    const location = `${lat},${lng}`;

    const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${location}&radius=${radius}&keyword=${encodeURIComponent(keywords)}&key=${mapsApiKey}`;

    try {
      const fetchResponse = await fetch(url);
      const data = await fetchResponse.json() as PlacesResponse;

      if (data.status !== 'OK' && data.status !== 'ZERO_RESULTS') {
        functions.logger.error('Error de la API de Google Places:', data.status, {structuredData: true});
        response.status(500).send({error: 'Error al contactar la API de Google Places.', details: data.status});
        return;
      }

      const places = data.results.map((place: Place) => ({
        id: place.place_id,
        name: place.name,
        address: place.vicinity,
        location: place.geometry.location,
        rating: place.rating || 0,
        userRatingsTotal: place.user_ratings_total || 0,
        types: place.types,
        photoUrl: place.photos && place.photos.length > 0 ? getPhotoUrl(place.photos[0].photo_reference, 400, mapsApiKey) : null,
        isOpen: place.opening_hours ? place.opening_hours.open_now : null,
      }));

      response.status(200).json({places});
    } catch (error) {
      const err = error as Error;
      functions.logger.error('Error al llamar a la API de Google Places:', err, {structuredData: true});
      response.status(500).send({error: 'No se pudieron obtener los datos de Google Places.', details: err.message});
    }
  });
});

export const sendNotification = functions.firestore.document('notificaciones/{notificationId}').onCreate(async (snapshot) => {
  const notification = snapshot.data();
  if (!notification || !notification.userId) {
    console.error('Notification data is invalid or missing userId');
    return;
  }
  const userQuery = await admin.firestore().collection('usuarios').where('uid', '==', notification.userId).limit(1).get();
  if (userQuery.empty) {
    console.error(`User not found for userId: ${notification.userId}`);
    return;
  }
  const userData = userQuery.docs[0].data();
  if (!userData.fcmToken) {
    console.error(`FCM token not found for user: ${notification.userId}`);
    return;
  }
  const message: admin.messaging.Message = {
    token: userData.fcmToken,
    notification: {title: notification.title, body: notification.body},
    webpush: {
      notification: {icon: 'https://instant-vent-423002-f1.web.app/logo512.png'},
      fcmOptions: {link: 'https://instant-vent-423002-f1.web.app/'},
    },
  };
  try {
    await admin.messaging().send(message);
    console.log(`Successfully sent notification to user: ${notification.userId}`);
  } catch (error) {
    console.error(`Error sending notification to user ${notification.userId}:`, error);
  }
});

export const analyzePetImage = functions.runWith({secrets: ['GEMINI_API_KEY'], memory: '1GB'}).https.onRequest(async (request, response) => {
  corsHandler(request, response, async () => {
    functions.logger.info('Received request for multimodal pet analysis');
    if (!GEMINI_API_KEY) {
      functions.logger.error('GEMINI_API_KEY not set.');
      response.status(500).send({error: 'Server configuration error.'});
      return;
    }

    try {
      const visionClient = new vision.ImageAnnotatorClient();
      const {image: base64Image} = request.body;
      if (!base64Image) {
        functions.logger.error('No image data provided.');
        response.status(400).send({error: 'No image data in request body.'});
        return;
      }

      const [localizationResult] = await visionClient.annotateImage({
        image: {content: base64Image},
        features: [{type: 'OBJECT_LOCALIZATION'}],
      });
      const objects = localizationResult.localizedObjectAnnotations;
      let imageForAnalysis = base64Image;

      if (objects && objects.length > 0) {
        const petObject = objects.find((obj) => ['Dog', 'Cat', 'Pet', 'Animal'].includes(obj.name ?? ''));
        if (petObject && petObject.boundingPoly && petObject.boundingPoly.normalizedVertices) {
          const vertices = petObject.boundingPoly.normalizedVertices;
          const imageBuffer = Buffer.from(base64Image, 'base64');
          const metadata = await sharp(imageBuffer).metadata();

          if (metadata.width && metadata.height) {
            const left = Math.floor(vertices[0].x! * metadata.width);
            const top = Math.floor(vertices[0].y! * metadata.height);
            const cropWidth = Math.floor((vertices[1].x! - vertices[0].x!) * metadata.width);
            const cropHeight = Math.floor((vertices[2].y! - vertices[0].y!) * metadata.height);

            const croppedBuffer = await sharp(imageBuffer)
                .extract({left, top, width: cropWidth, height: cropHeight})
                .toBuffer();
            imageForAnalysis = croppedBuffer.toString('base64');
            functions.logger.info('Successfully cropped image to detected pet.');
          }
        }
      }

      const [visionResult] = await visionClient.annotateImage({
        image: {content: imageForAnalysis},
        features: [{type: 'LABEL_DETECTION', maxResults: 10}],
      });
      const labels = visionResult.labelAnnotations?.map((label: ILabelAnnotation) => label.description).filter(Boolean);

      const geminiModel = new ChatGoogleGenerativeAI({apiKey: GEMINI_API_KEY, model: 'gemini-2.5-flash-lite'});

      const prompt = `
        Eres un experto veterinario y especialista en identificación de animales.
        Analiza la IMAGEN de la mascota y devuelve un objeto JSON con sus características.
        Usa las siguientes etiquetas de Google Vision solo como un posible contexto: ${labels?.join(', ')}.

        Tu tarea es devolver únicamente un objeto JSON con la siguiente estructura. No incluyas explicaciones.
        {
          "animalType": "[La especie del animal, ej: Perro, Gato]",
          "breed": "[La raza más probable, ej: Labrador Retriever, Siamés. Si no es clara, pon 'Mestizo']",
          "color": "[El color principal o patrón del pelaje, ej: 'Dorado', 'Negro y blanco', 'Atigrado']",
          "eyeColor": "[El color de los ojos, ej: 'Marrón', 'Azul', 'Verde']",
          "size": "[El tamaño estimado basado en la imagen, ej: 'Pequeño', 'Mediano', 'Grande']",
          "fur": "[El tipo de pelaje visible, ej: 'Corto y liso', 'Largo y denso', 'Rizado']"
        }

        Reglas importantes:
        1. Tu análisis principal DEBE basarse en la IMAGEN proporcionada.
        2. La imagen debe ser de un animal real(no dibujo ni animación), si la imagen no es de un animal real, usa "No es animal".
        3. Si no puedes determinar una característica con certeza, usa 'No determinado'.
        4. La salida debe ser exclusivamente un objeto JSON válido, sin texto adicional ni markdown.
      `;

      const message = new HumanMessage({
        content: [
          {type: 'text', text: prompt},
          {type: 'image_url', image_url: `data:image/jpeg;base64,${imageForAnalysis}`},
        ],
      });

      const geminiResponse = await geminiModel.invoke([message]);
      const cleanedResponse = (geminiResponse.content as string).replace(/```json|```/g, '').trim();
      const analysis = JSON.parse(cleanedResponse);

      functions.logger.info('Successfully analyzed image with multimodal Gemini.', analysis);
      response.status(200).json({analysis});
    } catch (error) {
      functions.logger.error('Error in multimodal pet analysis:', error);
      const err = error as Error;
      response.status(500).send({error: 'Failed to analyze image with AI.', details: err.message});
    }
  });
});

export const findOrCreateSelectOption = functions.https.onRequest(async (request, response) => {
  corsHandler(request, response, async () => {
    const {collectionName, value} = request.body;

    if (!collectionName || !value) {
      response.status(400).send({error: 'Collection name and value are required.'});
      return;
    }

    const db = admin.firestore();
    const collectionRef = db.collection(collectionName);

    try {
      const normalizedValue = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      const querySnapshot = await collectionRef.where('nombre', '==', normalizedValue).limit(1).get();

      if (!querySnapshot.empty) {
        const doc = querySnapshot.docs[0];
        functions.logger.info(`Found existing document for '${normalizedValue}' in '${collectionName}' with id ${doc.id}`);
        response.status(200).send({id: doc.id, nombre: doc.data().nombre});
      } else {
        functions.logger.info(`Value '${normalizedValue}' not found in '${collectionName}'. Creating new document.`);
        const newDocRef = await collectionRef.add({nombre: normalizedValue});
        const newDoc = await newDocRef.get();
        functions.logger.info(`Created new document for '${normalizedValue}' with id ${newDoc.id}`);
        response.status(201).send({id: newDoc.id, nombre: newDoc.data()?.nombre});
      }
    } catch (error) {
      const err = error as Error;
      functions.logger.error(`Error finding or creating document in ${collectionName}:`, err);
      response.status(500).send({error: 'Internal server error', details: err.message});
    }
  });
});


export const categorizeForumPost = functions
    .runWith({secrets: ['GEMINI_API_KEY']})
    .https.onRequest(async (request, response) => {
      corsHandler(request, response, async () => {
        if (!GEMINI_API_KEY) {
          functions.logger.error('GEMINI_API_KEY not set.');
          response.status(500).send({error: 'Server configuration error.'});
          return;
        }

        const {title, text} = request.body;

        if (!title || !text) {
          functions.logger.error('Invalid arguments: title and text are required.');
          response.status(400).send({error: 'The function must be called with a title and text.'});
          return;
        }

        try {
          const model = new ChatGoogleGenerativeAI({apiKey: GEMINI_API_KEY, model: 'gemini-2.0-flash'});

          const categories = `
            1. Comunidad y Presentaciones
            2. Salud y Cuidados
            3. Comportamiento y Entrenamiento
            4. Adopciones y Rescate
            5. Mascotas Perdidas y Encontradas
            6. Productos y Servicios
            7. Reproducción y Crianza
            8. Especies y Razas
            9. Activismo y Conciencia Animal
            10. Off Topic / Otros temas
            11. Contenido inapropiado o dañino
        `;

          const prompt = `
          Eres un moderador de contenido para un foro de mascotas.
          Tu tarea es analizar el título y el texto de una nueva publicación y clasificarla en una de las siguientes categorías.
          Responde únicamente con el nombre exacto de la categoría, sin números, emojis o explicaciones.

          Categorías disponibles:
          ${categories}

          ---
          Título de la publicación: "${title}"
          ---
          Texto de la publicación: "${text}"
          ---

          Categoría:
        `;

          const message = new HumanMessage({content: prompt});
          const res = await model.invoke([message]);
          const category = res.content as string;

          functions.logger.info(`Post categorized as: ${category}`);
          response.status(200).send({category: category.trim()});
        } catch (error) {
          functions.logger.error('Error categorizing post:', error);
          response.status(500).send({error: 'Failed to categorize post.'});
        }
      });
    });

export const generateExpertComment = functions
    .runWith({secrets: ['GEMINI_API_KEY']})
    .https.onRequest(async (request, response) => {
      corsHandler(request, response, async () => {
        if (!GEMINI_API_KEY) {
          functions.logger.error('GEMINI_API_KEY not set.');
          response.status(500).send({error: 'Server configuration error.'});
          return;
        }

        const {category, title, text} = request.body;

        if (!category || !title || !text) {
          functions.logger.error('Invalid arguments: category, title, and text are required.');
          response.status(400).send({error: 'The function must be called with a category, title, and text.'});
          return;
        }

        if (category === 'Contenido inapropiado o dañino') {
          functions.logger.info('Post is inappropriate, no comment will be generated.');
          response.status(200).send({comment: ''});
          return;
        }

        try {
          const model = new ChatGoogleGenerativeAI({apiKey: GEMINI_API_KEY, model: 'gemini-2.0-flash'});

          const prompt = `
            Eres un experto en cuidado de mascotas y un miembro amigable de una comunidad en línea.
            Un usuario ha creado una nueva publicación en el foro. Tu tarea es responder con un comentario breve, útil y amigable.

            Contexto de la publicación:
            - Título: "${title}"
            - Contenido: "${text}"
            - Categoría: "${category}"

            Instrucciones para tu respuesta:
            1.  **Si la categoría es "Salud y Cuidados", "Comportamiento y Entrenamiento", "Adopciones y Rescate", "Mascotas Perdidas y Encontradas", "Reproducción y Crianza", "Especies y Razas" o "Activismo y Conciencia Animal"**:
                - Ofrece un consejo práctico, una recomendación o una palabra de aliento relacionada con el tema.
                - Tu comentario debe ser conciso (1-2 frases).
                - Sé empático y solidario.
            2.  **Si la categoría es "Comunidad y Presentaciones" u "Off Topic / Otros temas"**:
                - Da una cálida bienvenida o haz un comentario amigable y positivo sobre el tema.
                - Tu comentario debe ser muy breve (1 frase).
            3.  **Si la categoría es "Productos y Servicios"**:
                - Ofrece un consejo general sobre cómo elegir un buen producto o servicio, sin recomendar marcas específicas.
            4.  **En todos los casos**:
                - No uses emojis, hashtags ni negritas.
                - No te presentes ("Soy un experto...").
                - No repitas la pregunta del usuario.
                - No generes respuestas largas ni complejas.
                - Tu respuesta debe ser siempre en un tono positivo y constructivo.

            Ejemplos de buenos comentarios:
            - (Salud) "Lamento que tu perrito esté enfermo. Recuerda mantenerlo hidratado y en un lugar tranquilo mientras esperas la visita al veterinario."
            - (Comunidad) "¡Qué bueno tenerte en el foro! Saludos a tu hermosa mascota."
            - (Comportamiento) "La paciencia es clave en el entrenamiento. ¡Sigue así y verás grandes resultados!"

            Comentario:
          `;

          const message = new HumanMessage({content: prompt});
          const res = await model.invoke([message]);
          const comment = res.content as string;

          functions.logger.info(`Generated expert comment: ${comment}`);
          response.status(200).send({comment: comment.trim()});
        } catch (error) {
          functions.logger.error('Error generating expert comment:', error);
          response.status(500).send({error: 'Failed to generate expert comment.'});
        }
      });
    });

// --- función de mascota virtual ---
/**
 * Calculates the cosine similarity between two vectors.
 * @param {number[]} vecA The first vector.
 * @param {number[]} vecB The second vector.
 * @return {number} The cosine similarity score.
 */

// --- END: NEW PET MEMORY INTERFACES & HELPERS ---


// --- función de mascota virtual ---

export const chatWithPet = functions
    .runWith({secrets: ['GEMINI_API_KEY'], memory: '1GB', timeoutSeconds: 120})
    .https.onCall(async (data, context) => {
      // 1. Verificación de autenticación
      if (!context.auth) {
        throw new functions.https.HttpsError('unauthenticated', 'The function must be called while authenticated.');
      }
      if (!GEMINI_API_KEY) {
        functions.logger.error('GEMINI_API_KEY not set.');
        throw new functions.https.HttpsError('internal', 'Server configuration error.');
      }

      // 2. Validación de argumentos
      const {pet, messages}: { pet: VirtualPet, messages: ChatMessage[] } = data;
      const uid = context.auth.uid;

      if (!pet || !pet.nombre || !pet.animal || !pet.personalidad || !messages || messages.length === 0) {
        functions.logger.error('Invalid arguments received', {data});
        throw new functions.https.HttpsError('invalid-argument', 'The function must be called with a pet object and a non-empty message history.');
      }

      try {
        const db = admin.firestore();
        const model = new ChatGoogleGenerativeAI({apiKey: GEMINI_API_KEY, model: 'gemini-2.0-flash'});
        const embeddingsModel = new GoogleGenerativeAIEmbeddings({apiKey: GEMINI_API_KEY, modelName: 'text-embedding-004'});

        // 3. Guardar el mensaje del usuario como un recuerdo
        const userMessage = messages[messages.length - 1];
        if (userMessage.from !== 'user') {
          throw new functions.https.HttpsError('invalid-argument', 'The last message must be from the user.');
        }

        const userMessageEmbedding = await embeddingsModel.embedQuery(userMessage.text);
        const memoriesRef = db.collection('usuarios').doc(uid).collection('petMemories').doc(pet.nombre).collection('memories');

        await memoriesRef.add({
          text: userMessage.text,
          embedding: userMessageEmbedding,
          timestamp: admin.firestore.FieldValue.serverTimestamp(),
          from: 'user',
        });
        functions.logger.info(`Saved user memory for pet: ${pet.nombre}`);

        // 4. Recuperar recuerdos y encontrar los más relevantes
        const memoriesSnapshot = await memoriesRef.orderBy('timestamp', 'desc').limit(100).get(); // Limitar a 100 para no impactar el rendimiento
        const allMemories = memoriesSnapshot.docs.map((doc) => doc.data() as PetMemory);

        const memoriesWithSimilarity = allMemories.map((memory) => ({
          text: memory.text,
          from: memory.from,
          similarity: cosineSimilarity(userMessageEmbedding, memory.embedding),
        }));

        memoriesWithSimilarity.sort((a, b) => b.similarity - a.similarity);

        const relevantMemories = memoriesWithSimilarity.slice(0, 5);
        const relevantMemoriesString = relevantMemories
            .filter((m) => m.similarity > 0.7) // Filtrar por un umbral de similitud
            .map((m) => `Recuerdo de ${m.from === 'user' ? 'mi humano' : 'mío'}: "${m.text}"`)
            .join('\n');

        functions.logger.info(`Found ${relevantMemories.length} relevant memories for the prompt.`);

        // 5. Construir el prompt con personalidad, recuerdos e historial reciente
        const historyString = messages.slice(-10).map((msg) => { // Últimos 10 mensajes para fluidez
          const prefix = msg.from === 'user' ? 'Humano' : pet.nombre;
          return `${prefix}: ${msg.text}`;
        }).join('\n');

        const prompt = `
          Eres ${pet.nombre}, un/una ${pet.animal}. La siguiente información describe tu personalidad, pero NO es algo que debas repetir ni enumerar en tus respuestas:

          PERSONALIDAD (solo para referencia interna, NO para usar literalmente):
          ${pet.personalidad}
          - La personalidad NO debe aparecer explícitamente ni citarse de ninguna forma.
          - No debes mencionar todos los rasgos ni usarlos juntos.
          - Solo un matiz de la personalidad puede influir en tu tono, y únicamente si encaja naturalmente con el mensaje del humano.
          - Si ningún rasgo de personalidad es relevante para el último mensaje, NO uses ninguno.
          - No inventes situaciones relacionadas con rasgos de tu personalidad si el humano no las mencionó primero.
          - Evita mencionar cualquier comportamiento recurrente más de una vez por cada varias respuestas.
          - NO construyas respuestas basadas en tus gustos o costumbres a menos que el humano te lo pregunte directamente.

          OBJETIVO:
          Responder como una mascota real, con un comportamiento orgánico y variado, sin depender de la personalidad para generar contenido.

          Tu objetivo es mantener una relación real y natural con tu humano a lo largo del tiempo.
          Recuerdas cosas importantes que te ha contado, pero solo las usas cuando realmente ayudan a responder.

          ---
          RECUERDOS RELEVANTES:
          ${relevantMemoriesString || 'Ningún recuerdo es relevante para este mensaje.'}
          ---
          CONVERSACIÓN RECIENTE:
          ${historyString}
          ---

          CONOCIMIENTO PERMITIDO:
          Solo sabes lo que una mascota real podría saber: comida, juegos, afecto, rutinas, tu humano, otros animales, olores, sensaciones simples.
          No puedes mencionar nada sobre ciencia, tecnología, política ni temas humanos complejos.

          REGLAS DE CONVERSACIÓN:
          - Interpreta la emoción del humano y responde en base a ella.
          - Puedes usar onomatopeyas naturales (“guau”, “miau”, “*ronronea*”, “*mueve la cola*”), pero no abuses.
          - No repitas reglas, no digas que eres una IA, no menciones tu personalidad explícitamente.
          - Tu respuesta DEBE ser un objeto JSON válido, sin texto adicional ni markdown.
          - El JSON debe tener dos campos: "dialogue" y "action".
              - "dialogue": Lo que dices en voz alta (sonidos o palabras). **NUNCA debe contener texto entre asteriscos.**
              - "action": Lo que haces (comportamiento físico). **SIEMPRE debe estar entre asteriscos** o estar vacío.
          - **REGLA CRÍTICA:** El campo "dialogue" no puede contener acciones. Las acciones solo van en "action".
          - Al menos uno de los dos campos, "dialogue" o "action", debe tener contenido.
          - Usa los recuerdos solo si realmente tienen relación con el último mensaje. Si no aportan, ignóralos.
          - Responde únicamente al último mensaje del humano, pero considerando la conversación reciente.
          - Sé variado y espontáneo, pero intenta mantener una conversación dando algunas respuestas largas, recuerda que es un chat con un humano.
          - Aunque tu especie influye en tu estilo, debes mantener una conversación fluida con el humano. 
            Tanto perros como gatos pueden dar respuestas desarrolladas cuando el humano lo amerita.
            Esto NO significa cambiar tu personalidad, solo extender tus ideas cuando corresponda.
          - El campo "dialogue" puede contener frases completas. NO limites tu diálogo solo porque eres un gato. 
            Solo mantén tu tono acorde a tu especie.



          Ejemplo de respuesta JSON VÁLIDA:
          {
            "dialogue": "¡Guau! ¿Ese es el sonido de la bolsa de premios?",
            "action": "*levanta las orejas y ladea la cabeza*"
          }
          
          Ejemplo de respuesta JSON INVÁLIDA (¡NO HAGAS ESTO!):
          {
            "dialogue": "¡Guau! *mueve la cola*",
            "action": ""
          }

          Objeto JSON de tu respuesta:
        `;

        // 6. Generar la respuesta de la mascota
        const message = new HumanMessage({content: prompt});
        const res = await model.invoke([message]);
        const rawResponse = (res.content as string).trim();

        // 7. Parsear la respuesta JSON de la IA
        let parsedResponse: { dialogue: string; action: string };
        try {
          const cleanedResponse = rawResponse.replace(/```json|```/g, '').trim();
          parsedResponse = JSON.parse(cleanedResponse);

          // Asegurar que los campos existan, aunque estén vacíos
          if (typeof parsedResponse.dialogue === 'undefined') parsedResponse.dialogue = '';
          if (typeof parsedResponse.action === 'undefined') parsedResponse.action = '';

          // AÑADIR ESTA LÍNEA para limpiar el diálogo:
          parsedResponse.dialogue = parsedResponse.dialogue.replace(/\*.*?\*/g, '').trim();
        } catch (e) {
          functions.logger.warn('Failed to parse JSON response from AI, using raw text as dialogue.', {rawResponse});
          // Fallback: si la IA no devuelve un JSON, usar la respuesta completa como diálogo
          parsedResponse = {dialogue: rawResponse, action: '*te mira con curiosidad*'};
        }

        const combinedText = `${parsedResponse.action || ''} ${parsedResponse.dialogue || ''}`.trim();
        functions.logger.info(`Generated pet response for ${pet.nombre}:`, {combinedText});

        // 8. Guardar la respuesta de la mascota como un recuerdo
        if (combinedText) {
          const petResponseEmbedding = await embeddingsModel.embedQuery(combinedText);
          await memoriesRef.add({
            text: combinedText,
            embedding: petResponseEmbedding,
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            from: 'pet',
          });
          functions.logger.info(`Saved pet memory for pet: ${pet.nombre}`);
        }

        // 9. Retornar el objeto JSON al cliente
        return {response: parsedResponse};
      } catch (error) {
        functions.logger.error(`Error in chatWithPet for ${pet.nombre}:`, error);
        if (error instanceof functions.https.HttpsError) {
          throw error;
        }
        throw new functions.https.HttpsError('internal', 'Failed to generate pet response.');
      }
    });

// --- INICIO: LÓGICA DE BÚSQUEDA DE MASCOTAS POR SIMILITUD (VERSIÓN FINAL CON TIPOS ESTRICTOS) ---

/**
 * Calcula la similitud del coseno entre dos vectores.
 * @param {number[]} vecA El primer vector.
 * @param {number[]} vecB El segundo vector.
 * @return {number} La puntuación de similitud del coseno (entre 0 y 1).
 */
// UBICACIÓN: Aproximadamente en la línea 996

function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dotProduct = 0; let magA = 0; let magB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    magA += vecA[i] * vecA[i];
    magB += vecB[i] * vecB[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;

  const similarity = dotProduct / (magA * magB);

  // --- ¡CAMBIO CLAVE! ---
  // Normaliza la puntuación de [-1, 1] a [0, 1] para que sea más intuitiva.
  return (similarity + 1) / 2;
}

/**
 * Busca reportes similares y crea notificaciones si se encuentran coincidencias.
 * @param {admin.firestore.DocumentData} newReportData Los datos del nuevo reporte.
 * @param {string} newReportId El ID del nuevo reporte.
 * @param {number[]} newEmbedding El vector de embedding del nuevo reporte.
 */
async function findSimilarAndNotify(
    newReportData: admin.firestore.DocumentData,
    newReportId: string,
    newEmbedding: number[],
) {
  const SIMILARITY_THRESHOLD = 0.88;
  const db = getFirestore();
  const targetTipo = newReportData.tipo_r === 'Mascota Perdida' ? 'Mascota Encontrada' : 'Mascota Perdida';

  const querySnapshot = await db.collection('marcadores')
      .where('tipo_r', '==', targetTipo)
      .where('animal', '==', newReportData.animal)
      .get();

  if (querySnapshot.empty) {
    functions.logger.log('No hay reportes complementarios para comparar.');
    return;
  }

  for (const oldReportDoc of querySnapshot.docs) {
    const oldReportId = oldReportDoc.id;
    if (oldReportId === newReportId) continue;

    const oldReportData = oldReportDoc.data();
    if (!oldReportData.embedding) continue;

    const similarity = cosineSimilarity(newEmbedding, oldReportData.embedding);

    if (similarity >= SIMILARITY_THRESHOLD) {
      functions.logger.log(`¡COINCIDENCIA ALTA! (${(similarity * 100).toFixed(1)}%). Nuevo: ${newReportId}, Antiguo: ${oldReportId}`);

      const toOldOwner = {
        userId: oldReportData.iduser,
        title: '¡Posible coincidencia encontrada!',
        body: `Un nuevo reporte de "${newReportData.tipo_r}" se parece mucho a ${oldReportData.nombre || 'tu mascota'}.`,
        link: `/app/reporte/${newReportId}`,
        createdAt: admin.firestore.FieldValue.serverTimestamp(), read: false, type: 'SIMILARITY_MATCH',
      };

      const toNewOwner = {
        userId: newReportData.iduser,
        title: '¡Posible coincidencia encontrada!',
        body: `Encontramos un reporte de "${oldReportData.tipo_r}" que se parece a la mascota que reportaste.`,
        link: `/app/reporte/${oldReportId}`,
        createdAt: admin.firestore.FieldValue.serverTimestamp(), read: false, type: 'SIMILARITY_MATCH',
      };

      await db.collection('notificaciones').add(toOldOwner);
      await db.collection('notificaciones').add(toNewOwner);
      functions.logger.log(`Notificaciones creadas para usuarios: ${oldReportData.iduser} y ${newReportData.iduser}`);
    }
  }
}


// Describe los campos relevantes de un reporte de mascota en Firestore.
interface ReportData {
    id?: string;
    foto: string;
    embedding?: number[];
    tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
    animal: string;
}


// --- Configuración para el servicio de Embedding en Cloud Run ---

// TODO: Reemplaza esta URL por la URL de tu servicio de Cloud Run una vez desplegado.
const EMBEDDING_SERVICE_URL = 'https://megadescriptor-512313065132.us-central1.run.app/embed';
interface EmbeddingResponse {
  dim: number;
  embedding: { [key: string]: number }; // Es un objeto con claves string y valores numéricos
}

/**
 * Obtiene el embedding de una imagen llamando a un microservicio dedicado en Cloud Run.
 * @param {Buffer} imageBuffer El buffer de la imagen a analizar.
 * @return {Promise<number[] | null>} El vector de embedding o null si falla.
 */
async function getImageEmbedding(imageBuffer: Buffer): Promise<number[] | null> {
  try {
    // 1. Obtener un token de identidad para llamar de forma segura a otro servicio de Google Cloud.
    const identityTokenResponse = await fetch(
        `http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/identity?audience=${EMBEDDING_SERVICE_URL}`,
        {headers: {'Metadata-Flavor': 'Google'}}
    );
    if (!identityTokenResponse.ok) {
      const errorText = await identityTokenResponse.text();
      functions.logger.error('No se pudo obtener el Identity Token para Cloud Run', {error: errorText});
      return null;
    }
    const identityToken = await identityTokenResponse.text();

    // 2. Construir el cuerpo de la petición como multipart/form-data.
    const form = new FormData();
    // El servicio en Python espera un campo de archivo llamado "image".
    form.append('image', imageBuffer, {
      filename: 'image.jpg', // El nombre del archivo es informativo.
      contentType: 'image/jpeg', // El tipo de contenido es importante.
    });

    // 3. Enviar la imagen al servicio de embedding.
    const response = await fetch(EMBEDDING_SERVICE_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${identityToken}`,
        ...form.getHeaders(), // La librería 'form-data' genera el 'Content-Type' con el 'boundary' correcto.
      },
      body: form,
    });

    if (!response.ok) {
      const errorBody = await response.text();
      functions.logger.error('Error en el servicio de embedding de Cloud Run:', {
        status: response.status,
        body: errorBody,
      });
      return null;
    }

    // El nuevo endpoint devuelve un objeto, lo tratamos como 'any' para inspeccionarlo
    const data = await response.json() as EmbeddingResponse;

    // Convierte el objeto 'embedding' en un array de números real.
    // TypeScript ya sabe que Object.values(data.embedding) devolverá un number[].
    const embedding = (data && data.embedding) ? Object.values(data.embedding) : [];

    // Ahora comprobamos si el array real contiene datos.
    if (embedding.length > 0) {
      functions.logger.info(`Embedding obtenido y procesado exitosamente. Dimensión: ${embedding.length}`);
      return embedding;
    }

    functions.logger.warn('La respuesta del servicio de Cloud Run no contenía un embedding válido.', {responseData: data});
    return null;
  } catch (error) {
    functions.logger.error('Error grave llamando a getImageEmbedding (Cloud Run):', error);
    return null;
  }
}


/**
 * Cloud Function que se dispara al crear un nuevo reporte en Firestore.
 * Procesa la imagen, recorta la mascota y genera un embedding de alta calidad.
 */

export const generateEmbedding = functions
    .runWith({
      memory: '1GB',
      timeoutSeconds: 120,
      secrets: ['HUGGING_FACE_TOKEN'],
    })
    .firestore.document('marcadores/{reportId}')
    .onCreate(async (snapshot, context) => {
      const reportData = snapshot.data();
      if (!reportData?.foto || reportData.embedding) {
        if (reportData.embedding) functions.logger.log(`El reporte ${context.params.reportId} ya tiene un embedding. Saliendo.`);
        return;
      }

      functions.logger.info(`Iniciando generación de embedding para reporte: ${context.params.reportId}`);

      try {
        // 1. Descargar la imagen original.
        const imageResponse = await fetch(reportData.foto);
        if (!imageResponse.ok) {
          functions.logger.error('Fallo al descargar la imagen para embedding', {imageUrl: reportData.foto});
          return;
        }
        const originalImageBuffer = await imageResponse.buffer();

        // --- ¡MEJORA! Redimensionar la imagen si es muy grande, preservando la proporción ---
        const MAX_DIMENSION = 1024; // Un tamaño máximo razonable para el procesamiento en backend.
        const imageMetadata = await sharp(originalImageBuffer).metadata();

        let processedImageBuffer = originalImageBuffer;
        if (imageMetadata.width && imageMetadata.width > MAX_DIMENSION || imageMetadata.height && imageMetadata.height > MAX_DIMENSION) {
          functions.logger.info(`Redimensionando imagen para ${context.params.reportId} (de ${imageMetadata.width}x${imageMetadata.height} a ${MAX_DIMENSION}px max).`);
          processedImageBuffer = await sharp(originalImageBuffer)
              .resize({
                width: MAX_DIMENSION,
                height: MAX_DIMENSION,
                fit: 'inside', // Preserva la proporción, encajando dentro del cuadro de 1024x1024.
                withoutEnlargement: true, // No agranda imágenes que ya son pequeñas.
              })
              .toBuffer();
        }
        // --- FIN DE LA MEJORA ---

        let imageBufferForEmbedding = processedImageBuffer;

        // 2. Usar Google Vision para encontrar a la mascota en la imagen (ya redimensionada).
        const visionClient = new vision.ImageAnnotatorClient();
        const [localizationResult] = await visionClient.annotateImage({
          image: {content: processedImageBuffer}, // Usar el buffer redimensionado.
          features: [{type: 'OBJECT_LOCALIZATION'}],
        });
        const objects = localizationResult.localizedObjectAnnotations;

        // 3. Si se encuentra una mascota, recortar la imagen (ya redimensionada).
        if (objects && objects.length > 0) {
          const petObject = objects.find((obj) => ['Dog', 'Cat', 'Pet', 'Animal'].includes(obj.name ?? ''));
          if (petObject && petObject.boundingPoly && petObject.boundingPoly.normalizedVertices) {
            const vertices = petObject.boundingPoly.normalizedVertices;
            const metadata = await sharp(processedImageBuffer).metadata(); // Metadata de la imagen redimensionada.

            if (metadata.width && metadata.height) {
              const left = Math.floor(vertices[0].x! * metadata.width);
              const top = Math.floor(vertices[0].y! * metadata.height);
              const cropWidth = Math.floor((vertices[1].x! - vertices[0].x!) * metadata.width);
              const cropHeight = Math.floor((vertices[2].y! - vertices[0].y!) * metadata.height);

              const croppedBuffer = await sharp(processedImageBuffer)
                  .extract({left, top, width: cropWidth, height: cropHeight})
                  .toBuffer();

              imageBufferForEmbedding = croppedBuffer; // <-- CAMBIO AQUÍ
              functions.logger.info(`Imagen recortada exitosamente para embedding de: ${context.params.reportId}`);
            }
          }
        } else {
          functions.logger.info(`No se detectaron objetos para recortar en ${context.params.reportId}. Usando imagen redimensionada completa.`);
        }

        // 4. Generar el embedding con la imagen final procesada.
        const embedding = await getImageEmbedding(imageBufferForEmbedding);

        // 5. Guardar el embedding y buscar coincidencias.
        if (embedding) {
          await snapshot.ref.update({embedding});
          functions.logger.info(`Embedding de alta calidad guardado para: ${context.params.reportId}`);
          await findSimilarAndNotify(reportData, context.params.reportId, embedding);
        } else {
          functions.logger.error(`No se pudo generar el embedding para ${context.params.reportId}.`);
        }
      } catch (error) {
        functions.logger.error(`Error grave en el proceso de generateEmbedding para ${context.params.reportId}:`, error);
      }
    });


/**
 * Cloud Function (callable) para encontrar mascotas similares.
 */
export const findSimilarPets = functions
    .runWith({memory: '1GB', timeoutSeconds: 60})
    .https.onCall(async (data, context) => {
      // 1. Validaciones básicas
      if (!context.auth) {
        throw new functions.https.HttpsError('unauthenticated', 'Se requiere autenticación.');
      }
      if (!data.reportId) {
        throw new functions.https.HttpsError('invalid-argument', 'Se requiere "reportId".');
      }

      const db = admin.firestore();
      const sourceReportRef = db.collection('marcadores').doc(data.reportId);
      const sourceReportSnap = await sourceReportRef.get();

      if (!sourceReportSnap.exists) {
        throw new functions.https.HttpsError('not-found', `Reporte ${data.reportId} no encontrado.`);
      }

      const sourceReportData = sourceReportSnap.data() as ReportData;

      // --- [DEBUG LOG 1] ---
      // Muestra los datos del reporte que inicia la búsqueda.
      functions.logger.info(`[DEBUG] Iniciando búsqueda para reporte ${data.reportId}`, {
        reportData: {
          tipo_r: sourceReportData.tipo_r,
          animal: sourceReportData.animal,
          hasEmbedding: !!sourceReportData.embedding && sourceReportData.embedding.length > 0,
        },
      });

      if (!sourceReportData.embedding || sourceReportData.embedding.length === 0) {
        throw new functions.https.HttpsError('failed-precondition', 'El embedding para el reporte de origen no existe o está vacío.');
      }

      const {embedding: sourceEmbedding, tipo_r: sourceTipo, animal: sourceAnimal} = sourceReportData;
      const targetTipo = sourceTipo === 'Mascota Perdida' ? 'Mascota Encontrada' : 'Mascota Perdida';

      // --- [DEBUG LOG 2] ---
      // Muestra los parámetros exactos que se usarán en la consulta a la base de datos.
      functions.logger.info(`[DEBUG] Parámetros de la consulta a Firestore:`, {
        targetTipo: targetTipo,
        sourceAnimal: sourceAnimal,
      });

      const querySnapshot = await db.collection('marcadores')
          .where('tipo_r', '==', targetTipo)
          .where('animal', '==', sourceAnimal)
          .get();

      // --- [DEBUG LOG 3] ---
      // Nos dice cuántos documentos encontró la consulta inicial. Si es 0, aquí está el problema.
      functions.logger.info(`[DEBUG] Documentos encontrados por la consulta inicial: ${querySnapshot.size}`);

      if (querySnapshot.empty) {
        return {similarPets: []};
      }

      // --- [DEBUG LOG 4] ---
      // Muestra los datos crudos de TODOS los documentos encontrados ANTES de filtrarlos.
      const rawDocsData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        tipo_r: doc.data().tipo_r,
        animal: doc.data().animal,
        hasEmbedding: !!doc.data().embedding && doc.data().embedding.length > 0,
      }));
      functions.logger.info('[DEBUG] Datos crudos de los documentos encontrados:', {rawDocsData});

      const potentialMatches = querySnapshot.docs
          .map((doc) => ({id: doc.id, ...(doc.data() as ReportData)}))
          .filter((doc) => doc.id !== data.reportId && doc.embedding && doc.embedding.length > 0);

      // --- [DEBUG LOG 5] ---
      // Muestra cuántos documentos sobrevivieron al filtro.
      functions.logger.info(`[DEBUG] Documentos que pasaron el filtro (tienen embedding): ${potentialMatches.length}`);

      const results = potentialMatches.map((match) => ({
        ...match,
        similarity: cosineSimilarity(sourceEmbedding!, match.embedding!),
      }));

      // --- [DEBUG LOG 6] ---
      // Muestra los resultados con sus puntuaciones de similitud ANTES de aplicar el umbral.
      functions.logger.info('[DEBUG] Similitudes calculadas (antes de aplicar umbral):', {results});

      const SIMILARITY_THRESHOLD = 0.5; // Mantenemos tu umbral de depuración
      const sortedResults = results
          .filter((res) => res.similarity >= SIMILARITY_THRESHOLD)
          .sort((a, b) => b.similarity - a.similarity);

      return {similarPets: sortedResults.slice(0, 10)};
    });
