module.exports = {
  extends: ['google'],
  rules: {
    'max-len': 'off',
    'camelcase': 'off',
    'require-jsdoc': 'off',
  },
};
