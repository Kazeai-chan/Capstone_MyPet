from fastapi import FastAPI, UploadFile
from PIL import Image
from transformers import AutoProcessor, AutoModel
import torch
from io import BytesIO

app = FastAPI()

MODEL_NAME = "apple/mobileclip-vit-quantized"

processor = AutoProcessor.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME)

@app.post("/compare")
async def compare(file1: UploadFile, file2: UploadFile):
    img1 = Image.open(BytesIO(await file1.read())).convert("RGB")
    img2 = Image.open(BytesIO(await file2.read())).convert("RGB")

    inputs = processor(images=[img1, img2], return_tensors="pt")
    outputs = model(**inputs)

    similarity = torch.cosine_similarity(
        outputs.image_embeds[0],
        outputs.image_embeds[1],
        dim=0
    )

    return {"similarity": float(similarity)}
