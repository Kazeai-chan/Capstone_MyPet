from flask import Flask, request, jsonify
from PIL import Image
import torch
import os
import numpy as np
import timm
from huggingface_hub import hf_hub_download

# --- Fix PyTorch security ---
# Esto sigue siendo potencialmente necesario porque cargamos un archivo .bin
from torch.serialization import add_safe_globals
add_safe_globals([np.core.multiarray._reconstruct])

# ------------------------------------
# Constants
# ------------------------------------
MODEL_REPO = "BVRA/MegaDescriptor-EfficientNetB3"
MODEL_FILE = "pytorch_model.bin"
ARCH_NAME = "efficientnet_b3"
EMBED_DIM = 1536 # Dimensión del embedding de salida

# ------------------------------------
# Flask App & Model Loading
# ------------------------------------
app = Flask(__name__)

print(f"🔄 Creando arquitectura del modelo: {ARCH_NAME}")
# Creamos el esqueleto del modelo con la dimensión de salida correcta
model = timm.create_model(
    ARCH_NAME,
    pretrained=False, # No usamos pesos pre-entrenados de timm
    num_classes=EMBED_DIM # La capa final tendrá 1536 neuronas
)

print(f"🔄 Descargando pesos desde {MODEL_REPO}...")
# Descargamos el archivo de pesos desde Hugging Face Hub
weights_path = hf_hub_download(
    repo_id=MODEL_REPO,
    filename=MODEL_FILE,
    token=os.getenv("HUGGING_FACE_HUB_TOKEN", "").strip()
)

print("🔄 Cargando pesos en el modelo...")
# Cargamos los pesos descargados en el modelo.
# strict=False es necesario porque los nombres de las capas en el archivo
# pueden no coincidir perfectamente con la arquitectura de timm.
model.load_state_dict(torch.load(weights_path, map_location=torch.device("cpu"), weights_only=False), strict=False)

# Ponemos el modelo en modo evaluación
model.eval()

print("✅ Modelo cargado correctamente con timm.")

# ------------------------------------
# Preprocessing (CORREGIDO)
# ------------------------------------
def preprocess_image(img: Image.Image):
    if img.mode != "RGB":
        img = img.convert("RGB")

    img = img.resize((288, 288), Image.BICUBIC)

    np_img = np.array(img).astype("float32") / 255.0
    # CORRECCIÓN: Forzar el dtype a float32 para que coincida con el modelo
    mean = np.array([0.485, 0.456, 0.406], dtype=np.float32).reshape(1, 1, 3)
    std = np.array([0.229, 0.224, 0.225], dtype=np.float32).reshape(1, 1, 3)
    np_img = (np_img - mean) / std
    np_img = np.transpose(np_img, (2, 0, 1))
    return torch.tensor(np_img).unsqueeze(0)


# ------------------------------------
# Health check
# ------------------------------------
@app.route("/", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


# ------------------------------------
# Embedding Endpoint (limpio)
# ------------------------------------
@app.route("/embed", methods=["POST"])
def embed():
    if "image" not in request.files:
        return jsonify({"error": "Debes enviar una imagen en la clave 'image'"}), 400

    try:
        img = Image.open(request.files["image"])
        tensor = preprocess_image(img)

        with torch.no_grad():
            embedding = model(tensor)

        # .squeeze() para eliminar la dimensión del batch
        vec = embedding.squeeze().cpu().numpy().tolist()

        return jsonify({
            "dim": len(vec),
            "embedding": vec
        })

    except Exception as e:
        print(f"❌ ERROR: {e}")
        return jsonify({"error": str(e)}), 500


# ------------------------------------
# Run
# ------------------------------------
if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
