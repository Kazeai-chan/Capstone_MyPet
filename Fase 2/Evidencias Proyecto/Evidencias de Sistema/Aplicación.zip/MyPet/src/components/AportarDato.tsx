import React, { useState, useContext, useEffect } from 'react';
import {
  IonTextarea, useIonAlert, IonButton
} from '@ionic/react';
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './AportarDato.css';

interface AportarDatoProps {
  onClose: (submitted: boolean) => void;
  markerId: string | null;
  markerNombre: string | null;
  markerFecha: string | null;
}

const AportarDato: React.FC<AportarDatoProps> = ({ onClose, markerId, markerNombre, markerFecha }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [pista, setPista] = useState('');
  const [presentAlert] = useIonAlert();

  // Limpiamos el estado si el componente se va a desmontar (ocultar)
  useEffect(() => {
    return () => {
      setPista('');
    };
  }, []);

  const handleSend = async () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para aportar un dato.', buttons: ['OK'] });
      return;
    }
    if (!markerId) {
        presentAlert({ header: 'Error', message: 'No se ha podido identificar el marcador.', buttons: ['OK'] });
        return;
    }
    if (pista.trim().length <= 5) {
      presentAlert({ header: 'Dato muy corto', message: 'Por favor, ingresa un dato con más de 5 letras.', buttons: ['OK'] });
      return;
    }

    try {
      await addDoc(collection(firestore, 'pistas'), {
        idmarker: markerId,
        iduser: user.uid,
        nombreUsuario: user.name,
        nombreMascota: markerNombre, // Usamos la prop
        pista: pista,
        fecha: serverTimestamp(),
        fechareporte: markerFecha
      });
      const userDocRef = doc(firestore, 'usuarios', user.uid);
      await updateDoc(userDocRef, { puntos: increment(1) });

      onClose(true);

    } catch (error) {
      console.error("Error al enviar el dato: ", error);
      presentAlert({ header: 'Error', message: 'No se pudo enviar tu dato. Inténtalo de nuevo.', buttons: ['OK'] });
    }
  };

  // El componente ahora devuelve el JSX directamente, sin portal
  return (
    <div className="aportar-dato-container">
        <div className="aportar-dato-content">
            <h2>Aportar un Dato sobre {markerNombre}</h2>
            <IonTextarea
                placeholder="Escribe aquí cualquier información que pueda ser útil..."
                value={pista}
                onIonChange={e => setPista(e.detail.value!)}
                autoGrow={true}
                style={{
                    background: 'white',
                    borderRadius: '8px',
                    padding: '10px',
                    minHeight: '120px'
                }}
            />
            <div className="aportar-dato-actions">
                <IonButton onClick={() => onClose(false)} fill="clear" color="medium">Cerrar</IonButton>
                <IonButton onClick={handleSend} style={{ '--background': '#5f7236' }}>Enviar Dato</IonButton>
            </div>
        </div>
    </div>
  );
};

export default AportarDato;
