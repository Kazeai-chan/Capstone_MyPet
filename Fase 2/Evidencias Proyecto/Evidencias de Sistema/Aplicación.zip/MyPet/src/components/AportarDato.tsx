import React, { useState, useContext, useEffect } from 'react';
import {
  IonTextarea,
  useIonAlert,
  IonButton
} from '@ionic/react';
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './AportarDato.css';

// 1. AÑADIMOS 'isOpen' A LAS PROPS
interface AportarDatoProps {
  isOpen: boolean;
  onClose: (submitted: boolean) => void;
  markerId: string | null;
  markerNombre: string | null;
  markerFecha: string | null;
  ownerId: string | null;
}

const AportarDato: React.FC<AportarDatoProps> = ({ isOpen, onClose, markerId, markerNombre, markerFecha, ownerId }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [pista, setPista] = useState('');
  const [presentAlert] = useIonAlert();

  useEffect(() => {
    // Limpia el campo de texto si el modal se cierra
    if (!isOpen) {
      setPista('');
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para aportar un dato.', buttons: ['OK'] });
      return;
    }
    if (!markerId || !ownerId) {
        presentAlert({ header: 'Error', message: 'No se ha podido identificar el reporte o el dueño.', buttons: ['OK'] });
        return;
    }
    if (pista.trim().length <= 5) {
      presentAlert({ header: 'Dato muy corto', message: 'Por favor, ingresa un dato con más de 5 letras.', buttons: ['OK'] });
      return;
    }

    try {
      await addDoc(collection(firestore, 'pistas'), {
        idmarker: markerId,
        iduser: user.uid,
        nombreUsuario: user.name,
        nombreMascota: markerNombre,
        pista: pista,
        fecha: serverTimestamp(),
        fechareporte: markerFecha
      });

      await addDoc(collection(firestore, 'notificaciones'), {
        userId: ownerId,
        title: `¡Nuevo dato sobre ${markerNombre}!`,
        body: `${user.name} ha aportado información sobre tu reporte.`,
        createdAt: serverTimestamp(),
        read: false,
        icon: '📍',
        link: '/dato'
      });

      const userDocRef = doc(firestore, 'usuarios', user.uid);
      await updateDoc(userDocRef, { puntos: increment(1) });

      onClose(true);

    } catch (error) {
      console.error("Error al enviar el dato y la notificación: ", error);
      presentAlert({ header: 'Error', message: 'No se pudo enviar tu dato. Inténtalo de nuevo.', buttons: ['OK'] });
    }
  };

  // 2. SI NO ESTÁ ABIERTO, NO RENDERIZAMOS NADA
  if (!isOpen) {
    return null;
  }

  // 3. SI ESTÁ ABIERTO, RENDERIZAMOS EL DIV FLOTANTE ORIGINAL
  return (
    <div className="aportar-dato-container">
        <div className="aportar-dato-content">
            <h2>Aportar un Dato sobre {markerNombre}</h2>
            <IonTextarea
                placeholder="Escribe aquí cualquier información que pueda ser útil..."
                value={pista}
                onIonInput={e => setPista(e.detail.value!)}
                autoGrow={true}
                className="aportar-dato-textarea-flotante"
            />
            <div className="aportar-dato-actions">
                <IonButton onClick={() => onClose(false)} fill="clear" color="medium">Cerrar</IonButton>
                <IonButton onClick={handleSend} style={{ '--background': '#5f7236' }}>Enviar Dato</IonButton>
            </div>
        </div>
    </div>
  );
};

export default AportarDato;

