import React, { useState, useContext, useEffect } from 'react';
import {
  IonTextarea, useIonAlert, IonButton, IonModal, IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonAvatar, IonCardContent, IonIcon, IonBadge, IonChip, IonSpinner
} from '@ionic/react';
import { useHistory } from 'react-router-dom';
import { collection, addDoc, serverTimestamp, query, getDocs, where, doc, getDoc, writeBatch } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import AportarDato from './AportarDato';
import ModMarcador from './ModMarcador';
import { alertCircleOutline, businessOutline, calendarOutline, callOutline, chatbubblesOutline, checkmarkCircleOutline, close, cutOutline, globeOutline, informationCircleOutline, locationOutline, pawOutline, sendOutline, star, storefrontOutline, timeOutline } from 'ionicons/icons';
import './VerMarcador.css';


// --- Unified Marker Interface ---
interface DisplayMarker {
  id: string;
  lat?: number;
  lng?: number;
  nombre: string;
  foto: string;
  iduser?: string;
  direccion?: string;
  descripcion?: string;
  tipo: 'Tienda' | 'Veterinaria' | 'Peluquería' | 'mascota';
  tipo_r?: 'Mascota Perdida' | 'Mascota Encontrada';
  animal?: string;
  tamano?: string;
  color?: string;
  fecha?: string;
  rating?: number;
  userRatingsTotal?: number;
  isGooglePlace: boolean;
  phoneNumber?: string;
  website?: string;
  openingHours?: string[]; // Array de strings para los horarios
}

interface Comentario {
    id: string;
    idmarker: string;
    iduser: string;
    nombre: string;
    cuerpo: string;
    c_fecha: any;
    avatar: string;
}

interface VerMarcadorProps {
  isOpen: boolean;
  onClose: () => void;
  marker: DisplayMarker | null;
}

// Helper function to categorize Google Place types
//const categorizePlace = (types: string[]): 'Veterinaria' | 'Peluquería' | 'Tienda' => {
//  if (types.includes('veterinary_care')) return 'Veterinaria';
//  if (types.includes('pet_grooming_service')) return 'Peluquería';
//  if (types.includes('pet_store')) return 'Tienda';
//  return 'Tienda'; // Default fallback
//};

const VerMarcador: React.FC<VerMarcadorProps> = ({ isOpen, onClose, marker }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();

  //const [marker, setMarker] = useState<DisplayMarker | null>(null);
  const [loading, setLoading] = useState(false);
  const [comentarios, setComentarios] = useState<Comentario[]>([]);
  const [nuevoComentario, setNuevoComentario] = useState('');
  const [isModModalOpen, setIsModModalOpen] = useState(false);
  const [isAportarDatoModalOpen, setIsAportarDatoModalOpen] = useState(false);
  const [presentAlert] = useIonAlert();
  const [ownerName, setOwnerName] = useState<string | null>(null);

  
  useEffect(() => {
    if (!isOpen || !marker) {
        setComentarios([]);
        setOwnerName(null);
        return;
    }

    const fetchAssociatedData = async () => {
        setLoading(true);
        try {
            // Lógica para buscar el nombre del dueño (se mantiene)
            if (marker.tipo === 'mascota' && marker.iduser) {
                const userDocRef = doc(firestore, 'usuarios', marker.iduser);
                const userDocSnap = await getDoc(userDocRef);
                setOwnerName(userDocSnap.exists() ? userDocSnap.data().name : "el dueño del reporte");
            }

            // Lógica para buscar los comentarios (se mantiene)
            const comentariosQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', marker.id));
            const querySnapshot = await getDocs(comentariosQuery);
            let comentariosData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comentario));
            comentariosData.sort((a, b) => (b.c_fecha?.toDate?.() || 0) - (a.c_fecha?.toDate?.() || 0));
            setComentarios(comentariosData);

        } catch (error) {
            console.error("Error al cargar datos asociados del marcador: ", error);
            presentAlert({ header: 'Error', message: 'No se pudieron cargar los comentarios.', buttons: ['OK'] });
        } finally {
            setLoading(false);
        }
    };

    fetchAssociatedData();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, marker]); // El efecto ahora depende del objeto 'marker'
  

  const handlePostComentario = async () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para comentar.', buttons: ['OK'] });
      return;
    }
    if (!marker) return;
    if (nuevoComentario.trim() === '') return;

    try {
      await addDoc(collection(firestore, 'comen-marcador'), {
        idmarker: marker.id,
        iduser: user.uid,
        nombre: user.name,
        cuerpo: nuevoComentario,
        c_fecha: serverTimestamp(),
        avatar: user.fotouser || 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Fuser.png?alt=media&token=3b5c325c-4348-4384-934e-b501e56456f9'
      });
      
      // Refresh comments after posting
      const comentariosQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', marker.id));
      const querySnapshot = await getDocs(comentariosQuery);
      let comentariosData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comentario));
      comentariosData.sort((a, b) => (b.c_fecha?.toDate?.() || 0) - (a.c_fecha?.toDate?.() || 0));
      setComentarios(comentariosData);

      setNuevoComentario('');
    } catch (error) {
        presentAlert({ header: 'Error', message: 'No se pudo publicar tu comentario.', buttons: ['OK'] });
    }
  };
  
  const handleMascotaEncontrada = () => {
    if (!user || !user.name || !marker || marker.isGooglePlace || !ownerName) return;
    if (user.uid === marker.iduser) {
      presentAlert({ header: 'Aviso', message: 'Este es tu propio reporte.', buttons: ['OK'] });
      return;
    }
    presentAlert({
      header: '¿Confirmar hallazgo?',
      message: `¿Estás seguro de avisar a ${ownerName} que encontraste a ${marker.nombre}?`,
      buttons: [
        { text: 'No', role: 'cancel' },
        { text: 'Sí, avisar', handler: () => {
            addDoc(collection(firestore, 'mensajes'), { de: user.uid, para: marker.iduser, fecha: serverTimestamp(), mensaje: `${user.name} ha encontrado a ${marker.nombre}` })
            .then(() => presentAlert({ header: 'Aviso Enviado', message: `Mensaje enviado a ${ownerName}.`, buttons: ['OK'] }))
            .catch(() => presentAlert({ header: 'Error', message: 'No se pudo enviar el aviso.', buttons: ['OK'] }));
        }}
      ]
    });
  };

  const handleEsMiMascota = () => {
    if (!user || !user.name || !marker || marker.isGooglePlace || !ownerName) return;
    if (user.uid === marker.iduser) {
        presentAlert({ header: 'Aviso', message: 'Este es tu propio reporte.', buttons: ['OK'] });
        return;
    }
    presentAlert({
      header: '¿Confirmar propiedad?',
      message: `¿Deseas avisar a ${ownerName} que esta mascota te pertenece?`,
      buttons: [
        { text: 'No', role: 'cancel' },
        { text: 'Sí, avisar', handler: () => {
          addDoc(collection(firestore, 'mensajes'), { de: user.uid, para: marker.iduser, fecha: serverTimestamp(), mensaje: `${user.name} dice que la mascota que encontraste es suya.` })
          .then(() => presentAlert({ header: 'Aviso Enviado', message: `Mensaje enviado a ${ownerName}.`, buttons: ['OK'] }))
          .catch(() => presentAlert({ header: 'Error', message: 'No se pudo enviar el aviso.', buttons: ['OK'] }));
        }}
      ]
    });
  };

  const handleCerrarReporte = () => {
      if (!marker || marker.isGooglePlace) return;
      presentAlert({ header: 'Confirmar Cierre', message: '¿Seguro que deseas cerrar este reporte?', buttons: [
        { text: 'Cancelar', role: 'cancel' },
        { text: 'Sí, cerrar', handler: () => {
            const markerRef = doc(firestore, 'marcadores', marker.id);
            const commentsQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', marker.id));
            getDocs(commentsQuery).then(commentsSnapshot => {
                const batch = writeBatch(firestore);
                commentsSnapshot.forEach(commentDoc => batch.delete(commentDoc.ref));
                batch.delete(markerRef);
                return batch.commit();
            }).then(() => {
                presentAlert({ header: 'Reporte Cerrado', message: 'El reporte ha sido eliminado.', buttons: ['OK'] });
                onClose();
            }).catch(() => presentAlert({ header: 'Error', message: 'No se pudo cerrar el reporte.', buttons: ['OK'] }));
        }}
      ]});
  };

  const goToProfile = (userId: string) => {
    if (userId) {
        handleClose();
        history.push(`/perfil/${userId}`);
    }
  };

  const handleClose = () => {
    setNuevoComentario('');
    onClose();
  }  

  const handleModModalClose = () => {
    setIsModModalOpen(false);
    handleClose(); // Fully close and refresh parent
  }

  const handleAportarDatoClose = (submitted: boolean) => {
    setIsAportarDatoModalOpen(false);
    if (submitted) {
      presentAlert({
        header: '¡Gracias!',
        message: 'Dato enviado, gracias por ayudar a la comunidad, usted ha ganado 1 PetPunto',
        buttons: ['OK'],
      });
    }
  }

  const formatCommentDate = (c_fecha: any): string => {
    if (c_fecha && typeof c_fecha.toDate === 'function') return new Date(c_fecha.toDate()).toLocaleString();
    if (c_fecha instanceof Date) return c_fecha.toLocaleString();
    return '';
  };

  const formatDate = (dateString: string | number | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const isMascota = marker?.tipo === 'mascota';
  const isPerdida = isMascota && marker?.tipo_r === 'Mascota Perdida';
  const isEncontrada = isMascota && marker?.tipo_r === 'Mascota Encontrada';
  const isOwner = user?.uid === marker?.iduser && !marker?.isGooglePlace;

  return (
    <>
      <IonModal isOpen={isOpen} onDidDismiss={handleClose} className="ver-marcador-modal">
        <IonHeader className="ion-no-border">
          <IonToolbar className="marcador-toolbar">
            <div className="marcador-header">
              <IonTitle className="marcador-title">{marker ? (isMascota ? marker.tipo_r : marker.nombre) : 'Cargando...'}</IonTitle>
              <IonButton fill="clear" onClick={handleClose} className="close-btn-marcador">
                <IonIcon icon={close} />
              </IonButton>
            </div>
          </IonToolbar>
        </IonHeader>

        <IonContent className="marcador-content">
          {loading && <div className="loading-container"><IonSpinner /></div>}
          
          {!loading && marker && (
            <>
              <div className="hero-image-container">
                <img src={marker.foto} alt={marker.nombre} className="hero-image" />
                {isMascota && (
                  <div className="hero-overlay">
                    <IonBadge className={`status-badge ${isPerdida ? 'perdida' : 'encontrada'}`}>
                      <IonIcon icon={isPerdida ? alertCircleOutline : checkmarkCircleOutline} />
                      {marker.tipo_r}
                    </IonBadge>
                  </div>
                )}
              </div>

              <div className="marcador-body">
                <IonCard className="title-card">
                  <IonCardContent className="title-content">
                    <h2 className="marcador-name">{isMascota ? marker.nombre : marker.nombre}</h2>
                    {marker.isGooglePlace && marker.rating ? (
                      <div className="rating-display">
                          <IonIcon icon={star} color="warning"/>
                          <span>{marker.rating} ({marker.userRatingsTotal} reseñas)</span>
                      </div>
                    ) : null}
                     <div className="info-chips">
                      {!isMascota && marker.tipo && (
                        <IonChip className="info-chip">
                          <IonIcon icon={
                            marker.tipo === 'Veterinaria' ? businessOutline :
                            marker.tipo === 'Peluquería' ? cutOutline :
                            storefrontOutline
                          } />
                          <span>{marker.tipo}</span>
                        </IonChip>
                      )}
                      {marker.direccion && <IonChip className="info-chip"><IonIcon icon={locationOutline} /><span>{marker.direccion.split(',')[0]}</span></IonChip>}
                      {isMascota && marker.fecha && <IonChip className="info-chip"><IonIcon icon={calendarOutline} /><span>{formatDate(marker.fecha).split(' ')[0]}</span></IonChip>}
                    </div>
                  </IonCardContent>
                </IonCard>
                
                <IonCard className="details-card">
                  <IonCardContent className="details-content">
                    <div className="section-header"><IonIcon icon={informationCircleOutline} className="section-icon" /><h3>Información</h3></div>
                    {marker.descripcion && <p>{marker.descripcion}</p>}
                    {/* --- INICIO: NUEVA INFORMACIÓN DE CONTACTO --- */}
                    {(marker.phoneNumber || marker.website || marker.openingHours) && (
                      <div className="contact-details-box">
                        {marker.phoneNumber && (
                          <div className="detail-item">
                            <IonIcon icon={callOutline} className="detail-icon" />
                            <div className="detail-text">
                              <span className="detail-label">Teléfono</span>
                              <p><a href={`tel:${marker.phoneNumber}`}>{marker.phoneNumber}</a></p>
                            </div>
                          </div>
                        )}
                        {marker.website && (
                          <div className="detail-item">
                            <IonIcon icon={globeOutline} className="detail-icon" />
                            <div className="detail-text">
                              <span className="detail-label">Sitio Web</span>
                              <p><a href={marker.website} target="_blank" rel="noopener noreferrer">{marker.website}</a></p>
                            </div>
                          </div>
                        )}
                        {marker.openingHours && (
                          <div className="detail-item">
                            <IonIcon icon={timeOutline} className="detail-icon" />
                            <div className="detail-text">
                              <span className="detail-label">Horarios</span>
                              {marker.openingHours.map((line, index) => <p key={index}>{line}</p>)}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                    {/* --- FIN: NUEVA INFORMACIÓN DE CONTACTO --- */}
                    {isMascota && (
                      <>
                        <div className="detail-item">
                          <IonIcon icon={calendarOutline} className="detail-icon" />
                          <div className="detail-text"><span className="detail-label">Fecha</span><p>{formatDate(marker.fecha!)}</p></div>
                        </div>
                        <div className="pet-details-box">
                          <div className="pet-detail-row">
                            <div className="pet-detail-item"><IonIcon icon={pawOutline} /><div><span className="pet-detail-label">Animal</span><p>{marker.animal}</p></div></div>
                            <div className="pet-detail-item"><span className="pet-detail-label">Nombre</span><p>{marker.nombre}</p></div>
                          </div>
                          <div className="pet-detail-row">
                            <div className="pet-detail-item"><span className="pet-detail-label">Color</span><p>{marker.color}</p></div>
                            <div className="pet-detail-item"><span className="pet-detail-label">Tamaño</span><p>{marker.tamano}</p></div>
                          </div>
                        </div>
                      </>
                    )}
                  </IonCardContent>
                </IonCard>

                {isMascota && (
                  <div className="action-buttons-container">
                    {isPerdida && !isOwner && (<>
                      <IonButton expand="block" className="action-btn primary" onClick={() => setIsAportarDatoModalOpen(true)}><IonIcon icon={informationCircleOutline} slot="start" />Aportar Dato</IonButton>
                      <IonButton expand="block" className="action-btn secondary" onClick={handleMascotaEncontrada}><IonIcon icon={checkmarkCircleOutline} slot="start" />La encontré</IonButton>
                    </>)}
                    {isEncontrada && !isOwner && (<>
                      <IonButton expand="block" className="action-btn primary" onClick={() => setIsAportarDatoModalOpen(true)}><IonIcon icon={informationCircleOutline} slot="start" />Aportar Dato</IonButton>
                      <IonButton expand="block" className="action-btn success" onClick={handleEsMiMascota}><IonIcon icon={pawOutline} slot="start" />Es Mi Mascota</IonButton>
                    </>)}
                  </div>
                )}

                <IonCard className="comments-card">
                  <IonCardContent className="comments-content">
                    <div className="section-header"><IonIcon icon={chatbubblesOutline} className="section-icon" /><h3>Comentarios</h3><IonBadge className="comments-count">{comentarios.length}</IonBadge></div>
                    <div className="comments-list">
                      {comentarios.map((comentario) => (
                        <div key={comentario.id} className="comment-item">
                          <IonAvatar className="comment-avatar" onClick={() => goToProfile(comentario.iduser)}><img src={comentario.avatar} alt={comentario.nombre} /></IonAvatar>
                          <div className="comment-content">
                            <div className="comment-header"><span className="comment-author">{comentario.nombre}</span><span className="comment-date">{formatCommentDate(comentario.c_fecha)}</span></div>
                            <p className="comment-text">{comentario.cuerpo}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    {user && (
                      <div className="new-comment-box">
                        <IonAvatar className="current-user-avatar"><img src={user.fotouser} alt={user.name} /></IonAvatar>
                        <div className="comment-input-container">
                          <IonTextarea placeholder="Escribe un comentario..." value={nuevoComentario} onIonInput={e => setNuevoComentario(e.detail.value!)} className="comment-textarea" autoGrow rows={1}/>
                          <IonButton fill="clear" className="send-comment-btn" onClick={handlePostComentario} disabled={!nuevoComentario.trim()}><IonIcon icon={sendOutline} /></IonButton>
                        </div>
                      </div>
                    )}
                  </IonCardContent>
                </IonCard>

                {isOwner && (
                  <div className="owner-actions">
                    <IonButton expand="block" fill="outline" className="action-btn secondary" onClick={() => setIsModModalOpen(true)}>Modificar Reporte</IonButton>
                    <IonButton expand="block" fill="outline" className="action-btn danger" color="danger" onClick={handleCerrarReporte}>Cerrar Reporte</IonButton>
                  </div>
                )}
                {marker && marker.isGooglePlace && (
                <div className="owner-actions">
                  <IonButton
                    expand="block"
                    fill="outline"
                    className="action-btn secondary"
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(marker.nombre)}&query_place_id=${marker.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Ver en Google Maps
                  </IonButton>
                </div>
              )}
              </div>
            </>
          )}
          {/* --- BLOQUE CORREGIDO PARA LOS MODALES HIJOS --- */}
          {marker && !marker.isGooglePlace && (
            <>
              <AportarDato
                isOpen={isAportarDatoModalOpen}  // <-- LA PROPIEDAD QUE FALTABA
                onClose={handleAportarDatoClose}
                markerId={marker.id}
                markerNombre={marker.nombre}
                markerFecha={marker.fecha || null}
                ownerId={marker.iduser || null}
              />
              <ModMarcador 
                isOpen={isModModalOpen}
                onClose={handleModModalClose}
                markerId={marker.id}
              />
            </>
          )}
        </IonContent>
      </IonModal>

    </>
  );
};

export default VerMarcador;
