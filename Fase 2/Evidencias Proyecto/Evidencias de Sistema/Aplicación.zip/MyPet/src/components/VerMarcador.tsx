import React, { useState, useContext, useEffect } from 'react';
import {
  IonTextarea, useIonAlert, IonButton,
  IonModal,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonAvatar,
  IonCardContent,
  IonIcon,
  IonBadge,
  IonChip
} from '@ionic/react';
import { useHistory } from 'react-router-dom';
import { collection, addDoc, serverTimestamp, query, getDocs, where, doc, getDoc, writeBatch } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import AportarDato from './AportarDato';
import ModMarcador from './ModMarcador';
import { alertCircleOutline, calendarOutline, chatbubblesOutline, checkmarkCircleOutline, close, informationCircleOutline, locationOutline, pawOutline, sendOutline } from 'ionicons/icons';
import './VerMarcador.css'; // Import custom CSS

interface BaseMarker { id: string; lat: number; lng: number; nombre: string; foto: string; iduser: string; direccion?: string; descripcion?: string; }
interface ShopMarker extends BaseMarker { tipo: 'Tienda' | 'Veterinaria'; }
interface PetReportMarker extends BaseMarker { tipo: 'mascota'; tipo_r: 'Mascota Perdida' | 'Mascota Encontrada'; animal: string; tamano: string; color: string; fecha: string; }
type Marker = ShopMarker | PetReportMarker;

interface Comentario {
    id: string; idmarker: string; iduser: string; nombre: string;
    cuerpo: string; c_fecha: any; avatar: string;
}

interface VerMarcadorProps {
  isOpen: boolean;
  onClose: () => void;
  marker: Marker | null;
}

const VerMarcador: React.FC<VerMarcadorProps> = ({ isOpen, onClose, marker }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();
  const [comentarios, setComentarios] = useState<Comentario[]>([]);
  const [nuevoComentario, setNuevoComentario] = useState('');
  const [isModModalOpen, setIsModModalOpen] = useState(false);
  const [isAportarDatoModalOpen, setIsAportarDatoModalOpen] = useState(false);
  const [presentAlert] = useIonAlert();
  const [ownerName, setOwnerName] = useState<string | null>(null);

  useEffect(() => {
    const fetchMarkerDetails = async () => {
      if (!marker) return;

      try {
        const comentariosQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', marker.id));
        const querySnapshot = await getDocs(comentariosQuery);
        let comentariosData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comentario));
        comentariosData.sort((a, b) => (b.c_fecha?.toDate?.() || 0) - (a.c_fecha?.toDate?.() || 0));
        setComentarios(comentariosData);
      } catch (error) {
        console.error("Error al obtener comentarios: ", error);
      }

      if (marker.iduser) {
          try {
            const userDocRef = doc(firestore, 'usuarios', marker.iduser);
            const userDocSnap = await getDoc(userDocRef);
            if (userDocSnap.exists() && userDocSnap.data().name) {
              setOwnerName(userDocSnap.data().name);
            } else {
              setOwnerName("el dueño del reporte");
            }
          } catch (error) {
            console.error("Error fetching owner name: ", error);
            setOwnerName("el dueño del reporte");
          }
      }
    };

    if (isOpen) {
      fetchMarkerDetails();
    } else {
      setComentarios([]);
      setOwnerName(null);
    }
  }, [isOpen, marker]);

  const handlePostComentario = async () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para comentar.', buttons: ['OK'] });
      return;
    }
    if (!marker) return;
    if (nuevoComentario.trim() === '') return;

    try {
      const newCommentRef = await addDoc(collection(firestore, 'comen-marcador'), {
        idmarker: marker.id,
        iduser: user.uid,
        nombre: user.name,
        cuerpo: nuevoComentario,
        c_fecha: serverTimestamp(),
        avatar: user.fotouser || 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Fuser.png?alt=media&token=3b5c325c-4348-4384-934e-b501e56456f9'
      });
      const newComment = { id: newCommentRef.id, idmarker: marker.id, iduser: user.uid, nombre: user.name, cuerpo: nuevoComentario, c_fecha: new Date(), avatar: user.fotouser || '...' };
      setComentarios(prev => [newComment, ...prev]);
      setNuevoComentario('');
    } catch (error) {
        presentAlert({ header: 'Error', message: 'No se pudo publicar tu comentario.', buttons: ['OK'] });
    }
  };
  
  const handleMascotaEncontrada = () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para realizar esta acción.', buttons: ['OK'] });
      return;
    }
    if (user.uid === marker?.iduser) {
      presentAlert({ header: 'Aviso', message: 'Este es tu propio reporte.', buttons: ['OK'] });
      return;
    }
    if (!marker || !ownerName) return;

    presentAlert({
      header: '¿Confirmar hallazgo?',
      message: `¿Estás seguro de avisar a ${ownerName} que encontraste a ${marker.nombre}?`,
      buttons: [
        { text: 'No', role: 'cancel' },
        {
          text: 'Sí, avisar',
          handler: () => {
            addDoc(collection(firestore, 'mensajes'), {
              de: user.uid,
              para: marker.iduser,
              fecha: serverTimestamp(),
              mensaje: `${user.name} ha encontrado a ${marker.nombre}`,
            })
            .then(() => {
              presentAlert({ header: 'Aviso Enviado', message: `Mensaje enviado a ${ownerName}, podrán hablar por mensajes.`, buttons: ['OK'] });
            })
            .catch((error) => {
              console.error("Error al enviar el mensaje: ", error);
              presentAlert({ header: 'Error', message: 'No se pudo enviar el aviso. Por favor, inténtalo de nuevo.', buttons: ['OK'] });
            });
          },
        },
      ],
    });
  };

  const handleEsMiMascota = () => {
    if (!user || !user.name) {
      presentAlert({ header: 'Error', message: 'Debes iniciar sesión para realizar esta acción.', buttons: ['OK'] });
      return;
    }
    if (user.uid === marker?.iduser) {
      presentAlert({ header: 'Aviso', message: 'Este es tu propio reporte.', buttons: ['OK'] });
      return;
    }
    if (!marker || !ownerName) return;

    presentAlert({
      header: '¿Confirmar propiedad?',
      message: `¿Esta seguro que desea avisar a ${ownerName} que esta mascota le pertenece?`,
      buttons: [
        { text: 'No', role: 'cancel' },
        {
          text: 'Sí, avisar',
          handler: () => {
            addDoc(collection(firestore, 'mensajes'), {
              de: user.uid,
              para: marker.iduser,
              fecha: serverTimestamp(),
              mensaje: `${user.name} dice que la mascota que encontraste es suya`,
            })
            .then(() => {
              presentAlert({ header: 'Aviso Enviado', message: `Mensaje enviado a ${ownerName}, podrán hablar por mensajes.`, buttons: ['OK'] });
            })
            .catch((error) => {
              console.error("Error al enviar el mensaje: ", error);
              presentAlert({ header: 'Error', message: 'No se pudo enviar el aviso. Por favor, inténtalo de nuevo.', buttons: ['OK'] });
            });
          },
        },
      ],
    });
  };

  // Función para borrar marcador y comentarios asociados
  const handleCerrarReporte = () => {
      if (!marker) return;

      presentAlert({
        header: 'Confirmar Cierre',
        message: '¿Está seguro que desea cerrar este reporte? Esta acción no se puede deshacer.',
        buttons: [
            { text: 'Cancelar', role: 'cancel' },
            {
                text: 'Sí, cerrar',
                handler: () => {
                    const markerRef = doc(firestore, 'marcadores', marker.id);
                    const commentsQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', marker.id));

                    getDocs(commentsQuery)
                        .then(commentsSnapshot => {
                            const batch = writeBatch(firestore);
                            
                            commentsSnapshot.forEach(commentDoc => {
                                batch.delete(commentDoc.ref);
                            });
                            
                            batch.delete(markerRef);
                            
                            return batch.commit();
                        })
                        .then(() => {
                            presentAlert({
                                header: 'Reporte Cerrado',
                                message: 'El reporte y sus comentarios han sido eliminados.',
                                buttons: ['OK']
                            });
                            onClose(); // Cierra el modal principal
                        })
                        .catch(error => {
                            console.error("Error al cerrar el reporte: ", error);
                            presentAlert({
                                header: 'Error',
                                message: 'No se pudo cerrar el reporte. Por favor, inténtalo de nuevo.',
                                buttons: ['OK']
                            });
                        });
                }
            }
        ]
    });
  };

  const goToProfile = (userId: string) => {
    if (userId) {
        handleClose();
        history.push(`/perfil/${userId}`);
    }
  };

  const handleClose = () => {
    setNuevoComentario('');
    onClose();
  }

  const handleModModalClose = () => {
    setIsModModalOpen(false);
    handleClose();
  }

  const handleAportarDatoClose = (submitted: boolean) => {
    setIsAportarDatoModalOpen(false);
    if (submitted) {
      presentAlert({
        header: '¡Gracias!',
        message: 'Dato enviado, gracias por ayudar a la comunidad, usted ha ganado 1 PetPunto',
        buttons: ['OK'],
      });
    }
  }

  const formatCommentDate = (c_fecha: any): string => {
    if (c_fecha && typeof c_fecha.toDate === 'function') {
      return new Date(c_fecha.toDate()).toLocaleString();
    }
    if (c_fecha instanceof Date) {
        return c_fecha.toLocaleString();
    }
    return '';
  };

  const formatDate = (dateString: string | number | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', { 
      day: '2-digit', 
      month: 'long', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isMascota = marker?.tipo === 'mascota';
  const isPerdida = marker?.tipo === 'mascota' && marker?.tipo_r === 'Mascota Perdida';
  const isEncontrada = marker?.tipo === 'mascota' && marker?.tipo_r === 'Mascota Encontrada';
  const isOwner = user?.uid === marker?.iduser;

  return (
    <>
      <IonModal isOpen={isOpen} onDidDismiss={handleClose} className="ver-marcador-modal">
        {/* Header */}
        <IonHeader className="ion-no-border">
          <IonToolbar className="marcador-toolbar">
            <div className="marcador-header">
              <IonTitle className="marcador-title">
                {isMascota ? marker.tipo_r : marker?.nombre}
              </IonTitle>
              <IonButton fill="clear" onClick={handleClose} className="close-btn-marcador">
                <IonIcon icon={close} />
              </IonButton>
            </div>
          </IonToolbar>
        </IonHeader>

        <IonContent className="marcador-content">
          {/* Hero Image */}
          <div className="hero-image-container">
            <img src={marker?.foto} alt={marker?.nombre} className="hero-image" />
            <div className="hero-overlay">
              {isMascota && (
                <IonBadge className={`status-badge ${isPerdida ? 'perdida' : 'encontrada'}`}>
                  <IonIcon icon={isPerdida ? alertCircleOutline : checkmarkCircleOutline} />
                  {marker.tipo_r}
                </IonBadge>
              )}
            </div>
          </div>

          <div className="marcador-body">
            {/* Title Card */}
            <IonCard className="title-card">
              <IonCardContent className="title-content">
                <h2 className="marcador-name">{isMascota ? marker.tipo_r : marker?.nombre}</h2>
                
                <div className="info-chips">
                  {marker?.direccion && (
                    <IonChip className="info-chip">
                      <IonIcon icon={locationOutline} />
                      <span>{marker?.direccion.split(',')[0]}</span>
                    </IonChip>
                  )}
                  {isMascota && marker.fecha && (
                    <IonChip className="info-chip">
                      <IonIcon icon={calendarOutline} />
                      <span>{formatDate(marker.fecha).split(' ')[0]}</span>
                    </IonChip>
                  )}
                </div>
              </IonCardContent>
            </IonCard>

            {/* Details Card */}
            <IonCard className="details-card">
              <IonCardContent className="details-content">
                <div className="section-header">
                  <IonIcon icon={informationCircleOutline} className="section-icon" />
                  <h3>Información</h3>
                </div>

                {marker?.direccion && (
                  <div className="detail-item">
                    <IonIcon icon={locationOutline} className="detail-icon" />
                    <div className="detail-text">
                      <span className="detail-label">Dirección</span>
                      <p>{marker.direccion}</p>
                    </div>
                  </div>
                )}

                {isMascota && marker.fecha && (
                  <div className="detail-item">
                    <IonIcon icon={calendarOutline} className="detail-icon" />
                    <div className="detail-text">
                      <span className="detail-label">Fecha</span>
                      <p>{formatDate(marker.fecha)}</p>
                    </div>
                  </div>
                )}

                {marker?.descripcion && (
                  <div className="detail-item">
                    <IonIcon icon={informationCircleOutline} className="detail-icon" />
                    <div className="detail-text">
                      <span className="detail-label">Descripción</span>
                      <p>{marker.descripcion}</p>
                    </div>
                  </div>
                )}

                {/* Pet Details */}
                {isMascota && (
                  <div className="pet-details-box">
                    <div className="pet-detail-row">
                      <div className="pet-detail-item">
                        <IonIcon icon={pawOutline} />
                        <div>
                          <span className="pet-detail-label">Animal</span>
                          <p>{marker.animal}</p>
                        </div>
                      </div>
                      <div className="pet-detail-item">
                        <span className="pet-detail-label">Nombre</span>
                        <p>{marker.nombre}</p>
                      </div>
                    </div>
                    <div className="pet-detail-row">
                      <div className="pet-detail-item">
                        <span className="pet-detail-label">Color</span>
                        <p>{marker.color}</p>
                      </div>
                      <div className="pet-detail-item">
                        <span className="pet-detail-label">Tamaño</span>
                        <p>{marker.tamano}</p>
                      </div>
                    </div>
                  </div>
                )}
              </IonCardContent>
            </IonCard>

            {/* Action Buttons */}
            {isMascota && (
              <div className="action-buttons-container">
                {isPerdida && (
                  <>
                    <IonButton 
                      expand="block" 
                      className="action-btn primary"
                      onClick={() => setIsAportarDatoModalOpen(true)}
                    >
                      <IonIcon icon={informationCircleOutline} slot="start" />
                      Aportar Dato
                    </IonButton>
                    <IonButton 
                      expand="block" 
                      className="action-btn secondary"
                      onClick={handleMascotaEncontrada}
                    >
                      <IonIcon icon={checkmarkCircleOutline} slot="start" />
                      Mascota Encontrada
                    </IonButton>
                  </>
                )}
                
                {isEncontrada && (
                  <>
                    <IonButton 
                      expand="block" 
                      className="action-btn primary"
                      onClick={() => setIsAportarDatoModalOpen(true)}
                    >
                      <IonIcon icon={informationCircleOutline} slot="start" />
                      Aportar Dato
                    </IonButton>
                    <IonButton 
                      expand="block" 
                      className="action-btn success"
                      onClick={handleEsMiMascota}
                    >
                      <IonIcon icon={pawOutline} slot="start" />
                      Es Mi Mascota
                    </IonButton>
                  </>
                )}
              </div>
            )}

            {/* Comments Section */}
            <IonCard className="comments-card">
              <IonCardContent className="comments-content">
                <div className="section-header">
                  <IonIcon icon={chatbubblesOutline} className="section-icon" />
                  <h3>Comentarios</h3>
                  <IonBadge className="comments-count">{comentarios.length}</IonBadge>
                </div>

                <div className="comments-list">
                  {comentarios.map((comentario) => (
                    <div key={comentario.id} className="comment-item">
                      <IonAvatar className="comment-avatar" onClick={() => goToProfile(comentario.iduser)} style={{ cursor: 'pointer' }}>
                        <img src={comentario.avatar} alt={comentario.nombre} />
                      </IonAvatar>
                      <div className="comment-content">
                        <div className="comment-header">
                          <span className="comment-author">{comentario.nombre}</span>
                          <span className="comment-date">
                            {formatCommentDate(comentario.c_fecha)}
                          </span>
                        </div>
                        <p className="comment-text">{comentario.cuerpo}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* New Comment */}
                {user && (
                  <div className="new-comment-box">
                    <IonAvatar className="current-user-avatar" onClick={() => goToProfile(user.uid)} style={{ cursor: 'pointer' }}>
                      <img src={user.fotouser} alt={user.name} />
                    </IonAvatar>
                    <div className="comment-input-container">
                      <IonTextarea
                        placeholder="Escribe un comentario..."
                        value={nuevoComentario}
                        onIonChange={e => setNuevoComentario(e.detail.value!)}
                        className="comment-textarea"
                        autoGrow
                        rows={1}
                      />
                      <IonButton
                        fill="clear"
                        className="send-comment-btn"
                        onClick={handlePostComentario}
                        disabled={!nuevoComentario.trim()}
                      >
                        <IonIcon icon={sendOutline} />
                      </IonButton>
                    </div>
                  </div>
                )}
              </IonCardContent>
            </IonCard>

            {/* Close Report Button (Owner Only) */}
            {isOwner && isMascota && (
              <IonButton
                expand="block"
                fill="outline"
                className="close-report-btn"
                onClick={handleCerrarReporte}
              >
                Cerrar Reporte
              </IonButton>
            )}

            <div style={{ height: '20px' }}></div>
          </div>
        </IonContent>

        {isAportarDatoModalOpen && (
          <AportarDato
            onClose={handleAportarDatoClose}
            markerId={marker?.id || null}
            markerNombre={marker?.nombre || null}
            markerFecha={(marker && 'fecha' in marker) ? marker.fecha : null}
          />
        )}
      </IonModal>

      <ModMarcador 
          isOpen={isModModalOpen}
          onClose={handleModModalClose}
          markerId={marker?.id || null}
      />
    </>
  );
};

export default VerMarcador;
