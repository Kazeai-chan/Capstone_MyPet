
import React, { useState, useRef, useEffect, useContext, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonTitle, IonButton, IonContent, 
  IonItem, IonInput, IonLabel, IonSelect, IonSelectOption,
  IonAlert, IonProgressBar, useIonAlert, IonTextarea,
  IonCard,
  IonCardContent,
  IonIcon
} from '@ionic/react';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import './ModMarcador.css';

import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { doc, getDoc, updateDoc, collection, getDocs, query, where, runTransaction } from "firebase/firestore";
import { UserContext, UserContextType } from '../context/UserContext';
import { firestore } from '../firebase';
import { camera, checkmarkCircle, close, documentTextOutline, imageOutline, locationOutline, pencilOutline, storefrontOutline, trashOutline } from 'ionicons/icons';

const ASPECT_RATIO = 4 / 3;
const placeholderImage = 'https://via.placeholder.com/400x300?text=Sin+Foto';


interface ModMarcadorProps {
  isOpen: boolean;
  onClose: () => void;
  markerId: string | null;
}

interface Marcador {
  id: string; lat: number; lng: number; nombre: string; direccion: string; foto: string;
  descripcion: string; tipo: string; iduser: string;
}

const ModMarcador: React.FC<ModMarcadorProps> = ({ isOpen, onClose, markerId }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [marcador, setMarcador] = useState<Partial<Marcador>>({});
  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [uploadPercent, setUploadPercent] = useState(0);
  const [presentAlert] = useIonAlert();

  const imgRef = useRef<HTMLImageElement | null>(null);
  const originalFotoUrlRef = useRef<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showCropSection, setShowCropSection] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);

  const resetAndClose = useCallback(() => {
    setMarcador({});
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setShowCropSection(false);
    setUploadPercent(0);
    originalFotoUrlRef.current = null;
    onClose();
  }, [onClose]);

  useEffect(() => {
    const fetchMarkerData = async () => {
      if (!markerId) return;
      const docRef = doc(firestore, "marcadores", markerId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const markerData = { id: docSnap.id, ...docSnap.data() } as Marcador;
        setMarcador(markerData);
        originalFotoUrlRef.current = markerData.foto;
      } else {
        presentAlert({ header: 'Error', message: 'No se encontró el marcador.', buttons: ['OK'] });
        resetAndClose();
      }
    };

    if (isOpen) {
        fetchMarkerData();
    }
  }, [markerId, isOpen, presentAlert, resetAndClose]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
        setCrop(undefined);
        const reader = new FileReader();
        reader.addEventListener('load', () => setSrc(reader.result?.toString() || null));
        reader.readAsDataURL(e.target.files[0]);
        setShowCropSection(true);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    imgRef.current = e.currentTarget;
  };

  const handleUploadImage = useCallback(() => {
    if (!completedCrop || !imgRef.current || !user?.uid) return;

    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(image, completedCrop.x, completedCrop.y, completedCrop.width, completedCrop.height, 0, 0, canvas.width, canvas.height);
    
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const filePath = `uploads/${user.uid}_${Date.now()}.png`;
      const storageRef = ref(getStorage(), filePath);
      const uploadTask = uploadBytesResumable(storageRef, blob);

      uploadTask.on('state_changed',
          (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
          (error) => presentAlert({ header: 'Error al subir', message: error.message, buttons: ['OK']}),
          async () => {
              const url = await getDownloadURL(storageRef);
              setMarcador(prev => ({ ...prev, foto: url }));
              presentAlert({ header: 'Éxito', message: 'Imagen actualizada. Guarde los cambios para aplicarla.', buttons: ['OK']});
              setShowCropSection(false);
              setSrc(null); // Clear preview
          }
      );
    }, 'image/png', 1);
  }, [completedCrop, user, presentAlert]);

  const handleUpdate = async () => {
    if (!markerId || !marcador || !marcador.nombre || !marcador.direccion || !marcador.tipo || !marcador.descripcion) {
        presentAlert({ header: 'Error', message: 'Debe llenar todos los campos.', buttons: ['OK'] });
        return;
    }
    try {
        if (marcador.foto !== originalFotoUrlRef.current && originalFotoUrlRef.current) {
            const oldPhotoRef = ref(getStorage(), originalFotoUrlRef.current);
            await deleteObject(oldPhotoRef).catch(err => console.error("Error al borrar imagen antigua:", err));
        }
        const markerRef = doc(firestore, "marcadores", markerId);
        const { id, ...markerData } = marcador;
        await updateDoc(markerRef, markerData);
        presentAlert({ header: 'Correcto', message: 'Marcador Modificado', buttons: ['OK']});
        resetAndClose();
    } catch (e) {
        presentAlert({ header: 'Error', message: 'No se pudo actualizar el marcador.', buttons: ['OK']});
    }
  };

  const handleDelete = async () => {
    if (!markerId || !user?.correo) return;

    try {
      // Transaction to ensure all or nothing deletion
      await runTransaction(firestore, async (transaction) => {
        const markerRef = doc(firestore, "marcadores", markerId);
        const creatorRef = doc(firestore, "creadores", user.correo!);

        // 1. Delete associated comments
        const commentsQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', markerId));
        const commentsSnapshot = await getDocs(commentsQuery);
        commentsSnapshot.docs.forEach(doc => transaction.delete(doc.ref));

        // 2. Decrement creator's marker count
        const creatorDoc = await transaction.get(creatorRef);
        if (creatorDoc.exists()) {
          const currentCount = creatorDoc.data().marcadores || 0;
          transaction.update(creatorRef, { marcadores: Math.max(0, currentCount - 1) });
        }

        // 3. Delete the marker itself
        transaction.delete(markerRef);
      });

      // 4. Delete the photo from storage (outside the transaction)
      if (marcador.foto) {
        const fileRef = ref(getStorage(), marcador.foto);
        await deleteObject(fileRef).catch(err => console.warn("La imagen no existía o ya fue borrada:", err));
      }

      presentAlert({ header: 'Eliminado', message: 'Marcador eliminado correctamente', buttons: ['OK']});
      resetAndClose();

    } catch (error) {
      console.error("Transaction failed: ", error);
      presentAlert({ header: 'Error', message: 'No se pudo eliminar el marcador.', buttons: ['OK']});
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="mod-marcador-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="marcador-toolbar">
          <div className="marcador-header">
            <div className="header-title-section">
              <IonIcon icon={pencilOutline} className="header-icon-marcador" />
              <IonTitle className="marcador-title">Modificar Marcador</IonTitle>
            </div>
            <IonButton fill="clear" onClick={resetAndClose} className="close-btn-marcador">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="marcador-content">
        {/* Sección de Foto */}
        <div className="photo-upload-section-marcador">
          <div className="photo-preview-container-marcador">
            <div className="photo-preview-marcador landscape">
              <img 
                src={marcador.foto || placeholderImage} 
                alt="Marcador" 
                className={marcador.foto ? 'has-photo' : 'placeholder'}
              />
            </div>
            
            {!marcador.foto && (
              <div className="upload-prompt-marcador">
                <IonIcon icon={imageOutline} className="upload-icon-marcador" />
                <p>Foto del lugar</p>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />

          <IonButton
            fill="clear"
            className="select-photo-btn-marcador"
            onClick={() => fileInputRef.current?.click()}
          >
            <IonIcon icon={camera} slot="start" />
            {marcador.foto ? 'Cambiar Foto' : 'Seleccionar Foto'}
          </IonButton>
        </div>

        {/* Sección de Recorte */}
        {showCropSection && src && (
          <div className="crop-section-marcador">
            <div className="crop-header-marcador">
              <IonIcon icon={imageOutline} />
              <span>Recorta la imagen a tu gusto</span>
            </div>
            
            <div className="crop-container-marcador">
              <ReactCrop 
                crop={crop} 
                onChange={c => setCrop(c)} 
                onComplete={c => setCompletedCrop(c)} 
                aspect={ASPECT_RATIO}
                minWidth={100}
              >
                <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image-marcador" />
              </ReactCrop>
            </div>

            {uploadPercent > 0 && (
              <div className="upload-progress-container-marcador">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar-marcador" />
                <span className="progress-text-marcador">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}

            <IonButton
              expand="block"
              className="confirm-crop-btn-marcador"
              onClick={handleUploadImage} 
              disabled={uploadPercent > 0}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Subir Foto
            </IonButton>
          </div>
        )}

        {/* Formulario */}
        <IonCard className="form-card-marcador">
          <IonCardContent className="form-content-marcador">
            <h4 className="form-section-title-marcador">
              <IonIcon icon={documentTextOutline} />
              Información del Lugar
            </h4>

            <div className="form-group-marcador">
              <IonItem className="custom-item-marcador" lines="none">
                <IonIcon icon={storefrontOutline} slot="start" className="item-icon-marcador" />
                <IonLabel position="stacked" className="custom-label-marcador">
                  Nombre del Marcador <span className="required">*</span>
                </IonLabel>
                <IonInput
                  value={marcador.nombre}
                  onIonInput={e => setMarcador(p => ({...p, nombre: e.detail.value!}))}
                  placeholder="Ingresa el nombre"
                  className="custom-input-marcador"
                />
              </IonItem>
            </div>

            <div className="form-group-marcador">
              <IonItem className="custom-item-marcador" lines="none">
                <IonIcon icon={locationOutline} slot="start" className="item-icon-marcador" />
                <IonLabel position="stacked" className="custom-label-marcador">
                  Dirección
                </IonLabel>
                <IonInput
                  value={marcador.direccion}
                  //onIonInput={e => handleInputChange('direccion', e.detail.value!)}
                  onIonChange={e => setMarcador(p => ({...p, nombre: e.detail.value!}))}
                  placeholder="Ingresa la dirección"
                  className="custom-input-marcador"
                />
              </IonItem>
            </div>

            <div className="form-group-marcador">
              <IonItem className="custom-item-marcador" lines="none">
                <IonIcon icon={storefrontOutline} slot="start" className="item-icon-marcador" />
                <IonLabel position="stacked" className="custom-label-marcador">
                  Tipo <span className="required">*</span>
                </IonLabel>
                <IonSelect
                  value={marcador.tipo}
                  //onIonChange={e => handleInputChange('tipo', e.detail.value!)}
                  onIonChange={e => setMarcador(p => ({...p, tipo: e.detail.value}))} 
                  interface="action-sheet"
                  placeholder="Selecciona el tipo"
                  className="custom-select-marcador"
                >
                  <IonSelectOption value="Tienda">Tienda</IonSelectOption>
                  <IonSelectOption value="Veterinaria">Veterinaria</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-marcador">
              <IonItem className="custom-item-marcador textarea-item" lines="none">
                <IonLabel position="stacked" className="custom-label-marcador">
                  Descripción
                </IonLabel>
                <IonTextarea
                  value={marcador.descripcion}
                  onIonInput={e => setMarcador(p => ({...p, descripcion: e.detail.value!}))}
                  placeholder="Describe el lugar"
                  className="custom-textarea-marcador"
                  autoGrow
                  rows={3}
                />
              </IonItem>
            </div>
          </IonCardContent>
        </IonCard>

        {/* Botones de Acción */}
        <div className="action-buttons-container-marcador">
          <IonButton
            expand="block"
            className="save-btn-marcador"
            onClick={handleUpdate}
          >
            <IonIcon icon={checkmarkCircle} slot="start" />
            Guardar Cambios
          </IonButton>

          <IonButton
            expand="block"
            className="delete-btn-marcador"
            onClick={() => setShowDeleteAlert(true)}
          >
            <IonIcon icon={trashOutline} slot="start" />
            Eliminar Marcador
          </IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>

      {/* Alert de Confirmación */}
      <IonAlert
        isOpen={showDeleteAlert}
        onDidDismiss={() => setShowDeleteAlert(false)}
        header="¿Está Seguro?"
        message="Esta acción eliminará permanentemente este marcador"
        buttons={[
          {
            text: 'Cancelar',
            role: 'cancel',
            cssClass: 'alert-button-cancel',
          },
          {
            text: 'Eliminar',
            role: 'confirm',
            cssClass: 'alert-button-confirm',
            handler: handleDelete,
          },
        ]}
        cssClass="custom-alert-marcador"
      />
    </IonModal>
  );
};

export default ModMarcador;
