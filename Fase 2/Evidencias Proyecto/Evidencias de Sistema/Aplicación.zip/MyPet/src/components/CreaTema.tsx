
import React, { useState, useContext } from 'react';
import { IonHeader, IonToolbar, IonTitle, IonButtons, IonButton, IonContent, IonInput, IonTextarea, IonIcon, IonProgressBar, IonSpinner } from '@ionic/react';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { addDoc, collection, doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';

import './CreaTema.css';
import { chatbubbleEllipsesOutline, checkmarkCircle, close, cloudUploadOutline, createOutline, imageOutline, trashOutline } from 'ionicons/icons';

interface CreaTemaResult {
  status: 'created' | 'blocked' | 'closed';
}

interface CreaTemaProps {
  onClose: (result?: CreaTemaResult) => void;
}

export const CreaTema: React.FC<CreaTemaProps> = ({ onClose }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [tema, setTema] = useState({
    titulo: '',
    cuerpo: '',
    foto: '',
  });
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isCategorizing, setIsCategorizing] = useState(false);

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    setTema({ ...tema, [name]: value });
  };

  const fileChangeEvent = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = () => {
        setPreviewImage(reader.result as string);
        setUploadComplete(false);
      };
    }
  };

  const uploadImage = async () => {
    if (!previewImage) {
      alert('Debe seleccionar un archivo');
      return;
    }

    setIsUploading(true);
    setUploadPercent(0);

    const storage = getStorage();
    const filePath = `uploads/${Date.now()}_${user?.uid}`;
    const storageRef = ref(storage, filePath);

    const response = await fetch(previewImage);
    const blob = await response.blob();

    const uploadTask = uploadBytesResumable(storageRef, blob);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        setUploadPercent(Math.round(percent));
      },
      (error) => {
        console.error('Error al subir archivo:', error);
        alert('No se pudo subir la imagen');
        setIsUploading(false);
      },
      async () => {
        const url = await getDownloadURL(storageRef);
        setTema(prevTema => ({ ...prevTema, foto: url }));
        setIsUploading(false);
        setUploadComplete(true);
      }
    );
  };

  const creaTema = async () => {
    if (tema.titulo.trim() === '' || tema.cuerpo.trim() === '') {
      alert('Debe llenar todos los campos o ingresar datos válidos');
      return;
    }
    
    if (previewImage && !uploadComplete) {
      alert('Por favor, primero carga la imagen seleccionada antes de publicar.');
      return;
    }

    setIsCategorizing(true);

    let category = 'Off Topic / Otros temas';

    try {
      const response = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/categorizeForumPost', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: tema.titulo,
          text: tema.cuerpo,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        category = data.category;
      } else {
        console.warn('La categorización automática falló. Se usará una categoría por defecto.');
      }
    } catch (apiError) {
      console.error('Error llamando a la función de categorización:', apiError);
    }

    const isBlocked = category === "Contenido inapropiado o dañino";

    try {
      const newTemaData = {
        ...tema,
        categoria: category,
        visible: !isBlocked,
        avatar: user?.fotouser,
        c_avatar: 'https://ionicframework.com/docs/img/demos/avatar.svg',
        c_nombre: '',
        comentario: 'Sin Comentarios aún',
        fecha: serverTimestamp(),
        iduser: user?.uid,
        n_com: 0,
        n_gusta: 0,
        nombreuser: user?.name,
      };

      const newTemaRef = await addDoc(collection(firestore, 'temas'), newTemaData);

      if (isBlocked) {
        await addDoc(collection(firestore, 'notificaciones'), {
            userId: user?.uid,
            fromId: 'sistema',
            type: 'warning',
            title: 'Contenido Bloqueado',
            body: 'Tu publicación en el foro fue eliminada por ser catalogada como inapropiada o dañina. La reincidencia puede llevar a la suspensión de tu cuenta.',
            createdAt: serverTimestamp(),
            read: false,
            icon: '⚠️',
            link: '/foro'
        });
      } else {
        try {
            const expertCommentResponse = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/generateExpertComment', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                category: category,
                title: tema.titulo,
                text: tema.cuerpo,
              }),
            });
      
            if (expertCommentResponse.ok) {
              const expertCommentData = await expertCommentResponse.json();
              const expertCommentText = expertCommentData.comment;
      
              if (expertCommentText && expertCommentText.trim() !== '') {
                const expertUser = {
                    id: 'mypet-expert',
                    nombre: 'Experto MyPet',
                    avatar: 'https://instant-vent-423002-f1.web.app/logo512.png' 
                };
                
                // Using correct field names as identified from TemaPage.tsx
                const commentsCollectionRef = collection(firestore, 'comentarios');
                await addDoc(commentsCollectionRef, {
                  idtema: newTemaRef.id,
                  c_cuerpo: expertCommentText,
                  c_fecha: serverTimestamp(),
                  c_iduser: expertUser.id,
                  c_nombre: expertUser.nombre,
                  c_avatar: expertUser.avatar,
                });
      
                const temaDocRef = doc(firestore, 'temas', newTemaRef.id);
                await updateDoc(temaDocRef, {
                  n_com: 1,
                  c_nombre: expertUser.nombre,
                  comentario: expertCommentText,
                  c_avatar: expertUser.avatar,
                });
              }
            }
        } catch (commentError) {
            console.error('Error in expert comment flow:', commentError);
        }
      }
      
      onClose({ status: isBlocked ? 'blocked' : 'created' });

    } catch (error) {
      console.error("Error al crear el tema o la notificación:", error);
      alert("Hubo un error al procesar tu publicación.");
      setIsCategorizing(false);
    }
  };

  const removeImage = () => {
    setPreviewImage(null);
    setUploadPercent(0);
    setUploadComplete(false);
    setIsUploading(false);
    setTema({ ...tema, foto: '' });
  };

  const isFormValid = tema.titulo.trim() && tema.cuerpo.trim();

  return (
    <>
      <IonHeader className="crear-tema-header-modern">
        <IonToolbar className="crear-tema-toolbar-modern">
          <div className="crear-tema-header-content">
            <div className="header-icon-wrapper-tema">
              <IonIcon icon={createOutline} className="header-icon-tema" />
              <div className="header-paw-mini">🐾</div>
            </div>
            <IonTitle className="crear-tema-title-modern">Crear Nuevo Tema</IonTitle>
          </div>
          <IonButtons slot="end">
            <IonButton onClick={() => onClose({ status: 'closed' })} className="close-btn-crear-modern">
              <IonIcon icon={close} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="crear-tema-content-modern">
        <div className="crear-tema-container-modern">
          {/* Sección de Título */}
          <div className="form-section-modern">
            <div className="section-header-modern">
              <div className="section-icon-badge">
                <IonIcon icon={chatbubbleEllipsesOutline} />
              </div>
              <div className="section-text">
                <h3 className="section-title-modern">Título del Tema</h3>
                <p className="section-subtitle-modern">Haz una pregunta o comparte tu experiencia</p>
              </div>
            </div>

            <div className="input-wrapper-modern">
              <IonInput
                name="titulo"
                value={tema.titulo}
                onIonInput={handleInputChange}
                placeholder="Ej: ¿Cómo cuido a mi cachorro?"
                className="input-modern-tema"
                maxlength={100}
              />
              <div className="input-counter">
                {tema.titulo.length}/100
              </div>
            </div>
          </div>

          {/* Sección de Descripción */}
          <div className="form-section-modern">
            <div className="section-header-modern">
              <div className="section-icon-badge">
                <IonIcon icon={createOutline} />
              </div>
              <div className="section-text">
                <h3 className="section-title-modern">Descripción</h3>
                <p className="section-subtitle-modern">Detalla tu situación o pregunta</p>
              </div>
            </div>

            <div className="textarea-wrapper-modern">
              <IonTextarea
                name="cuerpo"
                value={tema.cuerpo}
                onIonInput={handleInputChange}
                placeholder="Comparte tu historia, pregunta o consejo con la comunidad MyPet..."
                className="textarea-modern-tema"
                autoGrow
                rows={6}
                maxlength={1000}
              />
              <div className="textarea-counter-modern">
                {tema.cuerpo.length}/1000
              </div>
            </div>
          </div>

          {/* Sección de Imagen */}
          <div className="form-section-modern">
            <div className="section-header-modern">
              <div className="section-icon-badge">
                <IonIcon icon={imageOutline} />
              </div>
              <div className="section-text">
                <h3 className="section-title-modern">Imagen (Opcional)</h3>
                <p className="section-subtitle-modern">Las imágenes obtienen más atención</p>
              </div>
            </div>

            {!previewImage ? (
              <label className="upload-area-modern" htmlFor="file-upload-tema">
                <input
                  id="file-upload-tema"
                  type="file"
                  accept="image/*"
                  onChange={fileChangeEvent}
                  style={{ display: 'none' }}
                />
                <div className="upload-content-modern">
                  <div className="upload-icon-circle">
                    <IonIcon icon={imageOutline} className="upload-icon-modern" />
                  </div>
                  <h4 className="upload-title-modern">Agregar imagen</h4>
                  <p className="upload-text-modern">Toca para elegir desde tu galería</p>
                  <div className="upload-formats-modern">JPG, PNG o GIF • Máx. 5MB</div>
                </div>
                <div className="upload-decoration">
                  <div className="deco-paw">🐾</div>
                </div>
              </label>
            ) : (
              <div className="image-preview-container-modern">
                <div className="image-preview-modern">
                  <img src={previewImage} alt="Preview" className="preview-img-modern" />
                  {uploadComplete && (
                    <div className="upload-success-badge-modern">
                      <IonIcon icon={checkmarkCircle} />
                      <span>Imagen lista</span>
                    </div>
                  )}
                </div>

                {isUploading && (
                  <div className="upload-progress-modern">
                    <IonProgressBar value={uploadPercent / 100} className="progress-bar-tema" />
                    <span className="progress-text-tema">Subiendo... {uploadPercent}%</span>
                  </div>
                )}

                <div className="image-actions-modern">
                  {!uploadComplete && !isUploading && (
                    <IonButton
                      onClick={uploadImage}
                      className="btn-upload-tema"
                      expand="block"
                    >
                      <IonIcon icon={cloudUploadOutline} slot="start" />
                      Cargar Imagen
                    </IonButton>
                  )}

                  <IonButton
                    onClick={removeImage}
                    className="btn-remove-tema"
                    fill="clear"
                    disabled={isUploading}
                  >
                    <IonIcon icon={trashOutline} slot="start" />
                    Eliminar
                  </IonButton>
                </div>
              </div>
            )}
          </div>

          {/* Botón de Publicar */}
          <div className="form-actions-modern">
            <IonButton
              onClick={creaTema}
              disabled={!isFormValid || isUploading || isCategorizing}
              className="btn-publicar-tema"
              expand="block"
              size="large"
            >
              {isCategorizing ? (
                <>
                  <IonSpinner name="circular" className="spinner-publicando" />
                  Publicando...
                </>
              ) : (
                <>
                  <IonIcon icon={checkmarkCircle} slot="start" />
                  Publicar Tema
                </>
              )}
            </IonButton>
            <p className="helper-text-modern">
              * Asegúrate de completar título y descripción
            </p>
          </div>
        </div>

        {/* Decoración de patitas */}
        <div className="bg-decoration-tema">
          <div className="bg-paw-tema paw-1">🐾</div>
          <div className="bg-paw-tema paw-2">🐾</div>
        </div>
      </IonContent>
    </>
  );
};
