
import React, { useState, useContext } from 'react';
import { IonHeader, IonToolbar, IonTitle, IonButtons, IonButton, IonContent, IonInput, IonTextarea, IonIcon, IonProgressBar } from '@ionic/react';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { addDoc, collection } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
//import ImageCropper from 'react-easy-crop';

import './CreaTema.css';
import { checkmarkCircle, close, cloudUploadOutline, imageOutline, trashOutline } from 'ionicons/icons';

interface CreaTemaProps {
  onClose: () => void;
}

export const CreaTema: React.FC<CreaTemaProps> = ({ onClose }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [tema, setTema] = useState({
    titulo: '',
    cuerpo: '',
    foto: '',
  });
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [isUploading, setIsUploading] = useState(false);



  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    setTema({ ...tema, [name]: value });
  };

  const fileChangeEvent = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = () => {
        setPreviewImage(reader.result as string);
      };
    }
  };

  const uploadImage = async () => {
    if (!previewImage) {
      alert('Debe seleccionar un archivo');
      return;
    }

    setIsUploading(true);
    setUploadPercent(0);

    const storage = getStorage();
    const filePath = `uploads/${Date.now()}_${user?.uid}`;
    const storageRef = ref(storage, filePath);

    const response = await fetch(previewImage);
    const blob = await response.blob();

    const uploadTask = uploadBytesResumable(storageRef, blob);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        setUploadPercent(percent);
      },
      (error) => {
        console.error('Error al subir archivo:', error);
        alert('No se pudo subir la imagen');
      },
      async () => {
        const url = await getDownloadURL(storageRef);
        setTema({ ...tema, foto: url });
      }
    );
  };

  const creaTema = async () => {
    if (tema.titulo.trim() === '' || tema.cuerpo.trim() === '') {
      alert('Debe llenar todos los campos o ingresar datos válidos');
      return;
    }

    try {
      const newTema = {
        ...tema,
        avatar: user?.fotouser,
        c_avatar: 'https://ionicframework.com/docs/img/demos/avatar.svg',
        c_nombre: '',
        comentario: 'Sin Comentarios aún',
        fecha: new Date(),
        iduser: user?.uid,
        n_com: 0,
        n_gusta: 0,
        nombreuser: user?.name,
      };

      await addDoc(collection(firestore, 'temas'), newTema);
      alert('Tema Creado');
      onClose();
    } catch (error) {
      console.error('Error creating document: ', error);
      alert('Error al crear el tema');
    }
  };

  const removeImage = () => {
    setPreviewImage(null);
    setUploadPercent(0);
    setUploadComplete(false);
    setTema({ ...tema, foto: '' });
  };

  const isFormValid = tema.titulo.trim() && tema.cuerpo.trim();

  return (
    <>
      <IonHeader className="crear-tema-header">
        <IonToolbar className="crear-tema-toolbar">
          <IonTitle className="crear-tema-title">Crear Nuevo Tema</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={onClose} className="close-btn-crear">
              <IonIcon icon={close} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="crear-tema-content">
        <div className="crear-tema-container">
          {/* Sección de Título */}
          <div className="form-section">
            <div className="section-header">
              <h3 className="section-title">Información del Tema</h3>
              <p className="section-subtitle">Comparte tu historia con la comunidad</p>
            </div>

            <div className="input-group">
              <label className="input-label">Título del Tema *</label>
              <IonInput
                name="titulo"
                value={tema.titulo}
                onIonInput={handleInputChange}
                placeholder="Ej: Mi perro necesita ayuda"
                className="input-modern"
                maxlength={100}
              />
              <div className="input-helper">
                {tema.titulo.length}/100 caracteres
              </div>
            </div>
          </div>

          {/* Sección de Imagen */}
          <div className="form-section">
            <div className="section-header">
              <h3 className="section-title">Imagen del Tema</h3>
              <p className="section-subtitle">Opcional, pero ayuda a captar la atención</p>
            </div>

            {!previewImage ? (
              <label className="upload-area" htmlFor="file-upload">
                <input
                  id="file-upload"
                  type="file"
                  accept="image/*"
                  onChange={fileChangeEvent}
                  style={{ display: 'none' }}
                />
                <div className="upload-content">
                  <div className="upload-icon-wrapper">
                    <IonIcon icon={imageOutline} className="upload-icon" />
                  </div>
                  <h4 className="upload-title">Seleccionar imagen</h4>
                  <p className="upload-text">Toca para elegir una foto desde tu galería</p>
                  <div className="upload-formats">JPG, PNG o GIF (máx. 5MB)</div>
                </div>
              </label>
            ) : (
              <div className="image-preview-container">
                <div className="image-preview">
                  <img src={previewImage} alt="Preview" className="preview-img" />
                  {uploadComplete && (
                    <div className="upload-success-badge">
                      <IonIcon icon={checkmarkCircle} />
                    </div>
                  )}
                </div>

                {isUploading && (
                  <div className="upload-progress">
                    <IonProgressBar value={uploadPercent / 100} className="progress-bar-modern" />
                    <span className="progress-text">Subiendo... {uploadPercent}%</span>
                  </div>
                )}

                <div className="image-actions">
                  {!uploadComplete && !isUploading && (
                    <IonButton
                      onClick={uploadImage}
                      className="btn-upload-image"
                      expand="block"
                    >
                      <IonIcon icon={cloudUploadOutline} slot="start" />
                      Cargar Imagen
                    </IonButton>
                  )}
                  
                  {uploadComplete && (
                    <div className="upload-complete-message">
                      <IonIcon icon={checkmarkCircle} />
                      <span>Imagen cargada correctamente</span>
                    </div>
                  )}

                  <IonButton
                    onClick={removeImage}
                    className="btn-remove-image"
                    fill="clear"
                  >
                    <IonIcon icon={trashOutline} slot="start" />
                    Eliminar
                  </IonButton>
                </div>
              </div>
            )}
          </div>

          {/* Sección de Descripción */}
          <div className="form-section">
            <div className="section-header">
              <h3 className="section-title">Descripción *</h3>
              <p className="section-subtitle">Explica tu situación o pregunta</p>
            </div>

            <div className="textarea-wrapper">
              <IonTextarea
                name="cuerpo"
                value={tema.cuerpo}
                onIonInput={handleInputChange}
                placeholder="Escribe aquí lo que desees compartir con la comunidad..."
                className="textarea-modern-crear"
                autoGrow
                rows={6}
                maxlength={1000}
              />
              <div className="textarea-counter">
                {tema.cuerpo.length}/1000 caracteres
              </div>
            </div>
          </div>

          {/* Botón de Guardar */}
          <div className="form-actions">
            <IonButton
              onClick={creaTema}
              disabled={!isFormValid}
              className="btn-guardar-tema"
              expand="block"
              size="large"
            >
              Publicar Tema
            </IonButton>
            <p className="action-helper">
              * Campos requeridos
            </p>
          </div>
        </div>
      </IonContent>
            {/*
      <IonContent>
        <IonHeader>
          <IonToolbar className="barra-inicio">
            <IonTitle>Crear Nuevo Tema</IonTitle>
            <IonButtons slot="end">
              <IonButton onClick={onClose}>Cerrar</IonButton>
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        <section className="seccion">
          <IonCard className="tarjeta">
            <IonCardHeader className="tarj-head">
              <IonCardTitle className="tarj-titulo">Ingrese los siguientes datos</IonCardTitle>
            </IonCardHeader>
            <IonCardContent className="contenido">
              <IonItem className="textos">
                <IonInput
                  label="Título del Tema"
                  labelPlacement="floating"
                  name="titulo"
                  value={tema.titulo}
                  onIonChange={handleInputChange}
                  placeholder="Ingrese título"
                ></IonInput>
              </IonItem>
              <p>Foto para el tema</p>
              <IonItem className="textos">
                <input type="file" accept="image/*" onChange={fileChangeEvent} />
              </IonItem>

              {previewImage && (
                <div style={{ position: 'relative', width: '100%', height: 400 }}>
                </div>
              )}

              <IonRow>
                <IonCol>
                  <IonButton style={{ '--background': '#5f7236' }} onClick={uploadImage} shape="round" expand="block" size="small">Cargar</IonButton>
                </IonCol>
              </IonRow>
              {uploadPercent > 0 && <div>Upload Progress: {uploadPercent}%</div>}
              <IonItem className="textos">
                <IonTextarea
                  name="cuerpo"
                  value={tema.cuerpo}
                  onIonChange={handleInputChange}
                  placeholder="Escriba lo que desee transmitir..."
                ></IonTextarea>
              </IonItem>
              <IonGrid>
                <IonRow>
                  <IonCol>
                    <IonButton style={{ '--background': '#5f7236' }} onClick={creaTema} shape="round" expand="block">Guardar</IonButton>
                  </IonCol>
                </IonRow>
              </IonGrid>
            </IonCardContent>
          </IonCard>
        </section>
      </IonContent>
      */}
    </>
  );
};
