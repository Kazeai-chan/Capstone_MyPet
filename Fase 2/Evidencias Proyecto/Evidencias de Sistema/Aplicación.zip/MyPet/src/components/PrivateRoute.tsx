
import React, { useContext } from 'react';
import { Route, Redirect, RouteProps } from 'react-router-dom';
import { IonPage, IonContent, IonSpinner } from '@ionic/react';
import { UserContext, UserContextType } from '../context/UserContext';

// Define the props for the PrivateRoute component.
// It accepts all standard RouteProps, but makes 'component' a required prop.
interface PrivateRouteProps extends Omit<RouteProps, 'component' | 'render'> {
  component: React.ComponentType<any>;
}

const PrivateRoute: React.FC<PrivateRouteProps> = ({ component: Component, ...rest }) => {
  const { user, loading } = useContext<UserContextType>(UserContext);

  // While checking for the user, show a loading spinner.
  if (loading) {
    return (
      <IonPage>
        <IonContent fullscreen style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <IonSpinner name="crescent" />
        </IonContent>
      </IonPage>
    );
  }

  return (
    <Route
      {...rest}
      render={props => {
        // If the user is not authenticated, redirect to the login page.
        if (!user) {
          return <Redirect to="/login" />;
        }

        // If authenticated, render the requested component.
        return <Component {...props} />;
      }}
    />
  );
};

export default PrivateRoute;
