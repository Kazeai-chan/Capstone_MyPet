
import React, { useState, useEffect, useContext } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonTitle, IonContent, IonButton,
  IonItem, IonLabel, IonSpinner, IonAccordion, IonAccordionGroup, IonAvatar,
  IonIcon,
  IonBadge,
  IonChip
} from '@ionic/react';
import { collection, query, where, onSnapshot, Timestamp } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import { format } from 'date-fns';
import './DatosModal.css';
import { calendarOutline, close, informationCircleOutline, pawOutline, personOutline, timeOutline } from 'ionicons/icons';

/*
interface Timestamp {
  seconds: number;
  nanoseconds: number;
}*/

interface Pista {
  id: string;
  idmarker: string;
  fecha: Timestamp;
  nombreUsuario: string;
  pista: string;
}

interface Marcador {
    id: string;
    fecha: Timestamp;
    foto?: string;
}

interface GroupedData {
  [idmarker: string]: {
    fecha: Timestamp;
    foto?: string;
    pistas: Pista[];
  };
}

interface DatosModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DatosModal: React.FC<DatosModalProps> = ({ isOpen, onClose }) => {
  const [groupedData, setGroupedData] = useState<GroupedData>({});
  const [loading, setLoading] = useState(true);
  const { user } = useContext<UserContextType>(UserContext);

  useEffect(() => {
    if (!isOpen || !user) {
      if(isOpen) setLoading(false);
      return;
    }

    setLoading(true);

    const markersQuery = query(
      collection(firestore, 'marcadores'),
      where('iduser', '==', user.uid),
      where('tipo', '==', 'mascota')
    );

    const unsubscribeMarkers = onSnapshot(markersQuery, (markerSnapshot) => {
      const markers = markerSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Marcador));
      const markerIds = markers.map(m => m.id);

      const baseGroups: GroupedData = {};
      for (const marker of markers) {
        baseGroups[marker.id] = { fecha: marker.fecha, foto: marker.foto, pistas: [] };
      }

      if (markerIds.length === 0) {
        setGroupedData({});
        setLoading(false);
        return;
      }

      const pistasQuery = query(collection(firestore, 'pistas'), where('idmarker', 'in', markerIds));
      
      const unsubscribePistas = onSnapshot(pistasQuery, (pistaSnapshot) => {
        // Hacemos una copia profunda manual para no perder los métodos de Timestamp
        const finalGroups: GroupedData = {};
        for (const markerId in baseGroups) {
          finalGroups[markerId] = {
            ...baseGroups[markerId]
          };
        }

        pistaSnapshot.docs.forEach(doc => {
          const pista = { id: doc.id, ...doc.data() } as Pista;
          if (finalGroups[pista.idmarker]) {
            finalGroups[pista.idmarker].pistas.push(pista);
          }
        });

        // CORRECCIÓN: Se añaden los tipos explícitos (a: Pista, b: Pista)
        for (const markerId in finalGroups) {
            finalGroups[markerId].pistas.sort((a: Pista, b: Pista) => {
                if (!a.fecha) return 1;
                if (!b.fecha) return -1;
                return b.fecha.seconds - a.fecha.seconds;
            });
        }

        setGroupedData(finalGroups);
        setLoading(false);
      });

      return () => unsubscribePistas();

    }, (error) => {
      console.error("Error al obtener los reportes (marcadores):", error);
      setLoading(false);
    });

    return () => unsubscribeMarkers();
  }, [isOpen, user]);

  const formatDate = (dateValue: Timestamp) => {
    if (!dateValue) return '';
    try {
        return format(dateValue.toDate(), 'dd/MM/yyyy');
    } catch {
        return 'fecha inválida';
    }
  };

  const getTimeAgo = (dateString: Timestamp) => {
    if (!dateString) return '';
    let date: Date;
    if (typeof dateString === 'string') {
        date = new Date(dateString);
    } else if (dateString && typeof dateString.toDate === 'function') {
        date = dateString.toDate();
    } else {
        return 'fecha inválida';
    }
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Hoy';
    if (diffDays === 1) return 'Ayer';
    if (diffDays < 7) return `Hace ${diffDays} días`;
    if (diffDays < 30) return `Hace ${Math.floor(diffDays / 7)} semanas`;
    return formatDate(dateString);
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={onClose} className="datos-modal">
      {/* Header */}
      <IonHeader className="ion-no-border">
        <IonToolbar className="datos-toolbar">
          <div className="datos-header">
            <div className="header-title-section">
              <IonIcon icon={informationCircleOutline} className="header-icon" />
              <IonTitle className="datos-title">Datos Recibidos</IonTitle>
            </div>
            <IonButton fill="clear" onClick={onClose} className="close-btn-datos">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="datos-content">
        {loading ? (
          <div className="loading-state">
            <IonSpinner name="crescent" className="loading-spinner-datos" />
            <p>Cargando reportes...</p>
          </div>
        ) : Object.keys(groupedData).length === 0 ? (
          <div className="empty-state-datos">
            <div className="empty-icon-circle">
              <IonIcon icon={pawOutline} className="empty-icon-datos" />
            </div>
            <h3>No hay reportes activos</h3>
            <p>No tienes reportes de mascotas perdidas en este momento.</p>
          </div>
        ) : (
          <div className="reportes-container">
            <div className="reportes-stats">
              <IonChip className="stats-chip">
                <IonIcon icon={pawOutline} />
                <IonLabel>{Object.keys(groupedData).length} Reportes</IonLabel>
              </IonChip>
            </div>

            <IonAccordionGroup className="datos-accordion-modern">
              {Object.entries(groupedData).map(([idmarker, groupData]) => (
                <IonAccordion key={idmarker} value={idmarker} className="reporte-accordion">
                  <IonItem slot="header" className="accordion-header-modern" lines="none">
                    <IonAvatar slot="start" className="reporte-avatar-modern">
                      <img src={groupData.foto} alt="Mascota" />
                    </IonAvatar>
                    
                    <IonLabel className="accordion-label-modern">
                      <h3>Reporte del {formatDate(groupData.fecha)}</h3>
                      <div className="accordion-meta">
                        <span className="time-ago"> 
                          <IonIcon icon={timeOutline} />
                          {getTimeAgo(groupData.fecha)}
                        </span>
                        <IonBadge className={`pistas-badge ${groupData.pistas.length > 0 ? 'has-data' : 'no-data'}`}>
                          {groupData.pistas.length} {groupData.pistas.length === 1 ? 'dato' : 'datos'}
                        </IonBadge>
                      </div>
                    </IonLabel>
                  </IonItem>

                  <div className="accordion-content-modern" slot="content">
                    {groupData.pistas.length === 0 ? (
                      <div className="no-pistas-message">
                        <IonIcon icon={informationCircleOutline} />
                        <p>Aún no has recibido datos para este reporte.</p>
                      </div>
                    ) : (
                      <div className="pistas-list">
                        {groupData.pistas.map((pista) => (
                          <div key={pista.id} className="pista-card">
                            <div className="pista-header">
                              <div className="pista-user">
                                <IonIcon icon={personOutline} className="user-icon-dato" />
                                <span className="user-name-dato">{pista.nombreUsuario}</span>
                              </div>
                              <span className="pista-date">
                                <IonIcon icon={calendarOutline} />
                                {formatDate(pista.fecha)}
                              </span>
                            </div>
                            <div className="pista-content">
                              <p>{pista.pista}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </IonAccordion>
              ))}
            </IonAccordionGroup>
          </div>
        )}
      </IonContent>
    </IonModal>
  );
};

export default DatosModal;
