
import React, { useState, useEffect, useRef, useContext, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonTitle, IonButton, IonContent, IonInput,
  IonTextarea, IonSelect, IonSelectOption, IonItem, IonLabel, useIonAlert,
  IonProgressBar, IonIcon,
  IonCard,
  IonCardContent,
} from '@ionic/react';
import { camera, checkmarkCircle, close, documentTextOutline, imageOutline, locationOutline, storefrontOutline } from 'ionicons/icons';
import { addDoc, collection, doc, updateDoc, getDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import ReactCrop, { type Crop, type PixelCrop, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import './CreaTienda.css';

// --- Interfaces & Constants --- //
interface CreaTiendaProps {
  isOpen: boolean;
  onClose: () => void;
  location: { lat: number; lng: number } | null;
  googleMapsApiKey: string;
}

interface MarkerFormData {
  nombre: string;
  direccion: string;
  tipo: 'Tienda' | 'Veterinaria' | '';
  descripcion: string;
  foto: string;
  lat: number;
  lng: number;
  iduser: string;
}

const ASPECT_RATIO = 16 / 9;

// --- Component --- //
const CreaTienda: React.FC<CreaTiendaProps> = ({ isOpen, onClose, location, googleMapsApiKey }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [presentAlert] = useIonAlert();

  const [formData, setFormData] = useState<Partial<MarkerFormData>>({});
  
  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [uploadPercent, setUploadPercent] = useState(0);
  const [showCropSection, setShowCropSection] = useState(false);
  
  const imgRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const placeholderImage = 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Ftienda-placeholder.png?alt=media&token=87c636f3-a333-4464-9bff-d15f59ad1253';

  // --- Core Functions --- //
  const resetAndClose = useCallback(() => {
    setFormData({});
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setUploadPercent(0);
    setShowCropSection(false);
    onClose();
  }, [onClose]);

  useEffect(() => {
    if (isOpen && location && user) {
      const initialData = {
        lat: location.lat,
        lng: location.lng,
        iduser: user.uid,
        direccion: 'Cargando...',
      };
      setFormData(prev => ({ ...prev, ...initialData }));
      
      fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${location.lat},${location.lng}&key=${googleMapsApiKey}`)
        .then(res => res.json())
        .then(data => {
          if (data.results && data.results[0]) {
            setFormData(prev => ({ ...prev, direccion: data.results[0].formatted_address }));
          }
        }).catch(err => {
            console.error("Geocoding API error:", err);
            setFormData(prev => ({...prev, direccion: 'No se pudo obtener la dirección.'}));
        });
    }
  }, [isOpen, location, user, googleMapsApiKey]);

  // --- Form & Image Handling --- //
  const handleInputChange = (name: keyof MarkerFormData, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    imgRef.current = e.currentTarget;
    const { width, height } = e.currentTarget;
    const crop = centerCrop(
      makeAspectCrop({ unit: '%', width: 90 }, ASPECT_RATIO, width, height),
      width,
      height
    );
    setCrop(crop);
  };

  const handleUploadImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current) {
        presentAlert({ header: 'Atención', message: 'Por favor, selecciona y recorta una imagen primero.', buttons: ['OK'] });
        return;
    }
    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) { throw new Error('No se pudo obtener el contexto 2D'); }
    
    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            presentAlert({ header: 'Error', message: 'No se pudo crear el archivo de imagen.', buttons: ['OK'] });
            return;
        }
        try {
            const storage = getStorage();
            const filePath = `uploads/${user?.uid}_${Date.now()}_tienda.png`;
            const storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, blob);

            uploadTask.on('state_changed',
                (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
                (error) => {
                    console.error('Error al subir archivo:', error);
                    presentAlert({ header: 'Error', message: 'No se pudo subir la imagen.', buttons: ['OK'] });
                    setUploadPercent(0);
                },
                async () => {
                    const url = await getDownloadURL(storageRef);
                    setFormData(prev => ({ ...prev, foto: url }));
                    setShowCropSection(false);
                    setSrc(null);
                    setUploadPercent(0);
                    presentAlert({ header: 'Éxito', message: 'Imagen subida. Ahora puedes guardar la tienda.', buttons: ['OK'] });
                }
            );
        } catch (error) {
            console.error('Error en handleUploadImage:', error);
            presentAlert({ header: 'Error', message: 'Ocurrió un error inesperado al subir la imagen.', buttons: ['OK'] });
        }
    }, 'image/png', 1);
  }, [completedCrop, user, presentAlert]);

  const handleSave = async () => {
    const requiredFields: (keyof MarkerFormData)[] = ['nombre', 'direccion', 'tipo', 'descripcion', 'foto', 'lat', 'lng', 'iduser'];
    for (const field of requiredFields) {
        if (!formData[field]) {
            presentAlert({ header: 'Campos Incompletos', message: `Por favor, rellena todos los campos. Falta: ${field}.`, buttons: ['OK'] });
            return;
        }
    }
    if (!user || !user.correo) {
        presentAlert({ header: 'Error', message: 'Debes iniciar sesión para guardar', buttons: ['OK'] });
        return;
    }

    try {
        await addDoc(collection(firestore, 'marcadores'), formData as MarkerFormData);
        const creatorRef = doc(firestore, 'creadores', user.correo);
        const creatorSnap = await getDoc(creatorRef);
        if (creatorSnap.exists()) {
            const currentMarkers = creatorSnap.data().marcadores || 0;
            await updateDoc(creatorRef, { marcadores: currentMarkers + 1 });
        }
        presentAlert({ header: 'Correcto', message: 'Tienda Creada', buttons: ['OK'] });
        resetAndClose();
    } catch(e) {
        console.error("Error al guardar la tienda: ", e);
        presentAlert({ header: 'Error', message: 'No se pudo guardar la tienda.', buttons: ['OK'] });
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="crear-tienda-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="tienda-toolbar">
          <div className="tienda-header">
            <div className="header-title-section">
              <IonIcon icon={storefrontOutline} className="header-icon-tienda" />
              <IonTitle className="tienda-title">Crear Tienda</IonTitle>
            </div>
            <IonButton fill="clear" onClick={resetAndClose} className="close-btn-tienda">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
      
      <IonContent className="tienda-content">
        <div className="photo-upload-section-tienda">
          <div className="photo-preview-container-tienda">
            <div className="photo-preview-tienda landscape">
              <img 
                src={formData.foto || placeholderImage} 
                alt="Tienda" 
                className={formData.foto ? 'has-photo' : 'placeholder'}
              />
            </div>
            
            {!formData.foto && (
              <div className="upload-prompt-tienda">
                <IonIcon icon={imageOutline} className="upload-icon-tienda" />
                <p>Foto de la tienda</p>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />

          <IonButton
            fill="clear"
            className="select-photo-btn-tienda"
            onClick={() => fileInputRef.current?.click()}
          >
            <IonIcon icon={camera} slot="start" />
            {formData.foto ? 'Cambiar Foto' : 'Seleccionar Foto'}
          </IonButton>
        </div>

        {showCropSection && src && (
          <div className="crop-section">
            <div className="crop-header">
              <IonIcon icon={imageOutline} />
              <span>Recorta la imagen a tu gusto</span>
            </div>
            
            <div className="crop-container">
                <ReactCrop 
                    crop={crop} 
                    onChange={c => setCrop(c)} 
                    onComplete={c => setCompletedCrop(c)} 
                    aspect={ASPECT_RATIO}
                >
                    <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
                </ReactCrop>
            </div>

            {uploadPercent > 0 && (
              <div className="upload-progress-container">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}

            <IonButton
              expand="block"
              className="confirm-crop-btn"
              onClick={handleUploadImage} 
              disabled={uploadPercent > 0}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Subir Foto
            </IonButton>
          </div>
        )}

        <IonCard className="form-card-tienda">
          <IonCardContent className="form-content-tienda">
            <h4 className="form-section-title-tienda">
              <IonIcon icon={documentTextOutline} />
              Información de la Tienda
            </h4>

            <div className="form-group-tienda">
              <IonItem className="custom-item-tienda" lines="none">
                <IonIcon icon={storefrontOutline} slot="start" className="item-icon-tienda" />
                <IonLabel position="stacked" className="custom-label-tienda">
                  Nombre de la Tienda <span className="required">*</span>
                </IonLabel>
                <IonInput
                  value={formData.nombre}
                  onIonInput={e => handleInputChange('nombre', e.detail.value!)}
                  placeholder="Ingresa el nombre"
                  className="custom-input-tienda"
                />
              </IonItem>
            </div>

            <div className="form-group-tienda">
              <IonItem className="custom-item-tienda" lines="none">
                <IonIcon icon={locationOutline} slot="start" className="item-icon-tienda" />
                <IonLabel position="stacked" className="custom-label-tienda">
                  Dirección
                </IonLabel>
                <IonInput
                  value={formData.direccion}
                  readonly
                  className="custom-input-tienda readonly"
                />
              </IonItem>
            </div>

            <div className="form-group-tienda">
              <IonItem className="custom-item-tienda" lines="none">
                <IonIcon icon={storefrontOutline} slot="start" className="item-icon-tienda" />
                <IonLabel position="stacked" className="custom-label-tienda">
                  Tipo <span className="required">*</span>
                </IonLabel>
                <IonSelect
                  value={formData.tipo}
                  onIonChange={e => handleInputChange('tipo', e.detail.value)}
                  interface="action-sheet"
                  placeholder="Selecciona el tipo"
                  className="custom-select-tienda"
                >
                  <IonSelectOption value="Tienda">Tienda</IonSelectOption>
                  <IonSelectOption value="Veterinaria">Veterinaria</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-tienda">
              <IonItem className="custom-item-tienda textarea-item" lines="none">
                <IonLabel position="stacked" className="custom-label-tienda">
                  Descripción
                </IonLabel>
                <IonTextarea
                  value={formData.descripcion}
                  onIonInput={e => handleInputChange('descripcion', e.detail.value!)}
                  placeholder="Describe tu tienda o veterinaria"
                  className="custom-textarea-tienda"
                  autoGrow
                  rows={3}
                />
              </IonItem>
            </div>
          </IonCardContent>
        </IonCard>

        <div className="save-button-container-tienda">
          <IonButton
            expand="block"
            className="save-btn-tienda"
            onClick={handleSave}
          >
            <IonIcon icon={checkmarkCircle} slot="start" />
            Guardar Tienda
          </IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>
    </IonModal>
  );
};

export default CreaTienda;
