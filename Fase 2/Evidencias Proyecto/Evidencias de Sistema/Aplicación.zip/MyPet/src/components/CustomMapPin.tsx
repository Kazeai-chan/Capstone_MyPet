import React from 'react';
import './CustomMapPin.css';

interface PinConfig {
  color: string;
  emoji: string;
  label: string;
  gradient: string;
}

interface CustomMapPinProps {
  tipo: string;
  onClick: () => void;
  isActive?: boolean;
}

export const CustomMapPin: React.FC<CustomMapPinProps> = ({ tipo, onClick, isActive = false }) => {
  const getPinConfig = (type: string): PinConfig => {
    const configs: { [key: string]: PinConfig } = {
      'Tienda': {
        color: '#8B5CF6',
        gradient: 'linear-gradient(135deg, #8B5CF6 0%, #A78BFA 100%)',
        emoji: '🛍️',
        label: 'Tienda'
      },
      'Veterinaria': {
        color: '#445a14',
        gradient: 'linear-gradient(135deg, #445a14 0%, #5a7519 100%)',
        emoji: '🏥',
        label: 'Veterinaria'
      },
      'Peluquería': {
        color: '#445a14',
        gradient: 'linear-gradient(135deg, #6B7280 0%, #9CA3AF 100%)',
        emoji: '🐩',
        label: 'Peluquería'
      },
      'mascota': {
        color: '#F59E0B',
        gradient: 'linear-gradient(135deg, #F59E0B 0%, #FBBF24 100%)',
        emoji: '🐾',
        label: 'Mascota'
      },
      'Mascota Perdida': {
        color: '#EF4444',
        gradient: 'linear-gradient(135deg, #EF4444 0%, #F87171 100%)',
        emoji: '🐾',
        label: 'Perdida'
      },
      'Mascota Encontrada': {
        color: '#27ae60',
        gradient: 'linear-gradient(135deg, #27ae60 0%, #2ecc71 100%)',
        emoji: '🐾',
        label: 'Encontrada'
      },
      'default': {
        color: '#6B7280',
        gradient: 'linear-gradient(135deg, #6B7280 0%, #9CA3AF 100%)',
        emoji: '📍',
        label: 'Lugar'
      }
    };
    return configs[type] || configs.default;
  };

  const config = getPinConfig(tipo);

  return (
    <div 
      className={`mypet-pin-wrapper ${isActive ? 'active' : ''} ${tipo === 'Mascota Perdida' ? 'perdido' : ''} ${tipo === 'Mascota Encontrada' ? 'encontrado' : ''}`}
      onClick={onClick}
    >
      {/* Pin estilo moderno con base circular */}
      <div className="mypet-pin-container">
        {/* Círculo principal con gradiente */}
        <div 
          className="mypet-pin-circle"
          style={{ 
            background: config.gradient,
            boxShadow: `0 4px 12px ${config.color}40, 0 2px 4px ${config.color}20`
          }}
        >
          {/* Emoji/Icono */}
          <div className="mypet-pin-icon">
            {config.emoji}
          </div>
          
          {/* Borde decorativo interno */}
          <div className="mypet-pin-inner-border"></div>
        </div>

        {/* Punto indicador (triángulo inferior) */}
        <div 
          className="mypet-pin-pointer"
          style={{ 
            borderTopColor: config.color,
            filter: `drop-shadow(0 2px 4px ${config.color}60)`
          }}
        ></div>

        {/* Badge con label */}
        <div 
          className="mypet-pin-label"
          style={{ 
            background: config.gradient,
            boxShadow: `0 2px 8px ${config.color}30`
          }}
        >
          {config.label}
        </div>
      </div>

      {/* Efecto de pulso para pins importantes */}
      {(tipo === 'Mascota Perdida' || tipo === 'Mascota Encontrada') && (
        <div 
          className="mypet-pin-pulse"
          style={{ background: config.color }}
        ></div>
      )}

      {/* Sombra realista */}
      <div className="mypet-pin-shadow"></div>
    </div>
  );
};

export default CustomMapPin;