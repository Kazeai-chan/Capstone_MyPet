
import React, { useState, useRef, useContext, useEffect, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonContent, IonButton, IonAvatar,
  IonItem, IonLabel, IonCard, IonCardContent,
  IonInput, IonToggle, IonIcon, useIonAlert, IonProgressBar,
  ToggleCustomEvent,
  IonBadge,
  IonTextarea,
  IonList
} from '@ionic/react';
import { camera, checkmarkCircle, close, imageOutline, locationOutline, mailOutline, navigate, notificationsOutline, personOutline, trophyOutline, documentTextOutline } from 'ionicons/icons';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { doc, updateDoc } from "firebase/firestore";
import { firestore } from '../firebase';
import { User, UserContext } from '../context/UserContext';
import './PerfilModal.css';

// Interfaces
interface AutocompletePrediction {
  description: string;
  place_id: string;
}

interface PerfilModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  googleMapsApiKey: string;
}

function xhrFetch(url: string): Promise<any> {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    resolve(JSON.parse(xhr.responseText));
                } catch (e) {
                    console.error("Failed to parse the following response:", xhr.responseText);
                    reject(new Error('Failed to parse JSON response.'));
                }
            } else {
                 console.error(`Request failed with status ${xhr.status}. Response:`, xhr.responseText);
                reject(new Error(`Request failed with status: ${xhr.status} - ${xhr.statusText}`));
            }
        };
        xhr.onerror = () => reject(new Error('Network request failed.'));
        xhr.send();
    });
}

const PerfilModal: React.FC<PerfilModalProps> = ({ isOpen, onClose, user, googleMapsApiKey }) => {
  const [profileData, setProfileData] = useState<Partial<User>>(user);
  const [presentAlert] = useIonAlert();
  const { refreshUser } = useContext(UserContext);
  
  // State for image cropping
  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [uploadPercent, setUploadPercent] = useState(0);
  const [showCropSection, setShowCropSection] = useState(false);
  
  // State for address autocomplete
  const [predictions, setPredictions] = useState<AutocompletePrediction[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const imgRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const originalFotoUrlRef = useRef<string | null>(null);

  const handleClose = useCallback(() => {
    setShowCropSection(false);
    setSrc(null);
    setUploadPercent(0);
    setShowSuggestions(false);
    setPredictions([]);
    onClose();
  }, [onClose]);

  useEffect(() => {
    if (isOpen) {
      setProfileData(user);
      originalFotoUrlRef.current = user.fotouser;
      // Reset visual state
      setShowCropSection(false);
      setSrc(null);
      setUploadPercent(0);
      setShowSuggestions(false);
      setPredictions([]);
    }
  }, [isOpen, user]);

  const handleFieldChange = (field: keyof User, value: any) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleAddressChange = async (e: any) => {
    const value = e.detail.value || '';
    handleFieldChange('direccion', value);

    if (profileData.lat || profileData.lng) {
        const { lat, lng, ...rest } = profileData;
        setProfileData({ ...rest, direccion: value });
    }

    if (value.length > 3) {
      const url = `/api/maps/api/place/autocomplete/json?input=${encodeURIComponent(value)}&key=${googleMapsApiKey}&types=address`;
      try {
        const data = await xhrFetch(url);
        setPredictions(data.predictions || []);
        setShowSuggestions(true);
      } catch (error) {
        console.error("[XHR-PROXY] Autocomplete request failed:", error);
        setShowSuggestions(false);
      }
    } else {
      setPredictions([]);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = async (prediction: AutocompletePrediction) => {
    handleFieldChange('direccion', prediction.description);
    setShowSuggestions(false);
    setPredictions([]);

    try {
        const url = `/api/maps/api/place/details/json?placeid=${prediction.place_id}&fields=geometry,address_components&key=${googleMapsApiKey}`;
        const data = await xhrFetch(url);
        if (data.result && data.result.geometry) {
            const { lat, lng } = data.result.geometry.location;
            let city = '';
            if (data.result.address_components) {
              const cityComponent = data.result.address_components.find((comp: any) => comp.types.includes('locality'));
              if (cityComponent) {
                city = cityComponent.long_name;
              }
            }
            setProfileData(prev => ({ ...prev, lat, lng, direccion: prediction.description, ciudad: city }));
        }
    } catch (error) {
        console.error("[XHR-PROXY] Place details request failed:", error);
        presentAlert({
            header: 'Error de Ubicación',
            message: 'No se pudieron obtener las coordenadas para la dirección seleccionada. Por favor, intenta de nuevo.',
            buttons: ['OK'],
        });
    }
  };


  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    imgRef.current = e.currentTarget;
  };

  const handleUploadImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current) {
      presentAlert({ header: 'Atención', message: 'Por favor, selecciona y recorta una imagen primero.', buttons: ['OK'] });
      return;
    }

    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) { throw new Error('No se pudo obtener el contexto 2D'); }
    
    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
          presentAlert({ header: 'Error', message: 'No se pudo crear el archivo de imagen.', buttons: ['OK'] });
          return;
        }

        const storage = getStorage();
        const filePath = `uploads/${user.uid}_${Date.now()}.png`;
        const storageRef = ref(storage, filePath);
        const uploadTask = uploadBytesResumable(storageRef, blob);

        uploadTask.on('state_changed',
            (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
            (error) => {
              console.error("Upload failed:", error);
              presentAlert({ header: 'Error', message: 'No se pudo subir la nueva imagen.', buttons: ['OK'] });
              setUploadPercent(0);
            },
            async () => {
                const downloadURL = await getDownloadURL(storageRef);
                const userDocRef = doc(firestore, 'usuarios', user.uid);
                await updateDoc(userDocRef, { fotouser: downloadURL });

                if (originalFotoUrlRef.current && originalFotoUrlRef.current.includes('firebase')) {
                  const oldPhotoRef = ref(storage, originalFotoUrlRef.current);
                  deleteObject(oldPhotoRef).catch(err => console.error("Error al borrar imagen antigua:", err));
                }

                await refreshUser();
                setProfileData(prev => ({ ...prev, fotouser: downloadURL }));
                originalFotoUrlRef.current = downloadURL;

                setShowCropSection(false);
                setSrc(null);
                setUploadPercent(0);
                presentAlert({ header: 'Éxito', message: 'Tu foto de perfil ha sido actualizada.', buttons: ['OK'] });
            }
        );
    }, 'image/png', 1);
  }, [completedCrop, user.uid, presentAlert, refreshUser]);

  const handleUpdateProfile = async () => {
    if (!user.uid) {
        presentAlert({ header: 'Error', message: 'No se ha podido identificar al usuario.', buttons: ['OK'] });
        return;
    }
    const userDocRef = doc(firestore, 'usuarios', user.uid);

    const updateData: Partial<User> & { ciudad?: string } = {
        name: profileData.name,
        direccion: profileData.direccion || '',
        descripcion: profileData.descripcion || '',
        alertaMascotas: profileData.alertaMascotas || false,
        ciudad: profileData.ciudad || '',
    };

    if (profileData.lat && profileData.lng) {
        updateData.lat = profileData.lat;
        updateData.lng = profileData.lng;
    } else {
        updateData.lat = undefined;
        updateData.lng = undefined;
    }

    try {
        await updateDoc(userDocRef, updateData);
        await refreshUser();
        presentAlert({ header: 'Éxito', message: 'Perfil actualizado correctamente.', buttons: ['OK'] });
        handleClose();
    } catch (error) {
        console.error("Error updating profile: ", error);
        presentAlert({ header: 'Error', message: 'No se pudo actualizar el perfil.', buttons: ['OK'] });
    }
  };

  const handleAlertToggleChange = (e: ToggleCustomEvent) => {
    const newCheckedState = e.detail.checked;
    if (newCheckedState && (!profileData.direccion || profileData.direccion.trim() === '')) {
      presentAlert({
        header: 'Dirección Requerida',
        message: 'Por favor, añade tu dirección de domicilio antes de activar las alertas de mascotas perdidas.',
        buttons: ['OK'],
      });
      const toggle = e.target as HTMLIonToggleElement;
      if (toggle) { toggle.checked = false; }
      setProfileData(prev => ({ ...prev, alertaMascotas: false }));
    } else {
      handleFieldChange('alertaMascotas', newCheckedState);
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={handleClose}>
      <IonHeader className="ion-no-border">
        <IonToolbar className="modal-toolbar-perfil">
          <div className="modal-header-perfil">
            <h2>Mi Perfil</h2>
            <IonButton fill="clear" onClick={handleClose} className="close-btn-perfil">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
       <IonContent className="perfil-content">
        <div className="perfil-photo-section">
          <div className="avatar-container-perfil">
            <IonAvatar className="perfil-avatar-large">
              <img src={profileData.fotouser || 'https://via.placeholder.com/150'} alt={profileData.name} />
            </IonAvatar>
            <button 
              className="change-avatar-btn"
              onClick={() => !showCropSection && fileInputRef.current?.click()}
            >
              <IonIcon icon={camera} />
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
        </div>

        {showCropSection && src ? (
          <div className="crop-section">
            <div className="crop-header">
              <IonIcon icon={imageOutline} />
              <span>Recorta tu nueva foto</span>
            </div>
            <div className="crop-container">
              <ReactCrop 
                crop={crop} 
                onChange={c => setCrop(c)} 
                onComplete={c => setCompletedCrop(c)} 
                aspect={1} 
                circularCrop
              >
                <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
              </ReactCrop>
            </div>
            {uploadPercent > 0 && (
              <div className="upload-progress-container">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}
            <IonButton
              expand="block"
              className="confirm-crop-btn"
              onClick={handleUploadImage} 
              disabled={uploadPercent > 0}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Cambiar Foto
            </IonButton>
          </div>
        ) : (
          <>
            <IonCard className="perfil-info-card">
              <IonCardContent className="perfil-card-content">
                <h4 className="perfil-section-title">Información Personal</h4>
                <div className="perfil-form-group">
                  <IonItem className="perfil-item" lines="none">
                    <IonIcon icon={personOutline} slot="start" className="perfil-icon" />
                    <IonLabel position="stacked" className="perfil-label">Nombre</IonLabel>
                    <IonInput
                      value={profileData.name}
                      onIonInput={e => handleFieldChange('name', e.detail.value!)}
                      className="perfil-input"
                      placeholder="Ingresa tu nombre completo"
                    />
                  </IonItem>
                </div>
                <div className="perfil-form-group address-input-container">
                  <IonItem className="perfil-item" lines="none">
                    <IonIcon icon={locationOutline} slot="start" className="perfil-icon" />
                    <IonLabel position="stacked" className="perfil-label">Dirección</IonLabel>
                    <IonInput
                      value={profileData.direccion}
                      onIonInput={handleAddressChange}
                      className="perfil-input"
                      placeholder="Ingresa tu dirección"
                    />
                  </IonItem>
                  {showSuggestions && predictions.length > 0 && (
                    <IonList className="address-suggestions-list">
                      {predictions.map(p => (
                        <IonItem 
                          key={p.place_id}
                          button
                          detail={false}
                          className="address-suggestion-item"
                          onClick={() => handleSuggestionClick(p)}
                        >
                          <IonIcon icon={navigate} slot="start" />
                          <IonLabel>{p.description}</IonLabel>
                        </IonItem>
                      ))}
                    </IonList>
                  )}
                </div>
                 <div className="perfil-form-group">
                  <IonItem className="perfil-item" lines="none">
                    <IonIcon icon={documentTextOutline} slot="start" className="perfil-icon" />
                    <IonLabel position="stacked" className="perfil-label">Mi Bio</IonLabel>
                    <IonTextarea
                      value={profileData.descripcion}
                      onIonInput={e => handleFieldChange('descripcion', e.detail.value!)} 
                      className="perfil-input"
                      placeholder="Cuenta algo sobre ti y tus mascotas..."
                      autoGrow={true}
                    />
                  </IonItem>
                </div>
                <div className="perfil-form-group">
                  <IonItem className="perfil-item" lines="none">
                    <IonIcon icon={mailOutline} slot="start" className="perfil-icon" />
                    <IonLabel position="stacked" className="perfil-label">Correo Electrónico (no se puede cambiar)</IonLabel>
                    <IonInput
                      type="email"
                      value={user.correo}
                      readonly
                      className="perfil-input"
                    />
                  </IonItem>
                </div>
                <div className="perfil-form-group">
                  <IonItem className="perfil-item perfil-item-readonly" lines="none">
                    <IonIcon icon={trophyOutline} slot="start" className="perfil-icon trophy-icon" />
                    <IonLabel className="perfil-label">Mis Puntos</IonLabel>
                    <IonBadge className="points-badge" slot="end">{user.puntos} 🏆</IonBadge>
                  </IonItem>
                </div>
                <div className="perfil-form-group">
                  <IonItem className="perfil-item perfil-item-toggle" lines="none">
                    <IonIcon icon={notificationsOutline} slot="start" className="perfil-icon" />
                    <IonLabel className="perfil-label">Recibir alertas de mascotas</IonLabel>
                    <IonToggle
                      checked={profileData.alertaMascotas}
                      onIonChange={handleAlertToggleChange}
                      className="perfil-toggle"
                      slot="end"
                    />
                  </IonItem>
                </div>
              </IonCardContent>
            </IonCard>
            <div className="perfil-actions">
              <IonButton
                expand="block"
                className="save-btn-perfil"
                onClick={handleUpdateProfile}
              >
                <IonIcon icon={checkmarkCircle} slot="start" />
                Guardar Cambios
              </IonButton>
            </div>
          </>
        )}
        <div style={{ height: '20px' }}></div>
      </IonContent>
    </IonModal>
  );
};

export default PerfilModal;
