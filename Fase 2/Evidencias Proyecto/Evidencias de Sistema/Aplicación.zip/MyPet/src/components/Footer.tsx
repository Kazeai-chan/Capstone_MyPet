
import React from 'react';
import { IonIcon, IonLabel, IonRouterOutlet, IonTabBar, IonTabButton, IonTabs } from '@ionic/react';
import { Redirect, Route } from 'react-router-dom';
import { home, map, chatbubbles, person } from 'ionicons/icons';

// Estandarizando todas las importaciones para que usen rutas relativas.
import Home from '../pages/HomePage';
import Buscar from '../pages/Buscar';
import Foro from '../pages/Foro';
import ConversationsPage from '../pages/ConversationsPage';
import ChatPage from '../pages/ChatPage';
import PetPuntosPage from '../pages/PetPuntosPage';
import MascotaVirtualPage from '../pages/MascotaVirtualPage';
import Perfil from '../pages/Perfil';
import TemaPage from '../pages/TemaPage';
import AportarDatoPage from '../pages/AportarDatoPage';
import VisionTestPage from '../pages/VisionTestPage';
import SettingsPage from '../pages/SettingsPage'; 
import PetReportPage from '../pages/PetReportPage';

import './Footer.css'; 

const Footer: React.FC = () => (
  
  <IonTabs>
    <IonRouterOutlet>
      <Redirect exact path="/app" to="/app/home" />
      <Route exact path="/app/home" component={Home} />
      <Route exact path="/app/buscar" component={Buscar} />
      <Route exact path="/app/foro" component={Foro} />
      <Route exact path="/app/tema/:id" component={TemaPage} />
      <Route exact path="/app/conversations" component={ConversationsPage} />
      <Route exact path="/app/chat/:userId" component={ChatPage} />
      <Route exact path="/app/puntos" component={PetPuntosPage} />
      <Route exact path="/app/mascotavirtual" component={MascotaVirtualPage} />
      <Route exact path="/app/perfil" component={Perfil} />
      <Route exact path="/app/perfil/:id" component={Perfil} />
      <Route exact path="/app/dato" component={AportarDatoPage} />
      <Route exact path="/app/vision-test" component={VisionTestPage} />
      <Route exact path="/app/settings" component={SettingsPage} />
      <Route exact path="/app/reporte/:id" component={PetReportPage} />

    </IonRouterOutlet>

    <IonTabBar className="bottom-nav" slot="bottom">
      <IonTabButton 
        tab="home" href="/app/home"
      >
        <IonIcon icon={home} />
        <IonLabel>Inicio</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="buscar" href="/app/buscar"
      >
        <IonIcon icon={map} />
        <IonLabel>Mapa</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="foro" href="/app/foro"
      >
        <IonIcon icon={chatbubbles} />
        <IonLabel>Foro</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="perfil" 
        href="/app/perfil"
      >
        <IonIcon icon={person} />
        <IonLabel>Mi Perfil</IonLabel>
      </IonTabButton>
    </IonTabBar>

  </IonTabs>
);

export default Footer;
