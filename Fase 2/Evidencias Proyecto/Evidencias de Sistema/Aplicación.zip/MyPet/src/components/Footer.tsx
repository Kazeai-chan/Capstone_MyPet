
import React from 'react';
import { IonIcon, IonLabel, IonRouterOutlet, IonTabBar, IonTabButton, IonTabs } from '@ionic/react';
import { Redirect, Route } from 'react-router-dom';
import { home, map, chatbubbles, person } from 'ionicons/icons';
import Home from '../pages/HomePage';
import Buscar from '../pages/Buscar';
import Foro from '../pages/Foro';
import ConversationsPage from 'pages/ConversationsPage';
import ChatPage from 'pages/ChatPage';
import PetPuntosPage from 'pages/PetPuntosPage';
import MascotaVirtualPage from 'pages/MascotaVirtualPage';
import Perfil from 'pages/Perfil';

import './Footer.css'; 

const Footer: React.FC = () => (
  
  <IonTabs>
    <IonRouterOutlet>
      <Redirect exact path="/" to="/home" />
      <Route exact path="/home" component={Home} />
      <Route exact path="/buscar" component={Buscar} />
      <Route exact path="/foro" component={Foro} />
      <Route exact path="/conversations" component={ConversationsPage} />
      <Route exact path="/chat/:userId" component={ChatPage} />
      <Route exact path="/puntos" component={PetPuntosPage} />
      <Route exact path="/mascotavirtual" component={MascotaVirtualPage} />
      {/* Route for the logged-in user's profile */}
      <Route exact path="/perfil" component={Perfil} />
      {/* Route for viewing other users' profiles */}
      <Route exact path="/perfil/:id" component={Perfil} />
    </IonRouterOutlet>

    <IonTabBar className="bottom-nav" slot="bottom">
      <IonTabButton 
        tab="home" href="/home"
      >
        <IonIcon icon={home} />
        <IonLabel>Inicio</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="buscar" href="/buscar"
      >
        <IonIcon icon={map} />
        <IonLabel>Mapa</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="foro" href="/foro"
      >
        <IonIcon icon={chatbubbles} />
        <IonLabel>Foro</IonLabel>
      </IonTabButton>

      <IonTabButton 
        tab="perfil" 
        href="/perfil"
      >
        <IonIcon icon={person} />
        <IonLabel>Mi Perfil</IonLabel>
      </IonTabButton>
    </IonTabBar>
  </IonTabs>
);

export default Footer;
