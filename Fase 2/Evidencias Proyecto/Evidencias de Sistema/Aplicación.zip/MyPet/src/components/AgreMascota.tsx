
import React, { useState, useRef, useContext, useEffect, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonButton, IonContent, IonCard,
  IonCardContent, IonItem, IonInput, IonLabel, IonSelect,
  IonSelectOption, useIonAlert, IonIcon, IonSpinner, IonToast
} from '@ionic/react';
import { addCircle, calendarOutline, close, colorPaletteOutline, imageOutline, pawOutline, resizeOutline } from 'ionicons/icons';

import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { collection, doc, writeBatch, getDocs, orderBy, query } from "firebase/firestore"; // <-- Import 'doc' and 'writeBatch'

import { UserContext, UserContextType } from '../context/UserContext';
import { firestore } from '../firebase';
import './AgreMascota.css';

// --- INTERFACES ---
interface PetAnalysisResult {
  animalType: string; breed: string; color: string; eyeColor: string;
  size: string; fur: string;
}

interface SelectOption { id: string; nombre: string; }

interface Mascota {
  animal: string; color: string; colorOjos: string; foto: string; iduser: string;
  nacimiento: string; nombre: string; propia: boolean; raza: string; tamano: string; pelaje: string;
}

const INITIAL_MASCOTA_STATE: Mascota = {
  animal: "", color: "", colorOjos: "", foto: "", iduser: "", nacimiento: "",
  nombre: "", propia: true, raza: "", tamano: "", pelaje: ""
};

const AgreMascota: React.FC<{ isOpen: boolean; onClose: () => void; }> = ({ isOpen, onClose }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [mascota, setMascota] = useState<Mascota>(INITIAL_MASCOTA_STATE);
  const [presentAlert] = useIonAlert();

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  // --- Dropdown Options State ---
  const [animales, setAnimales] = useState<SelectOption[]>([]);
  const [razas, setRazas] = useState<SelectOption[]>([]);
  const [colores, setColores] = useState<SelectOption[]>([]);
  const [coloresOjos, setColoresOjos] = useState<SelectOption[]>([]);
  const [tamanos, setTamanos] = useState<SelectOption[]>([]);
  const [pelajes, setPelajes] = useState<SelectOption[]>([]);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const placeholderImage = 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Fpet-placeholder.png?alt=media&token=c2e4f95e-9c82-4a39-a8ff-b42554e9d491';

  const fetchCollection = async (collectionName: string) => {
    const q = query(collection(firestore, collectionName), orderBy('nombre'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as SelectOption));
  };

  useEffect(() => {
    if (isOpen) {
      Promise.all([
        fetchCollection('animales'), fetchCollection('razas'), fetchCollection('colores'),
        fetchCollection('coloresOjos'), fetchCollection('tamanos'), fetchCollection('pelajes'),
      ]).then(([animalesData, razasData, coloresData, coloresOjosData, tamanosData, pelajesData]) => {
        setAnimales(animalesData);
        setRazas(razasData);
        setColores(coloresData);
        setColoresOjos(coloresOjosData);
        setTamanos(tamanosData);
        setPelajes(pelajesData);
      }).catch(err => {
        console.error("Error fetching collections:", err);
        presentAlert({ header: 'Error', message: 'No se pudieron cargar las opciones del formulario.', buttons: ['OK'] });
      });
    }
  }, [isOpen, presentAlert]);

  const handleClose = useCallback(() => {
    setMascota(INITIAL_MASCOTA_STATE);
    setImagePreview(null);
    setUploadPercent(0);
    setIsAnalyzing(false);
    setAnalysisError(null);
    onClose();
  }, [onClose]);

  const findOrCreateOption = async (collectionName: string, value: string): Promise<SelectOption> => {
    if (!value || value === 'No determinado') return { id: '', nombre: '' };
    const response = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/findOrCreateSelectOption', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ collectionName, value }),
    });
    if (!response.ok) throw new Error(`Failed to find or create option for ${collectionName}`);
    const data = await response.json();
    return { id: data.id, nombre: data.nombre };
  };

  const handleFileAndAnalyze = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    setUploadPercent(0);
    let storageRef: any = null;

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const originalBase64 = reader.result as string;
      setImagePreview(originalBase64);

      const img = document.createElement('img');
      img.src = originalBase64;
      img.onload = async () => {
        const MAX_DIMENSION = 384;
        let { width, height } = img;
        if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
          if (width > height) {
            height = Math.round((height * MAX_DIMENSION) / width);
            width = MAX_DIMENSION;
          } else {
            width = Math.round((width * MAX_DIMENSION) / height);
            height = MAX_DIMENSION;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d')?.drawImage(img, 0, 0, width, height);
        const resizedBase64 = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];

        try {
          const uploadPromise = new Promise<string>((resolve, reject) => {
            const storage = getStorage();
            const filePath = `mascotas/${user?.uid}_${Date.now()}_${file.name}`;
            storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, file);
            uploadTask.on('state_changed',
              (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
              reject,
              () => getDownloadURL(storageRef).then(resolve).catch(reject)
            );
          });

          const analysisPromise = fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/analyzePetImage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: resizedBase64 }),
          }).then(res => res.json());

          const [downloadURL, analysisResponse] = await Promise.all([uploadPromise, analysisPromise]);

          if (analysisResponse.error || !analysisResponse.analysis) {
            throw new Error(analysisResponse.details || 'El análisis de la IA falló.');
          }

          const analysis: PetAnalysisResult = analysisResponse.analysis;

          if (analysis.animalType === 'No es animal') {
            if (storageRef) {
              await deleteObject(storageRef);
            }
            presentAlert({
              header: 'Imagen no válida',
              message: 'La imagen no parece ser de un animal. Por favor, intenta con otra foto.',
              buttons: ['OK']
            });
            setIsAnalyzing(false);
            setUploadPercent(0);
            return;
          }
          
          setMascota(prev => ({ ...prev, foto: downloadURL }));

          const [animalOpt, razaOpt, colorOpt, eyeColorOpt, tamanoOpt, pelajeOpt] = await Promise.all([
            findOrCreateOption('animales', analysis.animalType),
            findOrCreateOption('razas', analysis.breed),
            findOrCreateOption('colores', analysis.color),
            findOrCreateOption('coloresOjos', analysis.eyeColor),
            findOrCreateOption('tamanos', analysis.size),
            findOrCreateOption('pelajes', analysis.fur),
          ]);

          if (animalOpt.id && !animales.some(a => a.id === animalOpt.id)) setAnimales(prev => [...prev, animalOpt]);
          if (razaOpt.id && !razas.some(r => r.id === razaOpt.id)) setRazas(prev => [...prev, razaOpt]);
          if (colorOpt.id && !colores.some(c => c.id === colorOpt.id)) setColores(prev => [...prev, colorOpt]);
          if (eyeColorOpt.id && !coloresOjos.some(c => c.id === eyeColorOpt.id)) setColoresOjos(prev => [...prev, eyeColorOpt]);
          if (tamanoOpt.id && !tamanos.some(t => t.id === tamanoOpt.id)) setTamanos(prev => [...prev, tamanoOpt]);
          if (pelajeOpt.id && !pelajes.some(p => p.id === pelajeOpt.id)) setPelajes(prev => [...prev, pelajeOpt]);

          setMascota(prev => ({
            ...prev,
            animal: animalOpt.nombre,
            raza: razaOpt.nombre,
            color: colorOpt.nombre,
            colorOjos: eyeColorOpt.nombre,
            tamano: tamanoOpt.nombre,
            pelaje: pelajeOpt.nombre,
          }));

        } catch (err: any) {
          console.error(err);
          setAnalysisError(err.message || 'Ocurrió un error inesperado durante el análisis.');
        } finally {
          setIsAnalyzing(false);
          setUploadPercent(0);
        }
      };
    };
  };

  // --- MODIFIED: handleCreateMascota with Batch Write ---
  const handleCreateMascota = async () => {
    if (!user) {
        presentAlert({ header: 'Error de Autenticación', message: 'Debes iniciar sesión para crear una mascota.', buttons: ['OK'] });
        return;
    }

    const requiredFields: (keyof Omit<Mascota, 'iduser' | 'propia'>)[] = ['nombre', 'animal', 'raza', 'color', 'tamano', 'foto'];
    if (requiredFields.some(field => !mascota[field])) {
      presentAlert({ header: 'Campos Incompletos', message: 'Por favor, completa al menos el nombre, animal, raza, color, tamaño y sube una foto.', buttons: ['OK'] });
      return;
    }

    try {
      const batch = writeBatch(firestore);
      const newPetId = doc(collection(firestore, "mascotas")).id;
      const privatePetRef = doc(firestore, "mascotas", newPetId);
      const publicPetRef = doc(firestore, "mascota_publica", newPetId);

      const privatePetData = {
        ...mascota,
        iduser: user.uid,
        propia: true,
      };

      const publicPetData = {
        nombre: mascota.nombre,
        raza: mascota.raza,
        nacimiento: mascota.nacimiento,
        animal: mascota.animal,
        foto: mascota.foto,
        ownerData: {
          uid: user.uid,
          name: user.name,
          fotouser: user.fotouser,
          contacto: user.contacto || null,
        }
      };

      batch.set(privatePetRef, privatePetData);
      batch.set(publicPetRef, publicPetData);

      await batch.commit();

      presentAlert({ header: '¡Éxito!', message: 'Tu nueva mascota ha sido guardada.', buttons: ['OK'] });
      handleClose();

    } catch (e) {
      console.error("Error al guardar la mascota con batch write: ", e);
      presentAlert({ header: 'Error', message: 'Hubo un problema al guardar tu mascota. Inténtalo de nuevo.', buttons: ['OK'] });
    }
  };

  return (
    <IonModal isOpen={isOpen} onWillDismiss={handleClose} className="add-mascota-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="modal-toolbar">
          <div className="modal-header-content">
            <h2>Agregar Nueva Mascota</h2>
            <IonButton fill="clear" onClick={handleClose} className="close-btn-modal"><IonIcon icon={close} /></IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent className="add-mascota-content">

        <div className="photo-upload-section">
          <div className="photo-preview-container">
            <img
              src={imagePreview || mascota.foto || placeholderImage}
              alt="Mascota"
              className={imagePreview || mascota.foto ? 'has-photo' : 'placeholder'}
            />
            {isAnalyzing && (
              <div className="spinner-overlay">
                <IonSpinner name="crescent" />
                <p>{uploadPercent < 100 ? `Subiendo... ${Math.round(uploadPercent)}%` : 'Analizando...'}</p>
              </div>
            )}
          </div>

          <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleFileAndAnalyze} />
          
          <IonButton
            fill="clear"
            className="select-photo-btn"
            onClick={() => !isAnalyzing && fileInputRef.current?.click()}
            disabled={isAnalyzing}
          >
            <IonIcon icon={imageOutline} slot="start" />
            Analizar Foto con IA
          </IonButton>
        </div>
        
        <IonToast
          isOpen={!!analysisError}
          message={`Error: ${analysisError}`}
          duration={5000}
          onDidDismiss={() => setAnalysisError(null)}
          position="top"
          color="danger"
        />

        <IonCard className="form-card-add">
          <IonCardContent className="form-content-add">
            <h4 className="form-section-title"><IonIcon icon={pawOutline} /> Datos de tu Mascota</h4>
            
            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Nombre <span className="required">*</span></IonLabel>
                  <IonInput className="custom-input-add" value={mascota.nombre} onIonInput={e => setMascota(prev => ({ ...prev, nombre: e.detail.value! }))} placeholder="Dale un nombre" />
              </IonItem>
            </div>
            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={calendarOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">Fecha de Nacimiento</IonLabel>
                <IonInput className="custom-input-add" type="date" value={mascota.nacimiento} onIonChange={e => setMascota(prev => ({ ...prev, nacimiento: e.detail.value! }))} />
              </IonItem>
            </div>
            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Tipo de Animal <span className="required">*</span></IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.animal} onIonChange={e => setMascota(prev => ({ ...prev, animal: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {animales.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Raza <span className="required">*</span></IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.raza} onIonChange={e => setMascota(prev => ({ ...prev, raza: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {razas.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>
            
            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Color de Pelaje <span className="required">*</span></IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.color} onIonChange={e => setMascota(prev => ({ ...prev, color: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {colores.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Color de Ojos</IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.colorOjos} onIonChange={e => setMascota(prev => ({ ...prev, colorOjos: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {coloresOjos.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={resizeOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Tamaño <span className="required">*</span></IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.tamano} onIonChange={e => setMascota(prev => ({ ...prev, tamano: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {tamanos.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                  <IonLabel position="stacked" className="custom-label-add">Tipo de Pelaje</IonLabel>
                  <IonSelect className="custom-select-add" value={mascota.pelaje} onIonChange={e => setMascota(prev => ({ ...prev, pelaje: e.detail.value }))} interface="action-sheet" placeholder="Selecciona">
                    {pelajes.map(opt => <IonSelectOption key={opt.id} value={opt.nombre}>{opt.nombre}</IonSelectOption>)}
                  </IonSelect>
              </IonItem>
            </div>

          </IonCardContent>
        </IonCard>

        <div className="action-buttons-add">
          <IonButton expand="block" className="create-btn" onClick={handleCreateMascota} disabled={isAnalyzing}>
            <IonIcon icon={addCircle} slot="start" />
            Guardar Mascota
          </IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>
    </IonModal>
  );
};

export default AgreMascota;
