import React, { useState, useRef, useContext, useEffect, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonButton, IonContent, IonCard,
  IonCardContent, IonItem, IonInput, IonLabel, IonSelect,
  IonSelectOption, IonProgressBar, useIonAlert, IonIcon
} from '@ionic/react';
import { addCircle, calendarOutline, camera, checkmarkCircle, close, colorPaletteOutline, imageOutline, pawOutline, resizeOutline } from 'ionicons/icons';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { collection, addDoc, getDocs, orderBy, query } from "firebase/firestore"; 

import { UserContext, UserContextType } from '../context/UserContext';
import { firestore } from '../firebase';
import './AgreMascota.css';

// ... (interfaces and initial state remain the same)
interface AgreMascotaProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Mascota {
  animal: string; color: string; foto: string; iduser: string; nacimiento: string;
  nombre: string; propia: boolean; raza: string; tamano: string;
}

interface Animal { id: string; nombre: string; }
interface Color { id: string; nombre: string; }

const INITIAL_MASCOTA_STATE: Mascota = {
  animal: "", color: "", foto: "", iduser: "", nacimiento: "",
  nombre: "", propia: true, raza: "", tamano: "",
};

const AgreMascota: React.FC<AgreMascotaProps> = ({ isOpen, onClose }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [mascota, setMascota] = useState<Mascota>(INITIAL_MASCOTA_STATE);
  const [presentAlert] = useIonAlert();

  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [uploadPercent, setUploadPercent] = useState(0);
  const [animales, setAnimales] = useState<Animal[]>([]);
  const [colores, setColores] = useState<Color[]>([]);

  const imgRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const placeholderImage = 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Fpet-placeholder.png?alt=media&token=c2e4f95e-9c82-4a39-a8ff-b42554e9d491';
  const [showCropSection, setShowCropSection] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
        try {
            const animalesQuery = query(collection(firestore, 'animales'), orderBy('nombre'));
            const coloresQuery = query(collection(firestore, 'colores'), orderBy('nombre'));
            const [animalesSnapshot, coloresSnapshot] = await Promise.all([ getDocs(animalesQuery), getDocs(coloresQuery) ]);
            setAnimales(animalesSnapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as {nombre: string}) })));
            setColores(coloresSnapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as {nombre: string}) })));
        } catch (error) {
            console.error("Error al cargar datos desde Firestore:", error);
            presentAlert({ header: 'Error', message: 'No se pudieron cargar los datos necesarios.', buttons: ['OK'] });
        }
    };
    if (isOpen) fetchData();
  }, [isOpen, presentAlert]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => { imgRef.current = e.currentTarget; };

  const handleUploadImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current) {
        presentAlert({ header: 'Atención', message: 'Por favor, selecciona y recorta una imagen primero.', buttons: ['OK'] });
        return;
    }
    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) { throw new Error('No se pudo obtener el contexto 2D'); }
    
    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            presentAlert({ header: 'Error', message: 'No se pudo crear el archivo de imagen.', buttons: ['OK'] });
            return;
        }
        try {
            const storage = getStorage();
            const filePath = `uploads/${user?.uid}_${Date.now()}_mascota.png`;
            const storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, blob);

            uploadTask.on('state_changed',
                (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
                (error) => {
                    console.error('Error al subir archivo:', error);
                    presentAlert({ header: 'Error', message: 'No se pudo subir la imagen.', buttons: ['OK'] });
                    setUploadPercent(0);
                },
                async () => {
                    const url = await getDownloadURL(storageRef);
                    setMascota(prev => ({ ...prev, foto: url }));
                    setShowCropSection(false);
                    setSrc(null);
                    setUploadPercent(0);
                    presentAlert({ header: 'Éxito', message: 'Imagen subida. Ahora puedes guardar la mascota.', buttons: ['OK'] });
                }
            );
        } catch (error) {
            console.error('Error en handleUploadImage:', error);
            presentAlert({ header: 'Error', message: 'Ocurrió un error inesperado al subir la imagen.', buttons: ['OK'] });
        }
    }, 'image/png', 1);
  }, [completedCrop, user, presentAlert]);

  const handleCreateMascota = async () => {
    if (!user?.uid || !mascota.nombre.trim() || !mascota.animal || !mascota.color || !mascota.foto || !mascota.raza || !mascota.tamano || !mascota.nacimiento) {
      presentAlert({ header: 'Campos Incompletos', message: 'Por favor, rellena todos los campos y asegúrate de haber subido la foto.', buttons: ['OK'] });
      return;
    }
    try {
      await addDoc(collection(firestore, "mascotas"), { ...mascota, iduser: user.uid });
      presentAlert({ header: 'Éxito', message: 'Mascota guardada correctamente.', buttons: ['OK'] });
      handleClose();
    } catch (e) {
      console.error("Error al añadir documento: ", e);
      presentAlert({ header: 'Error', message: 'No se pudo guardar la mascota.', buttons: ['OK'] });
    }
  };
  
  const handleClose = useCallback(() => {
    setMascota(INITIAL_MASCOTA_STATE);
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setUploadPercent(0);
    setShowCropSection(false);
    onClose();
  }, [onClose]);

  // ... (JSX render starts)
  return (
    <IonModal isOpen={isOpen} onWillDismiss={handleClose} className="add-mascota-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="modal-toolbar">
          <div className="modal-header-content">
            <h2>Agregar Nueva Mascota</h2>
            <IonButton fill="clear" onClick={handleClose} className="close-btn-modal">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent className="add-mascota-content">
        {/* ... (photo upload section is unchanged) ... */}
        <div className="photo-upload-section">
          <div className="photo-preview-container">
            <div className="photo-preview">
              <img 
                src={mascota.foto || placeholderImage} 
                alt="Mascota" 
                className={mascota.foto ? 'has-photo' : 'placeholder'}
              />
            </div>
            
            {!mascota.foto && (
              <div className="upload-prompt">
                <IonIcon icon={imageOutline} className="upload-icon" />
                <p>Agrega una foto de tu mascota</p>
              </div>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />

          <IonButton
            fill="clear"
            className="select-photo-btn"
            onClick={() => fileInputRef.current?.click()}
          >
            <IonIcon icon={camera} slot="start" />
            {mascota.foto ? 'Cambiar Foto' : 'Seleccionar Foto'}
          </IonButton>
        </div>

        {showCropSection && src && (
          <div className="crop-section">
            <div className="crop-header">
              <IonIcon icon={imageOutline} />
              <span>Recorta la imagen a tu gusto</span>
            </div>
            
            <div className="crop-container">
                <ReactCrop 
                    crop={crop} 
                    onChange={c => setCrop(c)} 
                    onComplete={c => setCompletedCrop(c)} 
                    aspect={1} 
                    circularCrop
                >
                    <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
                </ReactCrop>
            </div>

            {uploadPercent > 0 && (
              <div className="upload-progress-container">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}

            <IonButton
              expand="block"
              className="confirm-crop-btn"
              onClick={handleUploadImage} 
              disabled={uploadPercent > 0}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Subir Foto
            </IonButton>
          </div>
        )}
        <IonCard className="form-card-add">
          <IonCardContent className="form-content-add">
            <h4 className="form-section-title">
              <IonIcon icon={pawOutline} />
              Datos de tu Mascota
            </h4>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Nombre <span className="required">*</span>
                </IonLabel>
                <IonInput
                  value={mascota.nombre}
                  onIonInput={e => setMascota(prev => ({ ...prev, nombre: e.detail.value ?? '' }))}
                  className="custom-input-add"
                  placeholder="Ingresa el nombre de tu mascota"
                />
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={calendarOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Fecha de Nacimiento
                </IonLabel>
                <IonInput
                  type="date"
                  value={mascota.nacimiento}
                  onIonChange={e => setMascota(prev => ({ ...prev, nacimiento: e.detail.value ?? '' }))}
                  className="custom-input-add"
                />
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Tipo de Animal <span className="required">*</span>
                </IonLabel>
                <IonSelect
                  value={mascota.animal}
                  onIonChange={e => setMascota(prev => ({ ...prev, animal: e.detail.value ?? '' }))}
                  interface="action-sheet"
                  placeholder="Selecciona el tipo"
                  className="custom-select-add"
                >
                  {animales.map(animal => (
                    <IonSelectOption key={animal.id} value={animal.nombre}>
                      {animal.nombre}
                    </IonSelectOption>
                  ))}
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Raza
                </IonLabel>
                <IonSelect
                  value={mascota.raza}
                  onIonChange={e => setMascota(prev => ({ ...prev, raza: e.detail.value ?? '' }))}
                  interface="action-sheet"
                  placeholder="Selecciona la raza"
                  className="custom-select-add"
                >
                  <IonSelectOption value="Hogareño">Hogareño</IonSelectOption>
                  <IonSelectOption value="Quiltro">Quiltro</IonSelectOption>
                  <IonSelectOption value="De Raza">De Raza</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={resizeOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Tamaño
                </IonLabel>
                <IonSelect
                  value={mascota.tamano}
                  onIonChange={e => setMascota(prev => ({ ...prev, tamano: e.detail.value ?? '' }))}
                  interface="action-sheet"
                  placeholder="Selecciona el tamaño"
                  className="custom-select-add"
                >
                  <IonSelectOption value="Pequeño">Pequeño</IonSelectOption>
                  <IonSelectOption value="Medio">Medio</IonSelectOption>
                  <IonSelectOption value="Grande">Grande</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group-add">
              <IonItem className="custom-item-add" lines="none">
                <IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-add" />
                <IonLabel position="stacked" className="custom-label-add">
                  Color
                </IonLabel>
                <IonSelect
                  value={mascota.color}
                  onIonChange={e => setMascota(prev => ({ ...prev, color: e.detail.value ?? '' }))}
                  interface="action-sheet"
                  placeholder="Selecciona el color"
                  className="custom-select-add"
                >
                  {colores.map(color => (
                    <IonSelectOption key={color.id} value={color.nombre}>
                      {color.nombre}
                    </IonSelectOption>
                  ))}
                </IonSelect>
              </IonItem>
            </div>
          </IonCardContent>
        </IonCard>

        <div className="action-buttons-add">
          <IonButton
            expand="block"
            className="create-btn"
            onClick={handleCreateMascota}
          >
            <IonIcon icon={addCircle} slot="start" />
            Guardar Mascota
          </IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>
    </IonModal>
  );
};

export default AgreMascota;
