
import React from 'react';
import { IonCard, IonCardContent, IonChip, IonIcon, IonSpinner } from '@ionic/react';
import { bulbOutline, pawOutline } from 'ionicons/icons';
import './ConsejoMascota.css';

interface ConsejoMascotaProps {
  consejo: string;
  loading: boolean;
}

const ConsejoMascota: React.FC<ConsejoMascotaProps> = ({ consejo, loading }) => {
  return (
    <IonCard className="consejo-card-modern">
      <IonCardContent className="consejo-content-modern">
        {/* Header con diseño mejorado */}
        <div className="consejo-header-modern">
          <div className="header-left">
            <div className="icon-badge-modern">
              <IonIcon icon={bulbOutline} className="bulb-icon" />
              <div className="icon-sparkle">✨</div>
            </div>
            <div className="header-text">
              <h2 className="consejo-title-modern">Consejo del Día</h2>
              <IonChip className="expert-chip">
                <IonIcon icon={pawOutline} />
                <span>Experto MyPet</span>
              </IonChip>
            </div>
          </div>
        </div>

        {/* Contenido del consejo */}
        <div className="consejo-body-modern">
          {loading ? (
            <div className="consejo-loading">
              <div className="loading-animation">
                <IonSpinner name="circular" className="spinner-consejo" />
                <div className="loading-paws">
                  <span className="paw-load paw-1">🐾</span>
                  <span className="paw-load paw-2">🐾</span>
                  <span className="paw-load paw-3">🐾</span>
                </div>
              </div>
              <p className="loading-text-consejo">Buscando el mejor consejo para ti...</p>
            </div>
          ) : (
            <div className="consejo-text-container">
              {consejo.split('\n').map((line, i) => (
                line.trim() && (
                  <p key={i} className="consejo-paragraph">
                    <span className="bullet-paw">🐾</span>
                    {line}
                  </p>
                )
              ))}
            </div>
          )}
        </div>

        {/* Decoración de fondo */}
        <div className="consejo-decoration">
          <div className="deco-paw deco-paw-1">🐾</div>
          <div className="deco-paw deco-paw-2">🐾</div>
        </div>
      </IonCardContent>
    </IonCard>
  );
};

export default ConsejoMascota;
