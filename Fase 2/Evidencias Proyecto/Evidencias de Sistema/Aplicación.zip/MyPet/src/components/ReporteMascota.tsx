
import React, { useState, useEffect, useContext, useRef, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonTitle, IonButton, IonContent, IonInput,
  IonTextarea, IonSelect, IonSelectOption, IonItem, IonLabel, useIonAlert,
  IonIcon, IonCard, IonCardContent, IonList, IonAvatar, IonSpinner, IonToast,
  IonRadio,
  IonRadioGroup
} from '@ionic/react';
import { calendarOutline, checkmarkCircle, close, colorPaletteOutline, documentTextOutline, locationOutline, pawOutline, resizeOutline, sparkles } from 'ionicons/icons';
import { doc, getDoc, addDoc, updateDoc, collection, getDocs, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';

import { firestore } from '../firebase';
import { UserContext } from '../context/UserContext';
import './ReporteMascota.css';

// --- Interfaces --- //
interface ReporteMascotaProps {
  isOpen: boolean;
  onClose: () => void;
  location: { lat: number; lng: number } | null;
  reportId?: string;
  googleMapsApiKey: string;
}

interface ReportFormData {
  nombre: string; direccion: string; foto: string; descripcion: string;
  lat: number; lng: number; tipo: 'mascota'; iduser: string;
  tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
  animal: string; tamano: string; fecha: string; color: string;
  raza: string; colorOjos: string; pelaje: string;
}

interface UserWithLocation {
  id: string;
  lat: number;
  lng: number;
  [key: string]: any; // Para permitir otros campos de usuario
}


interface SelectOption { id: string; nombre: string; }
interface RegisteredPet extends SelectOption { [key: string]: any; }
interface PetAnalysisResult { animalType: string; breed: string; color: string; eyeColor: string; size: string; fur: string; }

// --- Component --- //
const ReporteMascota: React.FC<ReporteMascotaProps> = ({ isOpen, onClose, location, reportId, googleMapsApiKey }) => {
  const { user } = useContext(UserContext);
  const [presentAlert] = useIonAlert();

  const isEditMode = !!reportId;

  const [formData, setFormData] = useState<Partial<ReportFormData>>({});
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);
  const [isPerdida, setIsPerdida] = useState(true);

  // Dropdown options state
  const [misMascotas, setMisMascotas] = useState<RegisteredPet[]>([]);
  const [animales, setAnimales] = useState<SelectOption[]>([]);
  const [razas, setRazas] = useState<SelectOption[]>([]);
  const [colores, setColores] = useState<SelectOption[]>([]);
  const [coloresOjos, setColoresOjos] = useState<SelectOption[]>([]);
  const [tamanos, setTamanos] = useState<SelectOption[]>([]);
  const [pelajes, setPelajes] = useState<SelectOption[]>([]);

  // AI & UI state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const onCloseRef = useRef(onClose);

  const resetAndClose = useCallback(() => {
    setFormData({});
    setSelectedPetId(null);
    setIsPerdida(true);
    setImagePreview(null);
    setUploadPercent(0);
    setIsAnalyzing(false);
    setAnalysisError(null);
    onCloseRef.current();
  }, [onCloseRef]);

  useEffect(() => { onCloseRef.current = onClose; }, [onClose]);

  // --- Data Loading Effect --- //
  useEffect(() => {
    if (!isOpen) return;

    const fetchSelectOptions = async () => {
      try {
        const collections = ['animales', 'razas', 'colores', 'coloresOjos', 'tamanos', 'pelajes'];
        const [animalesData, razasData, coloresData, coloresOjosData, tamanosData, pelajesData] = await Promise.all(
          collections.map(name => 
            getDocs(query(collection(firestore, name), orderBy('nombre')))
            .then(snap => snap.docs.map(d => ({ id: d.id, ...d.data() } as SelectOption)))
          )
        );
        setAnimales(animalesData); setRazas(razasData); setColores(coloresData);
        setColoresOjos(coloresOjosData); setTamanos(tamanosData); setPelajes(pelajesData);
      } catch (error) {
        console.error("Error fetching select options:", error);
        presentAlert({ header: 'Error', message: 'No se pudieron cargar las opciones del formulario.', buttons: ['OK'] });
      }
    };

    const loadReportForEdit = async () => {
      if (!reportId) return;
      try {
        const docRef = doc(firestore, "marcadores", reportId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const reportData = docSnap.data() as ReportFormData;
          setFormData(reportData);
          setIsPerdida(reportData.tipo_r === 'Mascota Perdida');
          setImagePreview(reportData.foto);
        } else {
          presentAlert({ header: 'Error', message: 'No se encontró el reporte para modificar.', buttons: ['OK'] });
          resetAndClose();
        }
      } catch (error) {
        presentAlert({ header: 'Error', message: 'No se pudo cargar el reporte.', buttons: ['OK'] });
        resetAndClose();
      }
    };

    const loadForCreate = async () => {
      if (user) {
        const mascotasQuery = query(collection(firestore, 'mascotas'), where("iduser", "==", user.uid));
        const snap = await getDocs(mascotasQuery);
        setMisMascotas(snap.docs.map(d => ({ id: d.id, ...d.data() } as RegisteredPet)));
      }
      if (location) {
        setFormData({ lat: location.lat, lng: location.lng, tipo: 'mascota', iduser: user?.uid, fecha: new Date().toISOString().split('T')[0], direccion: 'Cargando...' });
        try {
          const response = await fetch(`https://us-central1-instant-vent-423002-f1.cloudfunctions.net/googleMapsProxy?latlng=${location.lat},${location.lng}`);
          const data = await response.json();
          if (data.results?.[0]) setFormData(prev => ({ ...prev, direccion: data.results[0].formatted_address }));
        } catch (error) { console.error("Error fetching address:", error); }
      }
    };

    fetchSelectOptions();
    if (isEditMode) {
      loadReportForEdit();
    } else {
      loadForCreate();
    }
  }, [isOpen, reportId, isEditMode, user, location, googleMapsApiKey, presentAlert, resetAndClose]);

  const handleMascotaSelection = (e: any) => {
    const selectedId = e.detail.value;
    setSelectedPetId(selectedId);
    if (selectedId === 'Otra') {
      const { lat, lng, direccion, fecha, tipo, iduser } = formData;
      setFormData({ lat, lng, direccion, fecha, tipo, iduser });
      setImagePreview(null);
    } else {
      const pet = misMascotas.find(m => m.id === selectedId);
      if (pet) {
        setFormData(prev => ({ ...prev, ...pet }));
        setImagePreview(pet.foto);
      }
    }
  };

  const findOrCreateOption = async (collectionName: string, value: string) => {
    if (!value || value === 'No determinado') return { id: '', nombre: '' };
    const response = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/findOrCreateSelectOption', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ collectionName, value }),
    });
    if (!response.ok) throw new Error(`API call failed for ${collectionName}`);
    return response.json();
  };

  const handleFileAndAnalyze = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    setAnalysisError(null);
    setUploadPercent(0);
    let storageRef: any = null;

    // --- Inicia el proceso de análisis y subida ---
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const originalBase64 = reader.result as string;
      setImagePreview(originalBase64); // Muestra la previsualización de inmediato

      // Redimensiona la imagen para un análisis más rápido
      const img = document.createElement('img');
      img.src = originalBase64;
      img.onload = async () => {
        const MAX_DIMENSION = 384;
        let { width, height } = img;
        if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
          if (width > height) {
            height = Math.round((height * MAX_DIMENSION) / width);
            width = MAX_DIMENSION;
          } else {
            width = Math.round((width * MAX_DIMENSION) / height);
            height = MAX_DIMENSION;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d')?.drawImage(img, 0, 0, width, height);
        const resizedBase64 = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];

        try {
          // Promesa para subir la imagen a Firebase Storage
          const uploadPromise = new Promise<string>((resolve, reject) => {
            const storage = getStorage();
            // CORRECCIÓN CLAVE: Se añade el nombre del archivo a la ruta para evitar sobrescribir y fallos.
            const filePath = `reportes/${user?.uid}_${Date.now()}_${file.name}`;
            storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, file);
            uploadTask.on('state_changed',
              (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
              reject,
              () => getDownloadURL(storageRef).then(resolve).catch(reject)
            );
          });

          // Promesa para analizar la imagen con la Cloud Function
          const analysisPromise = fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/analyzePetImage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: resizedBase64 }),
          }).then(res => {
            if (!res.ok) return res.json().then(err => Promise.reject(err));
            return res.json();
          });

          // Se ejecutan ambas promesas en paralelo
          const [downloadURL, analysisResponse] = await Promise.all([uploadPromise, analysisPromise]);

          if (analysisResponse.error || !analysisResponse.analysis) {
            throw new Error(analysisResponse.details || 'El análisis de la IA falló.');
          }

          const analysis: PetAnalysisResult = analysisResponse.analysis;

          // Valida si la IA detectó un animal
          if (analysis.animalType === 'No es animal') {
            if (storageRef) await deleteObject(storageRef); // Borra la imagen subida
            presentAlert({
              header: 'Imagen no válida',
              message: 'La imagen no parece ser de un animal. Por favor, intenta con otra foto.',
              buttons: ['OK']
            });
            setImagePreview(null);
            setIsAnalyzing(false);
            return;
          }

          setFormData(prev => ({ ...prev, foto: downloadURL }));

          // Busca o crea las opciones detectadas por la IA
          const [animalOpt, razaOpt, colorOpt, eyeColorOpt, tamanoOpt, pelajeOpt] = await Promise.all([
            findOrCreateOption('animales', analysis.animalType),
            findOrCreateOption('razas', analysis.breed),
            findOrCreateOption('colores', analysis.color),
            findOrCreateOption('coloresOjos', analysis.eyeColor),
            findOrCreateOption('tamanos', analysis.size),
            findOrCreateOption('pelajes', analysis.fur),
          ]);

          // CORRECCIÓN CLAVE: Actualiza las listas de opciones si se creó una nueva
          if (animalOpt.id && !animales.some(a => a.id === animalOpt.id)) setAnimales(prev => [...prev, animalOpt]);
          if (razaOpt.id && !razas.some(r => r.id === razaOpt.id)) setRazas(prev => [...prev, razaOpt]);
          if (colorOpt.id && !colores.some(c => c.id === colorOpt.id)) setColores(prev => [...prev, colorOpt]);
          if (eyeColorOpt.id && !coloresOjos.some(c => c.id === eyeColorOpt.id)) setColoresOjos(prev => [...prev, eyeColorOpt]);
          if (tamanoOpt.id && !tamanos.some(t => t.id === tamanoOpt.id)) setTamanos(prev => [...prev, tamanoOpt]);
          if (pelajeOpt.id && !pelajes.some(p => p.id === pelajeOpt.id)) setPelajes(prev => [...prev, pelajeOpt]);

          // Rellena el formulario con los datos de la IA
          setFormData(prev => ({
            ...prev,
            animal: animalOpt.nombre,
            raza: razaOpt.nombre,
            color: colorOpt.nombre,
            colorOjos: eyeColorOpt.nombre,
            tamano: tamanoOpt.nombre,
            pelaje: pelajeOpt.nombre,
          }));

        } catch (err: any) {
          console.error("Error en handleFileAndAnalyze:", err);
          if (storageRef) await deleteObject(storageRef).catch(e => console.error("Error borrando imagen fallida:", e));
          setAnalysisError(err.message || 'Ocurrió un error inesperado durante el análisis.');
          setImagePreview(null); // Limpia la previsualización si falla
        } finally {
          setIsAnalyzing(false);
        }
      };
    };
  };


  const handleSave = useCallback(async () => {
    if (!user) {
      presentAlert({ header: 'Error', message: 'Debe iniciar sesión', buttons: ['OK'] });
      return;
    }

    const tipo_r = isPerdida ? 'Mascota Perdida' : 'Mascota Encontrada';
    const finalReporte: Partial<ReportFormData> = { ...formData, tipo_r, iduser: user.uid };
    if (!isPerdida) {
      finalReporte.nombre = 'Desconocido';
    }
    
    const requiredFields: (keyof ReportFormData)[] = ['direccion', 'foto', 'descripcion', 'lat', 'lng', 'tipo', 'iduser', 'tipo_r', 'animal', 'tamano', 'fecha', 'color', 'raza'];
    if (isPerdida) {
      requiredFields.push('nombre');
    }
    const dataToSave: { [key: string]: any } = { ...finalReporte };
    delete dataToSave.id; // Elimina el id heredado de la colección 'mascotas'

    for (const field of requiredFields) {
      if (!finalReporte[field]) {
        presentAlert({ header: 'Campos Incompletos', message: `Por favor, complete todos los campos requeridos. Falta: ${field}`, buttons: ['OK'] });
        return;
      }
    }

    try {
      let newReportId = reportId; // Usamos el ID existente si estamos editando

      if (reportId) {
        await updateDoc(doc(firestore, "marcadores", reportId), dataToSave);
      } else {
        const docRef = await addDoc(collection(firestore, 'marcadores'), dataToSave);
        newReportId = docRef.id; // Obtenemos el nuevo ID si estamos creando
      }
  
      // --- Lógica de Notificación ---
      const { lat, lng } = finalReporte;
      if (lat && lng && newReportId) {
        const radiusInKm = 10;
        const latDelta = radiusInKm / 111.32;
        const lngDelta = radiusInKm / (111.32 * Math.cos(lat * (Math.PI / 180)));
  
        const minLat = lat - latDelta;
        const maxLat = lat + latDelta;
        const minLng = lng - lngDelta;
        const maxLng = lng + lngDelta;
  
        const usersQuery = query(
          collection(firestore, 'usuarios'),
          where('lat', '>=', minLat),
          where('lat', '<=', maxLat),
          where('alertaMascotas', '==', true)
        );
  
        const usersSnapshot = await getDocs(usersQuery);
        const nearbyUsers = usersSnapshot.docs
          .map(uDoc => ({ id: uDoc.id, ...uDoc.data() } as UserWithLocation))
          .filter(u => u.lng >= minLng && u.lng <= maxLng && u.id !== user.uid);
  
        const notificationPromises = nearbyUsers.map(nearbyUser => {
          return addDoc(collection(firestore, 'notificaciones'), {
            userId: nearbyUser.id,
            title: `Nuevo reporte de ${finalReporte.tipo_r}`,
            body: `Hay un nuevo reporte de '${finalReporte.tipo_r}' cerca de tu ubicación.`,
            createdAt: serverTimestamp(),
            read: false,
            icon: '🐾',
            link: `/app/reporte/${newReportId}`
          });
        });
  
        await Promise.all(notificationPromises);
      }
      
      // REEMPLAZA el bloque presentAlert(...) anterior CON ESTO:
      const successMessage = isEditMode
      ? 'Reporte modificado con éxito.'
      : '¡Reporte creado! Nuestra IA ya está buscando coincidencias. Podrás ver los resultados en la página del reporte.';

      presentAlert({
      header: 'Correcto',
      message: successMessage,
      buttons: [{
        text: 'OK',
        handler: () => {
          resetAndClose();
        }
      }]
      });


    } catch (error) {
      console.log(error)
      presentAlert({ header: 'Error', message: `No se pudo guardar el reporte: ${error}`.slice(0, 200), buttons: ['OK'] });
    }
  }, [user, formData, reportId, presentAlert, resetAndClose, isPerdida, isEditMode]);

  const handleInputChange = (field: keyof Omit<ReportFormData, 'lat' | 'lng' | 'tipo' | 'iduser'>, value: any) => {
    setFormData(p => ({ ...p, [field]: value }));
  };

  const canShowCreateForm = !isEditMode && ((selectedPetId && selectedPetId !== 'Otra') || formData.foto);
  const showAiFlow = !isPerdida || selectedPetId === 'Otra';

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="reporte-modal-modern">
      <IonHeader className="ion-no-border"><IonToolbar className="reporte-toolbar-modern"><div className="reporte-header-modern"><div className="header-title-wrapper"><div className="header-icon-circle-reporte"><IonIcon icon={pawOutline} className="header-main-icon-reporte" /><div className="header-paw-badge">🐾</div></div><IonTitle className="reporte-title-modern">{isEditMode ? 'Editar Reporte' : 'Nuevo Reporte'}</IonTitle></div><IonButton fill="clear" onClick={resetAndClose} className="close-btn-reporte-modern"><IonIcon icon={close} /></IonButton></div></IonToolbar></IonHeader>

      <IonContent className="reporte-content-modern">
        <IonToast isOpen={!!analysisError} message={`Error de análisis: ${analysisError}`} duration={5000} onDidDismiss={() => setAnalysisError(null)} position="top" color="danger" />

        {/* --- CREATE MODE STEPS (Conditionally Rendered) --- */}
        {!isEditMode && (
          <>
            <IonCard className="tipo-reporte-card"><IonCardContent className="tipo-reporte-content"><div className="tipo-header"><IonIcon icon={pawOutline} className="tipo-icon" /><h3 className="tipo-title">¿Qué tipo de reporte deseas hacer?</h3></div><div className="tipo-options"><div className={`tipo-option perdida ${isPerdida ? 'selected' : ''}`} onClick={() => setIsPerdida(true)}><div className="option-icon">❗</div><div className="option-content"><h4>Mascota Perdida</h4><p>Reporta que tu mascota está perdida</p></div>{isPerdida && <IonIcon icon={checkmarkCircle} className="selected-check" />}</div><div className={`tipo-option encontrada ${!isPerdida ? 'selected' : ''}`} onClick={() => setIsPerdida(false)}><div className="option-icon">✅</div><div className="option-content"><h4>Mascota Encontrada</h4><p>Encontraste una mascota perdida</p></div>{!isPerdida && <IonIcon icon={checkmarkCircle} className="selected-check" />}</div></div></IonCardContent></IonCard>
            
            {isPerdida && misMascotas.length > 0 && (
              <div className="pets-selection-box-modern"><div className="selection-header"><IonIcon icon={pawOutline} className="selection-icon" /><IonLabel className="selection-label-modern">Selecciona tu mascota perdida</IonLabel></div><IonList className="pets-radio-list-modern"><IonRadioGroup value={selectedPetId} onIonChange={handleMascotaSelection}>{misMascotas.map(mascota => (<IonItem key={mascota.id} className="pet-radio-item-modern" lines="none"><IonRadio slot="start" value={mascota.id} /><IonAvatar className="pet-mini-avatar"><img src={mascota.foto} alt={mascota.nombre} /></IonAvatar><IonLabel className="pet-name-label">{mascota.nombre}</IonLabel></IonItem>))}<IonItem className="pet-radio-item-modern highlight" lines="none"><IonRadio slot="start" value="Otra" /><IonLabel className="pet-name-label">Otra mascota (usar IA)</IonLabel></IonItem></IonRadioGroup></IonList></div>
            )}

            {showAiFlow && !formData.foto && (
              <IonCard className="ai-prompt-card" button={true} onClick={() => !isAnalyzing && fileInputRef.current?.click()} disabled={isAnalyzing}>
                <IonCardContent><div className="ai-prompt-content"><IonIcon icon={sparkles} className="ai-icon" /><h4>{isAnalyzing ? 'Analizando...' : 'Sube una foto para análisis automático'}</h4><p>{isAnalyzing ? `Subiendo... ${Math.round(uploadPercent)}%` : 'Nuestra IA identificará sus características'}</p>{isAnalyzing && <IonSpinner name="crescent" />}</div></IonCardContent>
              </IonCard>
            )}
            {isAnalyzing && formData.foto && (
              <IonCard className="ai-prompt-card">
                <IonCardContent>
                  <div className="ai-prompt-content">
                    <IonIcon icon={sparkles} className="ai-icon" />
                    <h4>Extrayendo características...</h4>
                    <p>La IA está identificando los detalles. Un momento por favor.</p>
                    <IonSpinner name="crescent" />
                  </div>
                </IonCardContent>
              </IonCard>
            )}
            <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleFileAndAnalyze} />
          </>
        )}
        
        {/* --- MAIN FORM (for both EDIT and CREATE) --- */}
        {(isEditMode || canShowCreateForm) && !isAnalyzing && (
            <>
              <IonCard className="form-card-reporte-modern">
                {imagePreview && <img src={imagePreview} alt="Vista previa de la mascota" className="photo-preview-marcador landscape"/>}
                <IonCardContent className="form-content-reporte-modern">
                  <h4 className="form-section-title-reporte-modern"><IonIcon icon={documentTextOutline} />Detalles del Reporte{(showAiFlow && !isEditMode) && <IonIcon icon={sparkles} className="ai-badge" title="Completado con IA" />}</h4>
                  
                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none">
                      <IonIcon icon={locationOutline} slot="start" className="item-icon-reporte-modern" />
                      <IonLabel position="stacked" className="custom-label-reporte-modern">Ubicación del Reporte</IonLabel>
                      <IonInput value={formData.direccion} readonly className="custom-input-reporte-modern readonly" />
                    </IonItem>
                  </div>
                  
                  {isPerdida && (
                    <div className="form-group-reporte-modern">
                      <IonItem className="custom-item-reporte-modern" lines="none">
                        <IonLabel position="stacked" className="custom-label-reporte-modern">Nombre de la Mascota</IonLabel>
                        <IonInput value={formData.nombre} readonly={!isEditMode && selectedPetId !== 'Otra'} onIonInput={e => handleInputChange('nombre', e.detail.value!)} placeholder="Nombre de tu mascota" className="custom-input-reporte-modern" />
                      </IonItem>
                    </div>
                  )}

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none">
                      <IonIcon icon={calendarOutline} slot="start" className="item-icon-reporte-modern" />
                      <IonLabel position="stacked" className="custom-label-reporte-modern">Fecha del {isPerdida ? 'Extravío' : 'Hallazgo'}</IonLabel>
                      <IonInput type="date" value={formData.fecha} onIonChange={e => handleInputChange('fecha', e.detail.value!)} className="custom-input-reporte-modern" />
                    </IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none">
                      <IonIcon icon={pawOutline} slot="start" className="item-icon-reporte-modern" />
                      <IonLabel position="stacked" className="custom-label-reporte-modern">Tipo de Animal</IonLabel>
                      <IonSelect value={formData.animal} onIonChange={e => handleInputChange('animal', e.detail.value)} interface="action-sheet" placeholder="Selecciona el tipo" className="custom-select-reporte-modern">{animales.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect>
                    </IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon-reporte-modern" /><IonLabel position="stacked">Raza</IonLabel><IonSelect value={formData.raza} onIonChange={e => handleInputChange('raza', e.detail.value)} interface="action-sheet" placeholder="Selecciona la raza" className="custom-select-reporte-modern">{razas.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect></IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none"><IonIcon icon={resizeOutline} slot="start" className="item-icon-reporte-modern" /><IonLabel position="stacked">Tamaño</IonLabel><IonSelect value={formData.tamano} onIonChange={e => handleInputChange('tamano', e.detail.value)} interface="action-sheet" placeholder="Selecciona el tamaño" className="custom-select-reporte-modern">{tamanos.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect></IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none"><IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-reporte-modern" /><IonLabel position="stacked">Color Principal</IonLabel><IonSelect value={formData.color} onIonChange={e => handleInputChange('color', e.detail.value)} interface="action-sheet" placeholder="Selecciona el color" className="custom-select-reporte-modern">{colores.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect></IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none"><IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-reporte-modern" /><IonLabel position="stacked">Color de Ojos</IonLabel><IonSelect value={formData.colorOjos} onIonChange={e => handleInputChange('colorOjos', e.detail.value)} interface="action-sheet" placeholder="Selecciona el color" className="custom-select-reporte-modern">{coloresOjos.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect></IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon-reporte-modern" /><IonLabel position="stacked">Tipo de Pelaje</IonLabel><IonSelect value={formData.pelaje} onIonChange={e => handleInputChange('pelaje', e.detail.value)} interface="action-sheet" placeholder="Selecciona el pelaje" className="custom-select-reporte-modern">{pelajes.map(o => <IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>)}</IonSelect></IonItem>
                  </div>

                  <div className="form-group-reporte-modern">
                    <IonItem className="custom-item-reporte-modern textarea-item" lines="none"><IonLabel position="stacked">Descripción Adicional</IonLabel><IonTextarea value={formData.descripcion} onIonInput={e => handleInputChange('descripcion', e.detail.value!)} placeholder="Señas particulares, comportamiento..." autoGrow rows={3} className="custom-textarea-reporte-modern" /></IonItem>
                  </div>
                </IonCardContent>
              </IonCard>
              <div className="save-button-container-reporte-modern">
                <IonButton expand="block" className="save-btn-reporte-modern" onClick={handleSave} disabled={isAnalyzing}>
                  <IonIcon icon={checkmarkCircle} slot="start" />
                  {isEditMode ? 'Guardar Cambios' : 'Publicar Reporte'}
                </IonButton>
              </div>
            </>
        )}
        <div style={{ height: '20px' }}></div>
        <div className="bg-decoration-reporte"><div className="deco-paw-reporte paw-1">🐾</div><div className="deco-paw-reporte paw-2">🐾</div></div>
      </IonContent>
    </IonModal>
  );
};

export default ReporteMascota;
