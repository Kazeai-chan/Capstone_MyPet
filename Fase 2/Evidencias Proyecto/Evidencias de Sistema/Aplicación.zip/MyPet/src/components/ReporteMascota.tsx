
import React, { useState, useEffect, useContext, useRef, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonTitle, IonButton, IonContent, IonInput,
  IonTextarea, IonSelect, IonSelectOption, IonItem, IonLabel, useIonAlert,
  IonRadioGroup, IonRadio, IonIcon, 
  IonCard,
  IonCardContent,
  IonList,
  IonProgressBar
} from '@ionic/react';
import { calendarOutline, camera, checkmarkCircle, close, colorPaletteOutline, documentTextOutline, imageOutline, locationOutline, pawOutline, resizeOutline } from 'ionicons/icons';
import { doc, getDoc, addDoc, updateDoc, collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import ReactCrop, { type Crop, type PixelCrop, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './ReporteMascota.css';

// --- Interfaces & Constants --- //
interface ReporteMascotaProps {
  isOpen: boolean;
  onClose: () => void;
  location: { lat: number; lng: number } | null;
  reportId?: string;
  googleMapsApiKey: string;
}

interface ReportFormData {
  nombre: string;
  direccion: string;
  foto: string;
  descripcion: string;
  lat: number;
  lng: number;
  tipo: 'mascota';
  iduser: string;
  tipo_r: 'Mascota Perdida' | 'Mascota Encontrada' | '';
  animal: string;
  tamano: string;
  fecha: string;
  color: string;
}

interface DropdownItem { id: string; nombre: string; }
interface Mascota { id: string; nombre: string; foto: string; iduser: string; animal: string; color: string; tamano: string; }

const ASPECT_RATIO = 16 / 9;

// --- Component --- //
const ReporteMascota: React.FC<ReporteMascotaProps> = ({ isOpen, onClose, location, reportId, googleMapsApiKey }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const [presentAlert] = useIonAlert();

  const [formData, setFormData] = useState<Partial<ReportFormData>>({});
  const [selectedPetValue, setSelectedPetValue] = useState<string | null>(null);
  const [animales, setAnimales] = useState<DropdownItem[]>([]);
  const [colores, setColores] = useState<DropdownItem[]>([]);
  const [misMascotas, setMisMascotas] = useState<Mascota[]>([]);
  
  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [uploadPercent, setUploadPercent] = useState(0);
  const [showCropSection, setShowCropSection] = useState(false);
  
  const imgRef = useRef<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const placeholderImage = 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Fpet-placeholder.png?alt=media&token=c2e4f95e-9c82-4a39-a8ff-b42554e9d491';

  const resetAndClose = useCallback(() => {
    setFormData({});
    setAnimales([]);
    setColores([]);
    setMisMascotas([]);
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setUploadPercent(0);
    setShowCropSection(false);
    setSelectedPetValue(null);
    onClose();
  }, [onClose]);

  useEffect(() => {
    if (!isOpen) return;

    const fetchInitialData = async () => {
      try {
        const animalesQuery = query(collection(firestore, 'animales'), orderBy('nombre'));
        const coloresQuery = query(collection(firestore, 'colores'), orderBy('nombre'));
        const [animalesSnap, coloresSnap] = await Promise.all([getDocs(animalesQuery), getDocs(coloresQuery)]);
        setAnimales(animalesSnap.docs.map(d => ({ id: d.id, nombre: d.data().nombre })));
        setColores(coloresSnap.docs.map(d => ({ id: d.id, nombre: d.data().nombre })));

        if (user) {
            const mascotasQuery = query(collection(firestore, 'mascotas'), where("iduser", "==", user.uid));
            const snap = await getDocs(mascotasQuery);
            setMisMascotas(snap.docs.map(d => ({ id: d.id, ...d.data() } as Mascota)));
        }
      } catch (error) { console.error("Error fetching initial data:", error); }
    };

    const loadData = async () => {
        if (reportId) { 
            const docRef = doc(firestore, "marcadores", reportId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                setFormData(docSnap.data());
            }
        } else if (location) { 
            const initialData: Partial<ReportFormData> = {
                lat: location.lat, lng: location.lng, tipo: 'mascota',
                iduser: user?.uid || '', fecha: new Date().toISOString().split('T')[0],
                direccion: 'Cargando...',
            };
            setFormData(initialData);
            try {
                const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${location.lat},${location.lng}&key=${googleMapsApiKey}`);
                const data = await response.json();
                if (data.results && data.results[0]) {
                    setFormData(prev => ({...prev, direccion: data.results[0].formatted_address }));
                }
            } catch (error) { 
                console.error("Error fetching address:", error);
                setFormData(prev => ({...prev, direccion: 'No se pudo obtener la dirección.'}));
             }
        }
    }

    fetchInitialData();
    loadData();

  }, [isOpen, reportId, location, user, googleMapsApiKey]);
  
  useEffect(() => {
    if (formData.tipo_r !== 'Mascota Perdida') {
        setSelectedPetValue(null);
    }
  }, [formData.tipo_r]);

  const handleInputChange = (field: keyof ReportFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleMascotaSelection = (e: any) => {
    const selectedId = e.detail.value;
    setSelectedPetValue(selectedId);

    if (selectedId === 'Otra') {
      setFormData(prev => ({ ...prev, nombre: '', animal: '', color: '', tamano: '', foto: '', iduser: user?.uid || '' }));
    } else {
      const mascota = misMascotas.find(m => m.id === selectedId);
      if (mascota) {
        setFormData(prev => ({
            ...prev, 
            nombre: mascota.nombre, foto: mascota.foto, iduser: mascota.iduser,
            animal: mascota.animal, color: mascota.color, tamano: mascota.tamano,
        }));
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    imgRef.current = e.currentTarget;
    const { width, height } = e.currentTarget;
    const crop = centerCrop(
      makeAspectCrop({ unit: '%', width: 90 }, ASPECT_RATIO, width, height),
      width,
      height
    );
    setCrop(crop);
  };
  
  const handleImageUpload = useCallback(async () => {
    if (!completedCrop || !imgRef.current) {
        presentAlert({ header: 'Atención', message: 'Por favor, selecciona y recorta una imagen primero.', buttons: ['OK'] });
        return;
    }
    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) { throw new Error('No se pudo obtener el contexto 2D'); }
    
    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            presentAlert({ header: 'Error', message: 'No se pudo crear el archivo de imagen.', buttons: ['OK'] });
            return;
        }
        try {
            const storage = getStorage();
            const filePath = `uploads/${user?.uid}_${Date.now()}_reporte.png`;
            const storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, blob);

            uploadTask.on('state_changed',
                (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
                (error) => {
                    console.error('Error al subir archivo:', error);
                    presentAlert({ header: 'Error', message: 'No se pudo subir la imagen.', buttons: ['OK'] });
                    setUploadPercent(0);
                },
                async () => {
                    const url = await getDownloadURL(storageRef);
                    setFormData(prev => ({ ...prev, foto: url }));
                    setShowCropSection(false);
                    setSrc(null);
                    setUploadPercent(0);
                    presentAlert({ header: 'Éxito', message: 'Imagen subida. Ahora puedes guardar el reporte.', buttons: ['OK'] });
                }
            );
        } catch (error) {
            console.error('Error en handleImageUpload:', error);
            presentAlert({ header: 'Error', message: 'Ocurrió un error inesperado al subir la imagen.', buttons: ['OK'] });
        }
    }, 'image/png', 1);
  }, [completedCrop, user, presentAlert]);


  const handleSave = useCallback(async () => {
    if (!user) { presentAlert({ header: 'Error', message: 'Debe iniciar sesión', buttons: ['OK'] }); return; }

    let finalReporte = { ...formData };
    if (formData.tipo_r === 'Mascota Encontrada') {
      finalReporte = { ...finalReporte, nombre: 'Desconocido', iduser: user.uid };
    }
    
    const requiredFields: (keyof ReportFormData)[] = ['nombre', 'direccion', 'foto', 'descripcion', 'lat', 'lng', 'tipo', 'iduser', 'tipo_r', 'animal', 'tamano', 'fecha', 'color'];
    for (const field of requiredFields) {
        const value = finalReporte[field as keyof typeof finalReporte];
      if (value === undefined || value === null || value === '') {
        presentAlert({ header: 'Error', message: `Complete todos los campos. Falta: ${field}`, buttons: ['OK'] });
        return;
      }
    }

    try {
        const dataToSave = { ...finalReporte };
        if (reportId) {
          await updateDoc(doc(firestore, "marcadores", reportId), dataToSave);
        } else {
          await addDoc(collection(firestore, 'marcadores'), dataToSave);
        }
        presentAlert({ header: 'Correcto', message: `Reporte ${reportId ? 'Modificado' : 'Creado'}`, buttons: ['OK'] });
        resetAndClose();
    } catch (error) { 
        console.error("Save Error: ", error);
        presentAlert({ header: 'Error', message: `No se pudo guardar: ${error}`.slice(0, 200), buttons: ['OK'] }); 
    }
  }, [user, formData, reportId, presentAlert, resetAndClose]);

  const isPerdida = formData.tipo_r === 'Mascota Perdida';

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="reporte-modal">
        <IonHeader className="ion-no-border">
          <IonToolbar className="reporte-toolbar">
            <div className="reporte-header">
              <div className="header-title-section">
                <IonIcon icon={pawOutline} className="header-icon-reporte" />
                <IonTitle className="reporte-title">{reportId ? 'Editar Reporte' : 'Crear Reporte'}</IonTitle>
              </div>
              <IonButton fill="clear" onClick={resetAndClose} className="close-btn-reporte">
                <IonIcon icon={close} />
              </IonButton>
            </div>
          </IonToolbar>
        </IonHeader>

        <IonContent className="reporte-content">
          <div className="photo-upload-section-reporte">
            <div className="photo-preview-container-reporte">
              <div className="photo-preview-reporte">
                <img 
                  src={formData.foto || placeholderImage} 
                  alt="Mascota" 
                  className={formData.foto ? 'has-photo' : 'placeholder'}
                />
              </div>
              
              {!formData.foto && (
                <div className="upload-prompt-reporte">
                  <IonIcon icon={imageOutline} className="upload-icon-reporte" />
                  <p>Agrega una foto</p>
                </div>
              )}
            </div>
  
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={handleFileChange}
            />
  
            <IonButton
              fill="clear"
              className="select-photo-btn-reporte"
              onClick={() => fileInputRef.current?.click()}
            >
              <IonIcon icon={camera} slot="start" />
              {formData.foto ? 'Cambiar Foto' : 'Seleccionar Foto'}
            </IonButton>
          </div>
  
          {showCropSection && src && (
            <div className="crop-section">
              <div className="crop-header">
                <IonIcon icon={imageOutline} />
                <span>Recorta la imagen a tu gusto</span>
              </div>
              
              <div className="crop-container">
                  <ReactCrop 
                      crop={crop} 
                      onChange={c => setCrop(c)} 
                      onComplete={c => setCompletedCrop(c)} 
                      aspect={ASPECT_RATIO}
                  >
                      <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
                  </ReactCrop>
              </div>

              {uploadPercent > 0 && (
                <div className="upload-progress-container">
                  <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                  <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
                </div>
              )}

              <IonButton
                expand="block"
                className="confirm-crop-btn"
                onClick={handleImageUpload} 
                disabled={uploadPercent > 0}
              >
                <IonIcon icon={checkmarkCircle} slot="start" />
                Confirmar y Subir Foto
              </IonButton>
            </div>
          )}
          
          <IonCard className="form-card-reporte">
            <IonCardContent className="form-content-reporte">
              <h4 className="form-section-title-reporte">
                <IonIcon icon={documentTextOutline} />
                Datos del Reporte
              </h4>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={locationOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Dirección
                  </IonLabel>
                  <IonInput
                    value={formData.direccion}
                    readonly
                    className="custom-input-reporte readonly"
                  />
                </IonItem>
              </div>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Tipo de Reporte <span className="required">*</span>
                  </IonLabel>
                  <IonSelect
                    value={formData.tipo_r}
                    onIonChange={e => handleInputChange('tipo_r', e.detail.value)}
                    interface="action-sheet"
                    placeholder="Selecciona el tipo"
                    className="custom-select-reporte"
                  >
                    <IonSelectOption value="Mascota Perdida">Mascota Perdida</IonSelectOption>
                    <IonSelectOption value="Mascota Encontrada">Mascota Encontrada</IonSelectOption>
                  </IonSelect>
                </IonItem>
              </div>
  
              {isPerdida && !reportId && (
                <div className="pets-selection-box">
                  <IonLabel className="selection-label">Selecciona entre tus mascotas</IonLabel>
                  <IonRadioGroup value={selectedPetValue} onIonChange={handleMascotaSelection}>
                    <IonList className="pets-radio-list">
                      {misMascotas.map(mascota => (
                        <IonItem key={mascota.id} className="pet-radio-item" lines="none">
                          <IonRadio slot="start" value={mascota.id.toString()} />
                          <IonLabel>{mascota.nombre}</IonLabel>
                        </IonItem>
                      ))}
                      <IonItem className="pet-radio-item" lines="none">
                        <IonRadio slot="start" value="Otra" />
                        <IonLabel>Otra</IonLabel>
                      </IonItem>
                    </IonList>
                  </IonRadioGroup>
                </div>
              )}
  
              {isPerdida && (
                <div className="form-group-reporte">
                  <IonItem className="custom-item-reporte" lines="none">
                    <IonLabel position="stacked" className="custom-label-reporte">
                      Nombre de la Mascota
                    </IonLabel>
                    <IonInput
                      value={formData.nombre}
                      onIonInput={e => handleInputChange('nombre', e.detail.value!)}
                      placeholder="Ingresa el nombre"
                      className="custom-input-reporte"
                    />
                  </IonItem>
                </div>
              )}
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={calendarOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Fecha del Reporte <span className="required">*</span>
                  </IonLabel>
                  <IonInput
                    type="date"
                    value={formData.fecha}
                    onIonChange={e => handleInputChange('fecha', e.detail.value!)}
                    className="custom-input-reporte"
                  />
                </IonItem>
              </div>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={pawOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Tipo de Animal <span className="required">*</span>
                  </IonLabel>
                  <IonSelect
                    value={formData.animal}
                    onIonChange={e => handleInputChange('animal', e.detail.value)}
                    interface="action-sheet"
                    placeholder="Selecciona el tipo"
                    className="custom-select-reporte"
                  >
                    {animales.map(animal => (
                      <IonSelectOption key={animal.id} value={animal.nombre}>
                        {animal.nombre}
                      </IonSelectOption>
                    ))}
                  </IonSelect>
                </IonItem>
              </div>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={resizeOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Tamaño del Animal
                  </IonLabel>
                  <IonSelect
                    value={formData.tamano}
                    onIonChange={e => handleInputChange('tamano', e.detail.value)}
                    interface="action-sheet"
                    placeholder="Selecciona el tamaño"
                    className="custom-select-reporte"
                  >
                    <IonSelectOption value="Pequeño">Pequeño</IonSelectOption>
                    <IonSelectOption value="Medio">Medio</IonSelectOption>
                    <IonSelectOption value="Grande">Grande</IonSelectOption>
                  </IonSelect>
                </IonItem>
              </div>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte" lines="none">
                  <IonIcon icon={colorPaletteOutline} slot="start" className="item-icon-reporte" />
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Color del Animal
                  </IonLabel>
                  <IonSelect
                    value={formData.color}
                    onIonChange={e => handleInputChange('color', e.detail.value)}
                    interface="action-sheet"
                    placeholder="Selecciona el color"
                    className="custom-select-reporte"
                  >
                    {colores.map(color => (
                      <IonSelectOption key={color.id} value={color.nombre}>
                        {color.nombre}
                      </IonSelectOption>
                    ))}
                  </IonSelect>
                </IonItem>
              </div>
  
              <div className="form-group-reporte">
                <IonItem className="custom-item-reporte textarea-item" lines="none">
                  <IonLabel position="stacked" className="custom-label-reporte">
                    Descripción
                  </IonLabel>
                  <IonTextarea
                    value={formData.descripcion}
                    onIonInput={e => handleInputChange('descripcion', e.detail.value!)}
                    placeholder="Descripción de su reporte de mascota"
                    className="custom-textarea-reporte"
                    autoGrow
                    rows={3}
                  />
                </IonItem>
              </div>
            </IonCardContent>
          </IonCard>
  
          <div className="save-button-container">
            <IonButton
              expand="block"
              className="save-btn-reporte"
              onClick={handleSave}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Guardar Reporte
            </IonButton>
          </div>
  
          <div style={{ height: '20px' }}></div>
        </IonContent>
    </IonModal>
  );
};

export default ReporteMascota;
