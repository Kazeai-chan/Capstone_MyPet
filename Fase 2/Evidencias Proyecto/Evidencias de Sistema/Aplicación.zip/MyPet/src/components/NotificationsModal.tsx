
import React, { useEffect, useState, useContext } from 'react';
import { useHistory } from 'react-router-dom';
import {
  IonButton,
  IonIcon,
  IonBadge,
  IonSpinner,
} from '@ionic/react';
import {
  close,
  notificationsOutline,
  checkmarkCircleOutline,
  closeCircleOutline,
  warningOutline,
  alertCircleOutline,
  timeOutline,
} from 'ionicons/icons';
import './NotificationsModal.css';
import { firestore, requestPermission, doc, updateDoc } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import { collection, query, where, onSnapshot, orderBy, writeBatch, Timestamp, getDoc } from 'firebase/firestore';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Notification {
  id: string;
  title: string;
  body: string;
  read: boolean;
  createdAt: Timestamp;
  icon?: string; 
  link?: string; 
}

const checkSupport = () => 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;

const NotificationsModal: React.FC<NotificationsModalProps> = ({ onClose, isOpen }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSupported, setIsSupported] = useState(checkSupport());
  const [permissionStatus, setPermissionStatus] = useState(isSupported ? Notification.permission : 'unsupported');

  useEffect(() => {
    if (isOpen) {
      const supported = checkSupport();
      setIsSupported(supported);
      setPermissionStatus(supported ? Notification.permission : 'unsupported');

      if (user) {
        // =========================================================================
        // == SINCRONIZACIÓN DE TOKEN AUTOMÁTICA AL ABRIR EL MODAL                ==
        // =========================================================================
        // Si el permiso ya fue concedido, nos aseguramos de que el token esté en Firestore.
        // Esto resuelve el caso donde el usuario dio permiso pero el token no se guardó.
        if (supported && Notification.permission === 'granted') {
            const syncToken = async () => {
                const token = await requestPermission(); // Esto no volverá a pedir permiso, solo obtiene el token
                if (token) {
                    try {
                        const userDocRef = doc(firestore, 'usuarios', user.uid);
                        const userDocSnap = await getDoc(userDocRef);
                        // Guardamos el token si el usuario no tiene uno o si ha cambiado.
                        if (!userDocSnap.exists() || userDocSnap.data()?.fcmToken !== token) {
                            await updateDoc(userDocRef, { fcmToken: token });
                            //console.log("Token FCM sincronizado automáticamente en Firestore.");
                        }
                    } catch (error) {
                        console.error("Error al sincronizar el token FCM:", error);
                    }
                }
            };
            syncToken();
        }
        // =========================================================================

        setLoading(true);
        const q = query(
          collection(firestore, 'notificaciones'),
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
          const fetchedNotifications = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
          } as Notification));
          setNotifications(fetchedNotifications);
          setLoading(false);
        }, (error) => {
          console.error("Error al obtener notificaciones: ", error);
          setLoading(false);
        });

        return () => unsubscribe();
      } else {
        setLoading(false);
      }
    }
  }, [isOpen, user]);

  const handleNotificationClick = async (notification: Notification) => {
    if (!notification.read) {
      const notifRef = doc(firestore, 'notificaciones', notification.id);
      try {
        await updateDoc(notifRef, { read: true });
      } catch (error) {
        console.error("Error al marcar la notificación como leída: ", error);
      }
    }

    if (notification.link) {
      history.push(notification.link);
    }

    onClose();
  };

  const handleRequestPermission = async () => {
    const token = await requestPermission();
    if (token && user) {
      try {
        const userDocRef = doc(firestore, 'usuarios', user.uid);
        await updateDoc(userDocRef, { fcmToken: token });
      } catch (error) {
        console.error("Error al guardar el token en Firestore: ", error);
      }
    }
    setPermissionStatus(Notification.permission);
  };

  const handleMarkAllAsRead = async () => {
    if (!user) return;
    
    const unreadNotifications = notifications.filter(n => !n.read);
    if (unreadNotifications.length === 0) return;

    const batch = writeBatch(firestore);
    unreadNotifications.forEach(notif => {
      const notifRef = doc(firestore, 'notificaciones', notif.id);
      batch.update(notifRef, { read: true });
    });

    try {
      await batch.commit();
    } catch (error) {
      console.error("Error al marcar notificaciones como leídas: ", error);
    }
  };

  const formatTime = (timestamp: Timestamp) => {
    if (!timestamp) return '';
    const date = timestamp.toDate();
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diff / (1000 * 60));
    const diffHours = Math.floor(diff / (1000 * 60 * 60));

    if (diffMinutes < 1) return 'Ahora';
    if (diffMinutes < 60) return `Hace ${diffMinutes} min`;
    if (diffHours < 24) return `Hace ${diffHours} h`;
    return date.toLocaleDateString();
  };

  if (!isOpen) {
    return null;
  }

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="notifications-overlay" onClick={onClose}>
      <div className="notifications-modal-modern" onClick={(e) => e.stopPropagation()}>
        <div className="notifications-header-modern">
          <div className="header-title-wrapper_not">
            <div className="header-icon-circle_not">
              <IonIcon icon={notificationsOutline} className="header-notification-icon" />
              <div className="header-paw-deco-not">🐾</div>
            </div>
            <div className="header-text-section-not">
              <h2 className="notifications-title-modern">Notificaciones</h2>
              {unreadCount > 0 && (
                <IonBadge className="unread-badge-header-not">{unreadCount} nuevas</IonBadge>
              )}
            </div>
          </div>
          <button className="close-btn-modern-not" onClick={onClose}>
            <IonIcon icon={close} />
          </button>
        </div>

        {!isSupported && (
            <div className="permission-alert warning"><div className="alert-icon-wrapper warning-icon-not"><IonIcon icon={warningOutline} /></div><div className="alert-content"><h4 className="alert-title">Navegador no compatible</h4><p className="alert-description">Tu navegador no soporta notificaciones. Prueba con Chrome o Firefox.</p></div></div>
        )}
        {isSupported && permissionStatus === 'default' && (
            <div className="permission-alert info"><div className="alert-icon-wrapper info-icon-not"><IonIcon icon={alertCircleOutline} /></div><div className="alert-content"><h4 className="alert-title">Activa las notificaciones</h4><p className="alert-description">No te pierdas ninguna actualización importante de tu comunidad.</p></div></div>
        )}
        {isSupported && permissionStatus === 'granted' && (
            <div className="permission-alert success"><div className="alert-icon-wrapper success-icon-not"><IonIcon icon={checkmarkCircleOutline} /></div><div className="alert-content"><h4 className="alert-title">Notificaciones activas</h4><p className="alert-description">Recibirás notificaciones sobre mensajes, comentarios y más.</p></div></div>
        )}
        {isSupported && permissionStatus === 'denied' && (
            <div className="permission-alert error"><div className="alert-icon-wrapper error-icon-not"><IonIcon icon={closeCircleOutline} /></div><div className="alert-content"><h4 className="alert-title">Notificaciones bloqueadas</h4><p className="alert-description">Actívalas desde la configuración de tu navegador para recibir actualizaciones.</p></div></div>
        )}

        <div className="notifications-body-modern">
          {loading ? (
            <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '150px'}}>
              <IonSpinner name="crescent" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="empty-notifications">
              <div className="empty-notif-illustration">
                <div className="empty-notif-circle"><IonIcon icon={notificationsOutline} className="empty-notif-icon" /></div>
                <div className="paw-decoratsion paw-1">🐾</div>
                <div className="paw-decoration paw-2">🐾</div>
              </div>
              <h3 className="empty-notif-title">Todo tranquilo por aquí</h3>
              <p className="empty-notif-text">No tienes notificaciones nuevas. Te avisaremos cuando haya algo importante.</p>
            </div>
          ) : (
            <div className="notifications-list-modern">
              {notifications.map((notif) => (
                <div 
                  key={notif.id} 
                  className={`notification-card-modern ${!notif.read ? 'unread' : ''}`}
                  onClick={() => handleNotificationClick(notif)}
                  style={{cursor: 'pointer'}}
                >
                  {!notif.read && <div className="unread-indicator"></div>}
                  <div className="notif-icon-wrapper">
                    <span className="notif-emoji">{notif.icon || '🐾'}</span>
                  </div>
                  <div className="notif-content">
                    <h4 className="notif-title">{notif.title}</h4>
                    <p className="notif-description">{notif.body}</p>
                    <div className="notif-time">
                      <IonIcon icon={timeOutline} className="time-icon-small" />
                      <span>{formatTime(notif.createdAt)}</span>
                    </div>
                  </div>
                  {!notif.read && (
                    <div className="notif-badge-unread">
                      <span>Nuevo</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="notifications-footer-modern">
          {isSupported && permissionStatus === 'default' && (
            <IonButton 
              expand="block" 
              onClick={handleRequestPermission} 
              className="activate-btn-modern"
            >
              <IonIcon icon={notificationsOutline} slot="start" />
              Activar Notificaciones
            </IonButton>
          )}
          
          {notifications.length > 0 && unreadCount > 0 && (
            <IonButton 
              expand="block" 
              fill="clear" 
              onClick={handleMarkAllAsRead}
              className="mark-read-btn"
            >
              Marcar todas como leídas
            </IonButton>
          )}
        </div>

        <div className="modal-paw-bg paw-bg-1">🐾</div>
        <div className="modal-paw-bg paw-bg-2">🐾</div>
      </div>
    </div>
  );
};

export default NotificationsModal;
