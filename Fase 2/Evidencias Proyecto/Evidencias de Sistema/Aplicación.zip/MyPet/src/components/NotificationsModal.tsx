
import React, { useState, useEffect } from 'react';
import { IonIcon, IonButton } from '@ionic/react';
import { closeCircleOutline } from 'ionicons/icons';
import './NotificationsModal.css';
import { requestPermission } from '../firebase';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Pequeña función de utilidad para verificar el soporte.
const checkSupport = () => 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;

const NotificationsModal: React.FC<NotificationsModalProps> = ({ isOpen, onClose }) => {
  // CORRECCIÓN: Hooks en la parte superior.
  const [isSupported, setIsSupported] = useState(checkSupport());
  const [permissionStatus, setPermissionStatus] = useState(isSupported ? Notification.permission : 'unsupported');

  useEffect(() => {
    // Re-evaluar el estado cuando el modal se abre.
    if (isOpen) {
      const supported = checkSupport();
      setIsSupported(supported);
      setPermissionStatus(supported ? Notification.permission : 'unsupported');
    }
  }, [isOpen]);

  const handleRequestPermission = async () => {
    await requestPermission();
    // Actualiza el estado para que la UI refleje el cambio inmediatamente.
    setPermissionStatus(Notification.permission);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="notifications-modal-container" onClick={onClose}>
      <div className="notifications-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="notifications-modal-header">
          <h2>Notificaciones</h2>
          <IonIcon icon={closeCircleOutline} onClick={onClose} className="close-icon" />
        </div>
        <div className="notifications-list">
          {/* Cambiamos el mensaje principal basado en la compatibilidad */}
          {!isSupported ? (
            <div className="notification-item">
                <p>Tu navegador actual no es compatible con las notificaciones push. Prueba con Chrome o Firefox en tu dispositivo.</p>
            </div>
          ) : (
            <div className="notification-item">
                <p>Activa las notificaciones para no perderte ninguna actualización importante.</p>
            </div>
          )}
          <div className="notification-item placeholder">
            <p>No tienes notificaciones nuevas.</p>
          </div>
        </div>
        <div className="notifications-modal-actions">
          {/* Lógica de renderizado condicional basada en el estado */}
          {isSupported && permissionStatus === 'default' && (
            <IonButton expand="block" onClick={handleRequestPermission} className="permission-button">
              Activar Notificaciones
            </IonButton>
          )}
          {isSupported && permissionStatus === 'granted' && (
            <p className="permission-status-granted">✅ Ya tienes las notificaciones activadas.</p>
          )}
          {isSupported && permissionStatus === 'denied' && (
            <p className="permission-status-denied">❌ Bloqueaste las notificaciones. Debes activarlas desde la configuración de tu navegador.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotificationsModal;
