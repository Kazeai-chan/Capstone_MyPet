
import React, { useState, useEffect, useContext } from 'react';
import { IonContent, IonIcon, IonAvatar, IonTextarea, IonButton, IonToast, IonButtons, IonHeader, IonTitle, IonToolbar, IonChip } from '@ionic/react';
import { useHistory } from 'react-router-dom';
import { close, heart, chatboxEllipsesOutline, heartOutline, sendSharp, timeOutline } from 'ionicons/icons';
import { doc, getDoc, collection, query, where, getDocs, addDoc, updateDoc } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './Tema.css';

interface TemaProps {
  idTema: string;
  onClose: () => void;
}

export const Tema: React.FC<TemaProps> = ({ idTema, onClose }) => {
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();
  const [tema, setTema] = useState<any>(null);
  const [comentarios, setComentarios] = useState<any[]>([]);
  const [coment, setComent] = useState({ c_cuerpo: '' });
  const [meGusta, setMeGusta] = useState(false);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    const traeTema = async () => {
      const docRef = doc(firestore, 'temas', idTema);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setTema({ id: docSnap.id, ...docSnap.data() });
      }
    };

    const traeComentarios = async () => {
      const q = query(collection(firestore, 'comentarios'), where('idtema', '==', idTema));
      const querySnapshot = await getDocs(q);
      const coments: any[] = [];
      querySnapshot.forEach((doc) => {
        coments.push({ id: doc.id, ...doc.data() });
      });
      setComentarios(coments);
    };

    const revisaGusta = async () => {
      if (user) {
        const q = query(
          collection(firestore, 'gustas'),
          where('iduser', '==', user.uid),
          where('idtema', '==', idTema)
        );
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          setMeGusta(true);
        }
      }
    };

    traeTema();
    traeComentarios();
    revisaGusta();
  }, [idTema, user]);

  const handleComentChange = (e: any) => {
    setComent({ ...coment, [e.target.name]: e.target.value });
  };

  const Comentar = async () => {
    if (coment.c_cuerpo.trim() === '') {
      alert('Debe escribir un comentario');
      return;
    }

    if (user && tema) {
      const newComent = {
        c_avatar: user.fotouser,
        c_cuerpo: coment.c_cuerpo,
        c_fecha: new Date(),
        c_iduser: user.uid,
        c_nombre: user.name,
        idtema: idTema,
      };

      await addDoc(collection(firestore, 'comentarios'), newComent);

      const temaRef = doc(firestore, 'temas', idTema);
      await updateDoc(temaRef, {
        c_avatar: user.fotouser,
        c_nombre: user.name,
        comentario: coment.c_cuerpo,
        n_com: tema.n_com + 1,
      });

      setComent({ c_cuerpo: '' });
      // Refresh comments after posting
      const q = query(collection(firestore, 'comentarios'), where('idtema', '==', idTema));
      const querySnapshot = await getDocs(q);
      const coments: any[] = [];
      querySnapshot.forEach((doc) => {
        coments.push({ id: doc.id, ...doc.data() });
      });
      setComentarios(coments);
    }
  };

  const agregaGusta = async () => {
    if (meGusta) {
      alert('Ya le gusta este comentario');
    } else {
      if (user && tema) {
        const newGusta = {
          iduser: user.uid,
          idtema: idTema,
        };

        await addDoc(collection(firestore, 'gustas'), newGusta);

        const temaRef = doc(firestore, 'temas', idTema);
        await updateDoc(temaRef, {
          n_gusta: tema.n_gusta + 1,
        });
        
        setTema({...tema, n_gusta: tema.n_gusta + 1});
        setMeGusta(true);
        setShowToast(true);
      }
    }
  };

  const formatDate = (seconds: number) => {
    return new Date(seconds * 1000).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    const diffMinutes = Math.floor(diffSeconds / 60);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSeconds < 60) return 'Ahora';
    if (diffMinutes < 60) return `Hace ${diffMinutes}m`;
    if (diffHours < 24) return `Hace ${diffHours}h`;
    return `Hace ${diffDays}d`;
  };
  
  const goToProfile = (userId: string) => {
    if(userId) {
      onClose(); // Cierra el modal
      history.push(`/perfil/${userId}`); // Navega a la página de perfil
    }
  };

  if (!tema) return null;

  return (
    <>
      <IonHeader className="tema-header-modal">
        <IonToolbar className="tema-toolbar">
          <IonTitle className="tema-header-title">Discusión</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={onClose} className="close-btn-modern">
              <IonIcon icon={close} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent className="tema-content-modern">
        {tema.foto && (
          <div className="tema-hero-image">
            <img src={tema.foto} alt={tema.titulo} />
            <div className="hero-overlay"></div>
          </div>
        )}

        <div className="tema-main-content">
          <div className="tema-title-section">
            <h1 className="tema-title-modern">{tema.titulo}</h1>
            
            <div className="tema-author-info" onClick={() => goToProfile(tema.iduser)} style={{ cursor: 'pointer' }}>
              <IonAvatar className="author-avatar">
                <img alt={tema.nombreuser} src={tema.avatar} />
              </IonAvatar>
              <div className="author-details">
                <div className="author-name">{tema.nombreuser}</div>
                <div className="author-meta">
                  <IonIcon icon={timeOutline} className="meta-icon-small" />
                  <span>{formatDate(tema.fecha.seconds)}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="tema-body-section">
            <p className="tema-body-text">{tema.cuerpo}</p>
          </div>

          <div className="tema-stats-section">
            <IonChip className="stat-chip-modern" onClick={agregaGusta}>
              <IonIcon icon={meGusta ? heart : heartOutline} className={meGusta ? 'heart-active' : ''} />
              <span>{tema.n_gusta}</span>
            </IonChip>
            <IonChip className="stat-chip-modern">
              <IonIcon icon={chatboxEllipsesOutline} />
              <span>{comentarios.length} respuestas</span>
            </IonChip>
          </div>

          <div className="section-divider">
            <span className="divider-text">Respuestas</span>
          </div>

          <div className="comentarios-list">
            {comentarios.map((comentario) => (
              <div key={comentario.id} className="comentario-card-modern">
                <IonAvatar className="comentario-avatar-modern" onClick={() => goToProfile(comentario.c_iduser)} style={{ cursor: 'pointer' }}>
                  <img alt={comentario.c_nombre} src={comentario.c_avatar} />
                </IonAvatar>
                <div className="comentario-content-modern">
                  <div className="comentario-header-modern">
                    <span className="comentario-author-name">{comentario.c_nombre}</span>
                    <span className="comentario-time">{formatTimeAgo(comentario.c_fecha.toDate())}</span>
                  </div>
                  <p className="comentario-text">{comentario.c_cuerpo}</p>
                </div>
              </div>
            ))}
          </div>

        </div>

        <IonToast
          isOpen={showToast}
          onDidDismiss={() => setShowToast(false)}
          message={meGusta ? "¡Te gusta este tema!" : "Ya no te gusta este tema"}
          duration={2000}
          position="top"
          color={meGusta ? "success" : "medium"}
          className="toast-modern"
        />
      </IonContent>

      <div className="comentario-input-fixed">
        <IonAvatar className="input-avatar">
          <img alt="Tu perfil" src={user?.fotouser} />
        </IonAvatar>
        <div className="input-wrapper">
          <IonTextarea
            value={coment.c_cuerpo}
            onIonChange={handleComentChange}
            placeholder="Escribe tu respuesta..."
            className="textarea-modern"
            autoGrow
            rows={1}
            name="c_cuerpo"
          />
          <IonButton
            onClick={Comentar}
            disabled={!coment.c_cuerpo.trim()}
            className="send-btn-modern"
            fill="clear"
          >
            <IonIcon icon={sendSharp} />
          </IonButton>
        </div>
      </div>
    </>
  );
};
