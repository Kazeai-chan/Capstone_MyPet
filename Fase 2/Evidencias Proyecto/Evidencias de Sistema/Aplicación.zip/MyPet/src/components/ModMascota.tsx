
import React, { useState, useRef, useEffect, useCallback, useContext } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonButton, IonContent, 
  IonItem, IonInput, IonLabel, IonSelect, IonSelectOption,
  IonAlert, IonProgressBar, useIonAlert,
  IonCard, IonCardContent, IonIcon, IonAvatar, IonChip
} from '@ionic/react';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import './ModMascota.css';

import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { doc, getDoc, collection, getDocs, orderBy, query, writeBatch } from "firebase/firestore";
import { firestore } from '../firebase';
import { UserContext } from '../context/UserContext';
import { calendarOutline, camera, checkmarkCircle, close, colorPaletteOutline, imageOutline, pawOutline, resizeOutline, trashOutline } from 'ionicons/icons';

interface ModMascotaProps {
  isOpen: boolean;
  onClose: () => void;
  petId: string | null;
}

interface Mascota {
  id: string; animal: string; color: string; foto: string; iduser: string;
  nacimiento: string; nombre: string; propia: boolean; raza: string; tamano: string;
  colorOjos?: string;
  pelaje?: string;
}

interface SelectOption { id: string; nombre: string; }

const ModMascota: React.FC<ModMascotaProps> = ({ isOpen, onClose, petId }) => {
  const { user } = useContext(UserContext);
  const [mascota, setMascota] = useState<Partial<Mascota>>({});
  const [uploadPercent, setUploadPercent] = useState(0);
  const [presentAlert] = useIonAlert();

  const [animales, setAnimales] = useState<SelectOption[]>([]);
  const [colores, setColores] = useState<SelectOption[]>([]);
  const [razas, setRazas] = useState<SelectOption[]>([]);
  const [tamanos, setTamanos] = useState<SelectOption[]>([]);
  const [coloresOjos, setColoresOjos] = useState<SelectOption[]>([]);
  const [pelajes, setPelajes] = useState<SelectOption[]>([]);

  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [showCropSection, setShowCropSection] = useState(false);

  const imgRef = useRef<HTMLImageElement | null>(null);
  const originalFotoUrlRef = useRef<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);

  const onCloseRef = useRef(onClose);
  useEffect(() => { onCloseRef.current = onClose; }, [onClose]);

  const resetAndClose = useCallback(() => {
    setMascota({});
    setUploadPercent(0);
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setShowCropSection(false);
    originalFotoUrlRef.current = null;
    onCloseRef.current();
  }, []);

  useEffect(() => {
    const fetchInitialData = async () => {
        try {
            const collectionNames = ['animales', 'colores', 'razas', 'tamanos', 'coloresOjos', 'pelajes'];
            const queries = collectionNames.map(name => query(collection(firestore, name), orderBy('nombre')));
            const snapshots = await Promise.all(queries.map(q => getDocs(q)));
            const [animalesData, coloresData, razasData, tamanosData, coloresOjosData, pelajesData] = snapshots.map(snapshot => 
                snapshot.docs.map(d => ({ id: d.id, ...d.data() } as SelectOption))
            );
            setAnimales(animalesData);
            setColores(coloresData);
            setRazas(razasData);
            setTamanos(tamanosData);
            setColoresOjos(coloresOjosData);
            setPelajes(pelajesData);
        } catch (error) {
            console.error("Error fetching initial data:", error);
            presentAlert({ header: 'Error', message: 'No se pudieron cargar las opciones del formulario.', buttons: ['OK'] });
        }
    };
    if (isOpen) fetchInitialData();
  }, [isOpen, presentAlert]);

  useEffect(() => {
    const fetchPetData = async () => {
      if (petId && isOpen) {
        try {
          const docRef = doc(firestore, "mascotas", petId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const petData = { id: docSnap.id, ...docSnap.data() } as Mascota;
            setMascota(petData);
            originalFotoUrlRef.current = petData.foto;
          } else {
            presentAlert({ header: 'Error', message: 'No se encontró la mascota.', buttons: ['OK'] });
            resetAndClose();
          }
        } catch (error) {
          console.error("Error fetching pet data:", error);
          presentAlert({ header: 'Error', message: 'No se pudo cargar la info de la mascota.', buttons: ['OK'] });
          resetAndClose();
        }
      }
    };
    fetchPetData();
  }, [petId, isOpen, presentAlert, resetAndClose]);

  const triggerFileInput = () => fileInputRef.current?.click();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => { imgRef.current = e.currentTarget; };

  const handleUploadImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current || !petId) return;
    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      setUploadPercent(1);
      try {
        const storage = getStorage();
        const filePath = `mascotas/${petId}/${Date.now()}_cropped.png`;
        const storageRef = ref(storage, filePath);
        const uploadTask = uploadBytesResumable(storageRef, blob);

        uploadTask.on('state_changed',
          (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
          (error) => {
            console.error('Error al subir archivo:', error);
            presentAlert({ header: 'Error', message: 'No se pudo subir la imagen.', buttons: ['OK'] });
            setUploadPercent(0);
          },
          async () => {
            const downloadURL = await getDownloadURL(storageRef);
            
            // --- BATCH WRITE for photo update ---
            const batch = writeBatch(firestore);
            const privatePetRef = doc(firestore, "mascotas", petId);
            const publicPetRef = doc(firestore, "mascota_publica", petId);

            batch.update(privatePetRef, { foto: downloadURL });
            batch.update(publicPetRef, { foto: downloadURL });
            await batch.commit();
            
            if (originalFotoUrlRef.current && originalFotoUrlRef.current.includes('firebasestorage')) {
              await deleteObject(ref(getStorage(), originalFotoUrlRef.current)).catch(err => console.warn("Old photo delete failed:", err));
            }

            setMascota(prev => ({ ...prev, foto: downloadURL }));
            originalFotoUrlRef.current = downloadURL;
            setShowCropSection(false);
            setSrc(null);
            setUploadPercent(0);
            presentAlert({ header: 'Éxito', message: 'La foto ha sido actualizada.', buttons: ['OK'] });
          }
        );
      } catch (error) {
        console.error('Error in handleUploadImage:', error);
        setUploadPercent(0);
        presentAlert({ header: 'Error', message: 'Ocurrió un error inesperado al subir la imagen.', buttons: ['OK'] });
      }
    }, 'image/png', 1);
  }, [completedCrop, petId, presentAlert]);

  const handleUpdateMascota = async () => {
    if (!petId || !mascota || !user) return;
    try {
      const batch = writeBatch(firestore);
      const privatePetRef = doc(firestore, "mascotas", petId);
      const publicPetRef = doc(firestore, "mascota_publica", petId);

      // Private data (all fields from state)
      const { id, ...privatePetData } = mascota;
      batch.update(privatePetRef, privatePetData);

      // Public data (only specific fields)
      const publicPetData = {
        nombre: mascota.nombre,
        raza: mascota.raza,
        nacimiento: mascota.nacimiento,
        animal: mascota.animal,
        foto: mascota.foto,
        ownerData: {
          uid: user.uid,
          name: user.name,
          fotouser: user.fotouser,
          contacto: user.contacto || null,
        }
      };
      batch.update(publicPetRef, publicPetData);

      await batch.commit();

      presentAlert({ header: 'Correcto', message: 'Mascota Modificada', buttons: ['OK']});
      resetAndClose();
    } catch (e) {
      console.error("Error actualizando mascota con batch:", e);
      presentAlert({ header: 'Error', message: 'No se pudo actualizar la mascota.', buttons: ['OK']});
    }
  };

  const handleDeleteMascota = async () => {
    if (!petId || !mascota?.foto) return;
    try {
      // 1. Delete image from storage first
      if (mascota.foto.includes('firebasestorage')) {
        await deleteObject(ref(getStorage(), mascota.foto)).catch(err => console.warn("Image delete failed:", err));
      }

      // 2. Batch delete documents from Firestore
      const batch = writeBatch(firestore);
      const privatePetRef = doc(firestore, "mascotas", petId);
      const publicPetRef = doc(firestore, "mascota_publica", petId);
      
      batch.delete(privatePetRef);
      batch.delete(publicPetRef);
      await batch.commit();

      presentAlert({ header: 'Eliminada', message: 'Mascota eliminada correctamente', buttons: ['OK']});
      resetAndClose();
    } catch (error) {
      console.error("Error eliminando mascota con batch:", error);
      presentAlert({ header: 'Error', message: 'No se pudo eliminar la mascota.', buttons: ['OK']});
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="mod-mascota-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="modal-toolbar">
          <div className="modal-header-content">
            <h2>Modificar Mascota</h2>
            <IonButton fill="clear" onClick={resetAndClose} className="close-btn-modal"><IonIcon icon={close} /></IonButton>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="mod-mascota-content">
        <div className="photo-section">
          <div className="photo-container">
            <IonAvatar className="pet-photo-large"><img src={mascota.foto} alt={mascota.nombre} /></IonAvatar>
            <button className="change-photo-btn" onClick={triggerFileInput}><IonIcon icon={camera} /></button>
          </div>
          <h3 className="pet-name-display">{mascota.nombre}</h3>
          <IonChip className="pet-type-chip"><IonIcon icon={pawOutline} /><IonLabel>{mascota.animal}</IonLabel></IonChip>
          <input ref={fileInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleFileChange} />
        </div>
        {showCropSection && src && (
          <div className="crop-section">
            <div className="crop-header"><IonIcon icon={imageOutline} /><span>Recorta la nueva imagen</span></div>
            <div className="crop-container">
              <ReactCrop crop={crop} onChange={setCrop} onComplete={setCompletedCrop} aspect={1} circularCrop>
                <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
              </ReactCrop>
            </div>
            {uploadPercent > 0 && (
              <div className="upload-progress-container">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}
            <IonButton expand="block" className="confirm-crop-btn" onClick={handleUploadImage} disabled={uploadPercent > 0}>
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Cambiar Foto
            </IonButton>
          </div>
        )}

        <IonCard className="form-card">
          <IonCardContent className="form-content">
            <h4 className="form-section-title">Información de la Mascota</h4>

            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Nombre</IonLabel><IonInput value={mascota.nombre} onIonInput={e => setMascota(p => ({...p, nombre: e.detail.value!}))} /></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={calendarOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Fecha de Nacimiento</IonLabel><IonInput type="date" value={mascota.nacimiento} onIonInput={e => setMascota(p => ({...p, nacimiento: e.detail.value!}))} /></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Tipo de Animal</IonLabel><IonSelect value={mascota.animal} onIonChange={e => setMascota(p => ({...p, animal: e.detail.value}))} interface="action-sheet" className="custom-select">{animales.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Raza</IonLabel><IonSelect value={mascota.raza} onIonChange={e => setMascota(p => ({...p, raza: e.detail.value}))} interface="action-sheet" className="custom-select">{razas.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={colorPaletteOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Color de Pelaje</IonLabel><IonSelect value={mascota.color} onIonChange={e => setMascota(p => ({...p, color: e.detail.value}))} interface="action-sheet" className="custom-select">{colores.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={colorPaletteOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Color de Ojos</IonLabel><IonSelect value={mascota.colorOjos} onIonChange={e => setMascota(p => ({...p, colorOjos: e.detail.value}))} interface="action-sheet" className="custom-select" placeholder="No especificado">{coloresOjos.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={resizeOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Tamaño</IonLabel><IonSelect value={mascota.tamano} onIonChange={e => setMascota(p => ({...p, tamano: e.detail.value}))} interface="action-sheet" className="custom-select">{tamanos.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>
            <div className="form-group"><IonItem className="custom-item" lines="none"><IonIcon icon={pawOutline} slot="start" className="item-icon" /><IonLabel position="stacked" className="custom-label">Tipo de Pelaje</IonLabel><IonSelect value={mascota.pelaje} onIonChange={e => setMascota(p => ({...p, pelaje: e.detail.value}))} interface="action-sheet" className="custom-select" placeholder="No especificado">{pelajes.map(o => (<IonSelectOption key={o.id} value={o.nombre}>{o.nombre}</IonSelectOption>))}</IonSelect></IonItem></div>

          </IonCardContent>
        </IonCard>

        <div className="action-buttons">
          <IonButton expand="block" className="save-btn" onClick={handleUpdateMascota} disabled={showCropSection}><IonIcon icon={checkmarkCircle} slot="start" />Guardar Cambios</IonButton>
          <IonButton expand="block" fill="outline" className="delete-btn" onClick={() => setShowDeleteAlert(true)} disabled={showCropSection}><IonIcon icon={trashOutline} slot="start" />Eliminar Mascota</IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>

      <IonAlert isOpen={showDeleteAlert} onDidDismiss={() => setShowDeleteAlert(false)} header="¿Eliminar Mascota?" message="Esta acción no se puede deshacer. ¿Estás seguro?" buttons={[{ text: 'Cancelar', role: 'cancel' }, { text: 'Eliminar', role: 'destructive', handler: handleDeleteMascota }]} />
    </IonModal>
  );
};

export default ModMascota;
