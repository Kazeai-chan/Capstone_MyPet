import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  IonModal, IonHeader, IonToolbar, IonButton, IonContent, 
  IonItem, IonInput, IonLabel, IonSelect, IonSelectOption,
  IonAlert, IonProgressBar, useIonAlert,
  IonCard,
  IonCardContent,
  IonIcon,
  IonAvatar,
  IonChip
} from '@ionic/react';
import ReactCrop, { type Crop, type PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import './ModMascota.css';

import { getStorage, ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { doc, getDoc, updateDoc, deleteDoc, collection, getDocs, orderBy, query } from "firebase/firestore";
//import { UserContext, UserContextType } from '../context/UserContext';
import { firestore } from '../firebase';
import { calendarOutline, camera, checkmarkCircle, close, colorPaletteOutline, imageOutline, pawOutline, resizeOutline, trashOutline } from 'ionicons/icons';

interface ModMascotaProps {
  isOpen: boolean;
  onClose: () => void;
  petId: string | null;
}

interface Mascota {
  id: string; animal: string; color: string; foto: string; iduser: string;
  nacimiento: string; nombre: string; propia: boolean; raza: string; tamano: string;
}
interface Animal { id: string; nombre: string; }
interface Color { id: string; nombre: string; }

const ModMascota: React.FC<ModMascotaProps> = ({ isOpen, onClose, petId }) => {
  //const { user } = useContext<UserContextType>(UserContext);
  const [mascota, setMascota] = useState<Partial<Mascota>>({});
  const [uploadPercent, setUploadPercent] = useState(0);
  const [animales, setAnimales] = useState<Animal[]>([]);
  const [colores, setColores] = useState<Color[]>([]);
  const [presentAlert] = useIonAlert();

  // States for image cropping
  const [src, setSrc] = useState<string | null>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [showCropSection, setShowCropSection] = useState(false);

  const imgRef = useRef<HTMLImageElement | null>(null);
  const originalFotoUrlRef = useRef<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);

  const resetAndClose = useCallback(() => {
    setMascota({});
    setUploadPercent(0);
    setSrc(null);
    setCrop(undefined);
    setCompletedCrop(undefined);
    setShowCropSection(false);
    originalFotoUrlRef.current = null;
    onClose();
  }, [onClose]);

  useEffect(() => {
    const fetchPetData = async () => {
      if (!petId) return;
      const docRef = doc(firestore, "mascotas", petId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const petData = { id: docSnap.id, ...docSnap.data() } as Mascota;
        setMascota(petData);
        originalFotoUrlRef.current = petData.foto;
      } else {
        presentAlert({ header: 'Error', message: 'No se encontró la mascota.', buttons: ['OK'] });
        resetAndClose();
      }
    };
    const fetchInitialData = async () => {
        const animalesQuery = query(collection(firestore, 'animales'), orderBy('nombre'));
        const coloresQuery = query(collection(firestore, 'colores'), orderBy('nombre'));
        const [animalesSnapshot, coloresSnapshot] = await Promise.all([ getDocs(animalesQuery), getDocs(coloresQuery) ]);
        setAnimales(animalesSnapshot.docs.map(d => ({ id: d.id, ...(d.data() as {nombre: string}) })));
        setColores(coloresSnapshot.docs.map(d => ({ id: d.id, ...(d.data() as {nombre: string}) })));
    };
    if (isOpen) {
      fetchPetData();
      fetchInitialData();
    }
}, [petId, isOpen, presentAlert, resetAndClose]);

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setCrop(undefined);
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setSrc(reader.result?.toString() || null);
        setShowCropSection(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    imgRef.current = e.currentTarget;
  };

  const handleUploadImage = useCallback(async () => {
    if (!completedCrop || !imgRef.current || !petId) {
        presentAlert({ header: 'Atención', message: 'Por favor, selecciona y recorta una imagen primero.', buttons: ['OK'] });
        return;
    }
    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) { throw new Error('No se pudo obtener el contexto 2D'); }
    
    ctx.drawImage(image, completedCrop.x * scaleX, completedCrop.y * scaleY, completedCrop.width * scaleX, completedCrop.height * scaleY, 0, 0, completedCrop.width, completedCrop.height);

    canvas.toBlob(async (blob) => {
        if (!blob) {
            presentAlert({ header: 'Error', message: 'No se pudo crear el archivo de imagen.', buttons: ['OK'] });
            return;
        }
        try {
            const storage = getStorage();
            const filePath = `mascotas/${petId}/${Date.now()}_cropped.png`;
            const storageRef = ref(storage, filePath);
            const uploadTask = uploadBytesResumable(storageRef, blob);

            uploadTask.on('state_changed',
                (snapshot) => setUploadPercent((snapshot.bytesTransferred / snapshot.totalBytes) * 100),
                (error) => {
                    console.error('Error al subir archivo:', error);
                    presentAlert({ header: 'Error', message: 'No se pudo subir la imagen.', buttons: ['OK'] });
                    setUploadPercent(0);
                },
                async () => {
                    const downloadURL = await getDownloadURL(storageRef);
                    const petRef = doc(firestore, "mascotas", petId);
                    await updateDoc(petRef, { foto: downloadURL });

                    if (originalFotoUrlRef.current && originalFotoUrlRef.current !== downloadURL) {
                      const oldPhotoRef = ref(getStorage(), originalFotoUrlRef.current);
                      deleteObject(oldPhotoRef).catch(err => console.error("Error al borrar imagen antigua:", err));
                    }

                    setMascota(prev => ({ ...prev, foto: downloadURL }));
                    originalFotoUrlRef.current = downloadURL;

                    setShowCropSection(false);
                    setSrc(null);
                    setUploadPercent(0);
                    presentAlert({ header: 'Éxito', message: 'La foto ha sido actualizada.', buttons: ['OK'] });
                }
            );
        } catch (error) {
            console.error('Error en handleUploadImage:', error);
            presentAlert({ header: 'Error', message: 'Ocurrió un error inesperado al subir la imagen.', buttons: ['OK'] });
        }
    }, 'image/png', 1);
  }, [completedCrop, petId, presentAlert]);

  const handleUpdateMascota = async () => {
    if (!petId || !mascota) return;
    try {
      const petRef = doc(firestore, "mascotas", petId);
      const { id, ...petData } = mascota;
      await updateDoc(petRef, petData);
      presentAlert({ header: 'Correcto', message: 'Mascota Modificada', buttons: ['OK']});
      resetAndClose();
    } catch (e) {
      presentAlert({ header: 'Error', message: 'No se pudo actualizar la mascota.', buttons: ['OK']});
    }
  };

  const handleDeleteMascota = async () => {
    if (!petId || !mascota?.foto) return;
    try {
        const fileRef = ref(getStorage(), mascota.foto);
        await deleteObject(fileRef).catch(err => console.warn("La imagen no existía o ya fue borrada:", err));
        const petRef = doc(firestore, "mascotas", petId);
        await deleteDoc(petRef);
        presentAlert({ header: 'Eliminada', message: 'Mascota eliminada correctamente', buttons: ['OK']});
        resetAndClose();
    } catch (error) {
        presentAlert({ header: 'Error', message: 'No se pudo eliminar la mascota.', buttons: ['OK']});
    }
  };

  return (
    <IonModal isOpen={isOpen} onDidDismiss={resetAndClose} className="mod-mascota-modal">
      <IonHeader className="ion-no-border">
        <IonToolbar className="modal-toolbar">
          <div className="modal-header-content">
            <h2>Modificar Mascota</h2>
            <IonButton fill="clear" onClick={resetAndClose} className="close-btn-modal">
              <IonIcon icon={close} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="mod-mascota-content">
        <div className="photo-section">
          <div className="photo-container">
            <IonAvatar className="pet-photo-large">
              <img src={mascota.foto} alt={mascota.nombre} />
            </IonAvatar>
            <button
              className="change-photo-btn"
              onClick={triggerFileInput} 
            >
              <IonIcon icon={camera} />
            </button>
          </div>
          
          <h3 className="pet-name-display">{mascota.nombre}</h3>
          <IonChip className="pet-type-chip">
            <IonIcon icon={pawOutline} />
            <IonLabel>{mascota.animal}</IonLabel>
          </IonChip>
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
        </div>

        {showCropSection && src && (
          <div className="crop-section">
            <div className="crop-header">
              <IonIcon icon={imageOutline} />
              <span>Recorta la nueva imagen</span>
            </div>
            
            <div className="crop-container">
                <ReactCrop 
                    crop={crop} 
                    onChange={c => setCrop(c)} 
                    onComplete={c => setCompletedCrop(c)} 
                    aspect={1} 
                    circularCrop
                >
                    <img ref={imgRef} src={src} onLoad={onImageLoad} alt="Recorte" className="crop-image" />
                </ReactCrop>
            </div>

            {uploadPercent > 0 && (
              <div className="upload-progress-container">
                <IonProgressBar value={uploadPercent / 100} className="custom-progress-bar" />
                <span className="progress-text">Subiendo... {Math.round(uploadPercent)}%</span>
              </div>
            )}

            <IonButton
              expand="block"
              className="confirm-crop-btn"
              onClick={handleUploadImage} 
              disabled={uploadPercent > 0}
            >
              <IonIcon icon={checkmarkCircle} slot="start" />
              Confirmar y Cambiar Foto
            </IonButton>
          </div>
        )}

        <IonCard className="form-card">
          <IonCardContent className="form-content">
            <h4 className="form-section-title">Información de la Mascota</h4>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Nombre de la mascota
                </IonLabel>
                <IonInput
                  value={mascota.nombre}
                  onIonInput={e => setMascota(p => ({...p, nombre: e.detail.value!}))}
                  className="custom-input"
                  placeholder="Ingresa el nombre"
                />
              </IonItem>
            </div>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={calendarOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Fecha de Nacimiento
                </IonLabel>
                <IonInput
                  type="date"
                  value={mascota.nacimiento}
                  onIonChange={e => setMascota(p => ({...p, nacimiento: e.detail.value!}))}
                  className="custom-input"
                />
              </IonItem>
            </div>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Tipo de Animal
                </IonLabel>
                <IonSelect
                  value={mascota.animal}
                  onIonChange={e => setMascota(p => ({...p, animal: e.detail.value}))}
                  interface="action-sheet"
                  className="custom-select"
                >
                  {animales.map(animal => (
                    <IonSelectOption key={animal.id} value={animal.nombre}>
                      {animal.nombre}
                    </IonSelectOption>
                  ))}
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={pawOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Raza del Animal
                </IonLabel>
                <IonSelect
                  value={mascota.raza}
                  onIonChange={e => setMascota(p => ({...p, raza: e.detail.value}))}
                  interface="action-sheet"
                  className="custom-select"
                >
                  <IonSelectOption value="Hogareño">Hogareño</IonSelectOption>
                  <IonSelectOption value="Quiltro">Quiltro</IonSelectOption>
                  <IonSelectOption value="De Raza">De Raza</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={resizeOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Tamaño del Animal
                </IonLabel>
                <IonSelect
                  value={mascota.tamano}
                  onIonChange={e => setMascota(p => ({...p, tamano: e.detail.value}))}
                  interface="action-sheet"
                  className="custom-select"
                >
                  <IonSelectOption value="Pequeño">Pequeño</IonSelectOption>
                  <IonSelectOption value="Medio">Medio</IonSelectOption>
                  <IonSelectOption value="Grande">Grande</IonSelectOption>
                </IonSelect>
              </IonItem>
            </div>

            <div className="form-group">
              <IonItem className="custom-item" lines="none">
                <IonIcon icon={colorPaletteOutline} slot="start" className="item-icon" />
                <IonLabel position="stacked" className="custom-label">
                  Color del Animal
                </IonLabel>
                <IonSelect
                  value={mascota.color}
                  onIonChange={e => setMascota(p => ({...p, color: e.detail.value}))}
                  interface="action-sheet"
                  className="custom-select"
                >
                  {colores.map(color => (
                    <IonSelectOption key={color.id} value={color.nombre}>
                      {color.nombre}
                    </IonSelectOption>
                  ))}
                </IonSelect>
              </IonItem>
            </div>
          </IonCardContent>
        </IonCard>

        <div className="action-buttons">
          <IonButton
            expand="block"
            className="save-btn"
            onClick={handleUpdateMascota}
            disabled={showCropSection}
          >
            <IonIcon icon={checkmarkCircle} slot="start" />
            Guardar Cambios
          </IonButton>

          <IonButton
            expand="block"
            fill="outline"
            className="delete-btn"
            onClick={() => setShowDeleteAlert(true)}
            disabled={showCropSection}
          >
            <IonIcon icon={trashOutline} slot="start" />
            Eliminar Mascota
          </IonButton>
        </div>

        <div style={{ height: '20px' }}></div>
      </IonContent>

      <IonAlert
        isOpen={showDeleteAlert}
        onDidDismiss={() => setShowDeleteAlert(false)}
        header="¿Eliminar Mascota?"
        message="Esta acción no se puede deshacer. ¿Estás seguro de eliminar esta mascota?"
        buttons={[
          {
            text: 'Cancelar',
            role: 'cancel',
            cssClass: 'alert-cancel-btn'
          },
          {
            text: 'Eliminar',
            role: 'destructive',
            cssClass: 'alert-delete-btn',
            handler: handleDeleteMascota
          }
        ]}
        cssClass="custom-alert"
      />
    </IonModal>
  );
};

export default ModMascota;
