
import type { Express } from 'express';
const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app: Express) {
  // Proxy para la Cloud Function que actúa como proxy de Google Maps
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'https://us-central1-instant-vent-423002-f1.cloudfunctions.net',
      changeOrigin: true,
      pathRewrite: (path: string, req: any) => {
        // Reescribe /api/maps/etc a /googleMapsProxy/maps/etc
        const newPath = path.replace('^/api', '/googleMapsProxy');
        console.log(`[Proxy] Rewriting /api path from: ${path} to: ${newPath}`);
        return newPath;
      },
      onProxyReq: (proxyReq: any, req: any, res: any) => {
        // Las Cloud Functions de 2ª Gen exponen la URL original en este header.
        // Lo añadimos para asegurar compatibilidad si migras en el futuro.
        proxyReq.setHeader('x-forwarded-host', req.headers.host);
      }
    })
  );

  // Proxy para la Cloud Function que obtiene las noticias
  app.use(
    '/getNews',
    createProxyMiddleware({
      target: 'https://us-central1-instant-vent-423002-f1.cloudfunctions.net',
      changeOrigin: true,
      onProxyReq: (proxyReq: any, req: any, res: any) => {
        proxyReq.setHeader('x-forwarded-host', req.headers.host);
      }
    })
  );
};
