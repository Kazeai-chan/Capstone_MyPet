
import { initializeApp } from "firebase/app";
import { getFirestore, doc, updateDoc } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";
import { getMessaging, getToken, onMessage, isSupported, Messaging } from "firebase/messaging";

// =======================================================================
// == CLAVE DE API CENTRALIZADA PARA GOOGLE MAPS                        ==
// =======================================================================
export const GOOGLE_MAPS_API_KEY = "AIzaSyDZvardedtAdnxBvNIGrWDe1Ye-GDjVjoo";


export const firebaseConfig = {
  apiKey: "AIzaSyC-IQfYVGquGeLgD46equ2MO58Eayeba-A",
  authDomain: "instant-vent-423002-f1.firebaseapp.com",
  projectId: "instant-vent-423002-f1",
  storageBucket: "instant-vent-423002-f1.appspot.com",
  messagingSenderId: "512313065132",
  appId: "1:512313065132:web:21cd578443f1cf5a046909"
};

const app = initializeApp(firebaseConfig);

const firestore = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

let messaging: Messaging | null = null;

const initializeMessaging = async () => {
  const supported = await isSupported();
  if (supported) {
    messaging = getMessaging(app);
  } else {
    messaging = null;
  }
  return messaging;
};

initializeMessaging();

const requestPermission = async (): Promise<string | null> => {
  const supported = await isSupported();
  if (!supported) {
    console.warn("Las notificaciones no son compatibles con este navegador.");
    return null;
  }
  
  if (!messaging) {
    await initializeMessaging();
  }

  if (!messaging) return null;

  console.log("Solicitando permiso...");
  const permission = await Notification.requestPermission();
  if (permission === "granted") {
    console.log("Permiso de notificación concedido.");
    try {
      const currentToken = await getToken(messaging, {
        vapidKey: "BOpusjOPRmVyhMLnJgvr7dz_61bW1bR-1indiLxBAV7yp6jMDSVKynsUqMxUCOj4vjwZnKpcGFUJ0dp44FLcOLg",
      });
      if (currentToken) {
        return currentToken;
      } else {
        console.log("No hay token de registro disponible. Solicita permiso para generar uno.");
        return null;
      }
    } catch (err) {
      console.error("Ocurrió un error al recuperar el token. ", err);
      return null;
    }
  } else {
    console.log("Permiso no concedido.");
    return null;
  }
};

export { app, firestore, storage, auth, messaging, requestPermission, onMessage, initializeMessaging, doc, updateDoc };
