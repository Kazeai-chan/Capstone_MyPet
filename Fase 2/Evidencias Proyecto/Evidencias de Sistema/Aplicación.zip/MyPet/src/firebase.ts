
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";
// CORRECCIÓN: Importamos el TIPO `Messaging` para el tipado estricto.
import { getMessaging, getToken, onMessage, isSupported, Messaging } from "firebase/messaging";

const firebaseConfig = {
  
};

const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

// CORRECCIÓN: Le damos un tipo explícito a la variable `messaging`.
let messaging: Messaging | null = null;

const initializeMessaging = async () => {
  const supported = await isSupported();
  if (supported) {
    console.log("Firebase Messaging is supported.");
    messaging = getMessaging(app);
  } else {
    console.log("Firebase Messaging is not supported in this browser.");
    messaging = null; // Ya es null, pero lo dejamos por claridad
  }
  return messaging;
};

// Inicializamos al cargar el script
initializeMessaging();

const requestPermission = async () => {
  const supported = await isSupported();
  if (!supported) {
    console.warn("Notifications are not supported in this browser.");
    return;
  }
  
  if (!messaging) {
    await initializeMessaging();
  }

  if (!messaging) return;

  console.log("Requesting permission...");
  const permission = await Notification.requestPermission();
  if (permission === "granted") {
    console.log("Notification permission granted.");
    try {
      const currentToken = await getToken(messaging, {
        vapidKey: "",
      });
      if (currentToken) {
        console.log("Token del dispositivo:", currentToken);
      } else {
        console.log("No registration token available. Request permission to generate one.");
      }
    } catch (err) {
      console.error("An error occurred while retrieving token. ", err);
    }
  }
};

export { app, firestore, storage, auth, messaging, requestPermission, onMessage, initializeMessaging };
