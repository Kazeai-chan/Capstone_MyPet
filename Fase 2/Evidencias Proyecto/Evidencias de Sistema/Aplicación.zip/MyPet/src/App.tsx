
// src/App.tsx
import React, { useEffect, useState, useContext } from 'react';
import {
  IonApp,
  setupIonicReact,
  IonPage,
  IonContent,
  IonRouterOutlet,
} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';
import { Route } from 'react-router-dom';

import { UserProvider, UserContext } from './context/UserContext';
import Sesion from './pages/Sesion/Sesion';
import Footer from './components/Footer';

/* Ionic CSS & Theme */
import '@ionic/react/css/core.css';
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';
import './theme/variables.css';
import './App.css';

import { messaging } from './firebase'; // Puede ser null en navegadores no compatibles
import { onMessage } from 'firebase/messaging';

setupIonicReact();

const AppRouter: React.FC = () => {
  const { loading, user } = useContext(UserContext);
  const [dots, setDots] = useState('');

  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => (prev.length >= 3 ? '' : prev + '.'));
    }, 500);
    return () => clearInterval(interval);
  }, []);

  // CORRECCIÓN FINAL: Escuchamos mensajes solo si el navegador es compatible.
  useEffect(() => {
    // Verificamos que messaging se haya inicializado correctamente.
    if (messaging) {
      const unsubscribe = onMessage(messaging, payload => {
        console.log('Mensaje recibido en primer plano:', payload);
        // Considera usar un Toast de Ionic en lugar de un alert para una mejor UX.
        alert(payload.notification?.title || 'Nueva notificación recibida');
      });

      // Se llama a la función de limpieza cuando el componente se desmonta.
      return () => unsubscribe();
    }
  }, []);

  if (loading) {
    const email = localStorage.getItem('user_email');
    return (
      <IonPage>
        <IonContent fullscreen className="loading-screen-modern">
          <div className="loading-container">
            {/* ... (código de la pantalla de carga sin cambios) ... */}
            <div className="loading-illustration">
              <div className="illustration-wrapper">
                <img
                  src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
                  alt="MyPet"
                  className="loading-logo"
                />
                <div className="paw-prints">
                  <div className="paw paw-1">🐾</div>
                  <div className="paw paw-2">🐾</div>
                  <div className="paw paw-3">🐾</div>
                  <div className="paw paw-4">🐾</div>
                </div>
              </div>
            </div>
            <div className="loading-text-section">
              <h1 className="loading-title">MyPet</h1>
              <p className="loading-subtitle">Tu comunidad de mascotas</p>
            </div>
            <div className="loading-progress-container">
              <div className="progress-bar-wrapper">
                <div className="progress-bar-animated"></div>
              </div>
            </div>
            {email && (
              <div className="loading-info">
                <div className="loading-status">Iniciando sesión{dots}</div>
                <div className="loading-email">{email}</div>
              </div>
            )}
            <div className="loading-decoration">
              <div className="decoration-circle circle-1"></div>
              <div className="decoration-circle circle-2"></div>
              <div className="decoration-circle circle-3"></div>
            </div>
          </div>
        </IonContent>
      </IonPage>
    );
  }

  return (
    <IonApp>
      <IonReactRouter>
        <IonRouterOutlet>
          <Route path="/" render={() => user ? <Footer /> : <Sesion />} />
        </IonRouterOutlet>
      </IonReactRouter>
    </IonApp>
  );
};

const App = () => (
  <UserProvider>
    <AppRouter />
  </UserProvider>
);

export default App;
