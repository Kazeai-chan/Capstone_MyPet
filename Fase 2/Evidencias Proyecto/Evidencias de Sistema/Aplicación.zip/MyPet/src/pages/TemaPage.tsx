
import React, { useState, useEffect, useContext } from 'react';
import { IonContent, IonIcon, IonAvatar, IonTextarea, IonButton, IonToast, IonHeader, IonToolbar, IonButtons, IonBackButton, IonPage, IonChip, IonSpinner, IonFooter } from '@ionic/react';
import { useHistory, useParams } from 'react-router-dom';
import { heart, chatboxEllipsesOutline, heartOutline, pricetagOutline, sendSharp, timeOutline } from 'ionicons/icons';
import { doc, getDoc, collection, query, where, getDocs, addDoc, updateDoc, serverTimestamp, orderBy, Timestamp, deleteDoc } from 'firebase/firestore'; // <-- Importado deleteDoc
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import '../pages/TemaPage.css';

const TemaPage: React.FC = () => {
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();
  const { id: idTema } = useParams<{ id: string }>();

  const [tema, setTema] = useState<any>(null);
  const [comentarios, setComentarios] = useState<any[]>([]);
  const [coment, setComent] = useState({ c_cuerpo: '' });
  const [meGusta, setMeGusta] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!idTema) return;

    setLoading(true);
    const traeTema = async () => {
      const docRef = doc(firestore, 'temas', idTema);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setTema({ id: docSnap.id, ...docSnap.data() });
      }
    };

    const traeComentarios = async () => {
      const q = query(collection(firestore, 'comentarios'), where('idtema', '==', idTema), orderBy('c_fecha', 'asc'));
      const querySnapshot = await getDocs(q);
      const coments: any[] = [];
      querySnapshot.forEach((doc) => {
        coments.push({ id: doc.id, ...doc.data() });
      });
      setComentarios(coments);
    };

    const revisaGusta = async () => {
      if (user) {
        const q = query(
          collection(firestore, 'gustas'),
          where('iduser', '==', user.uid),
          where('idtema', '==', idTema)
        );
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          setMeGusta(true);
        }
      }
    };

    Promise.all([traeTema(), traeComentarios(), revisaGusta()]).finally(() => setLoading(false));
  }, [idTema, user]);

  const handleComentChange = (e: any) => {
    setComent({ ...coment, [e.target.name]: e.target.value });
  };

  const Comentar = async () => {
    if (coment.c_cuerpo.trim() === '' || !user || !tema) return;

    const timestamp = Timestamp.now();
    const newComent = {
      c_avatar: user.fotouser,
      c_cuerpo: coment.c_cuerpo,
      c_fecha: timestamp,
      c_iduser: user.uid,
      c_nombre: user.name,
      idtema: idTema,
    };
    
    setComentarios(prevComentarios => [...prevComentarios, { ...newComent, id: Date.now().toString() }]);
    setComent({ c_cuerpo: '' });

    await addDoc(collection(firestore, 'comentarios'), newComent);

    if (user.uid !== tema.iduser) {
      await addDoc(collection(firestore, 'notificaciones'), {
        userId: tema.iduser,
        title: `${user.name} comentó en tu publicación`,
        body: coment.c_cuerpo,
        createdAt: serverTimestamp(),
        read: false,
        icon: '💭',
        link: `/app/tema/${idTema}`
      });
    }

    const temaRef = doc(firestore, 'temas', idTema);
    const updatedComCount = comentarios.length + 1;
    await updateDoc(temaRef, {
      c_avatar: user.fotouser,
      c_nombre: user.name,
      comentario: coment.c_cuerpo,
      n_com: updatedComCount,
    });
    
    setTema((prevTema: any) => ({ ...prevTema, n_com: updatedComCount }));
  };

  const toggleGusta = async () => {
    if (!user || !tema) return;

    const newMeGustaState = !meGusta;
    setMeGusta(newMeGustaState);

    const newLikes = newMeGustaState ? tema.n_gusta + 1 : tema.n_gusta - 1;
    setTema((prevTema: any) => ({ ...prevTema, n_gusta: newLikes }));

    if (newMeGustaState) {
      setShowToast(true);
      try {
        await addDoc(collection(firestore, 'gustas'), { iduser: user.uid, idtema: idTema });
        await updateDoc(doc(firestore, 'temas', idTema), { n_gusta: newLikes });
        if (user.uid !== tema.iduser) {
          await addDoc(collection(firestore, 'notificaciones'), {
            userId: tema.iduser,
            title: 'A alguien le gusta tu tema',
            body: `${user.name} le ha dado me gusta a tu publicación.`,
            createdAt: serverTimestamp(),
            read: false,
            icon: '❤️',
            link: `/app/tema/${idTema}`
          });
        }
      } catch (error) {
        console.error("Error al dar me gusta:", error);
        setMeGusta(false);
        setTema((prevTema: any) => ({ ...prevTema, n_gusta: prevTema.n_gusta - 1 }));
      }
    } else {
      try {
        const q = query(collection(firestore, 'gustas'), where('iduser', '==', user.uid), where('idtema', '==', idTema));
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          await deleteDoc(querySnapshot.docs[0].ref);
        }
        await updateDoc(doc(firestore, 'temas', idTema), { n_gusta: newLikes });
      } catch (error) {
        console.error("Error al quitar me gusta:", error);
        setMeGusta(true);
        setTema((prevTema: any) => ({ ...prevTema, n_gusta: prevTema.n_gusta + 1 }));
      }
    }
  };

  const formatDate = (seconds: number) => {
    return new Date(seconds * 1000).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const formatTimeAgo = (date: any) => {
    let d = date;
    if (date && date.toDate) { d = date.toDate(); }
    if (!(d instanceof Date) || isNaN(d.getTime())) { return 'hace un momento'; }
    const now = new Date();
    const diffSeconds = Math.floor((now.getTime() - d.getTime()) / 1000);
    if (diffSeconds < 60) return 'Ahora';
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes < 60) return `Hace ${diffMinutes}m`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `Hace ${diffHours}h`;
    const diffDays = Math.floor(diffHours / 24);
    return `Hace ${diffDays}d`;
  };
  
  const goToProfile = (userId: string) => {
    // Check to prevent navigation for the expert user
    if (userId && userId !== 'mypet-expert') {
      history.push(`/app/perfil/${userId}`);
    }
  };

  if (loading || !tema) {
    return (
      <IonPage>
        <IonHeader className="tema-header-modern">
          <IonToolbar className="tema-toolbar-modern">
            <IonButtons slot="start">
              <IonBackButton defaultHref="/app/foro" text="Foro" className="back-btn-modern" />
            </IonButtons>
          </IonToolbar>
        </IonHeader>
        <IonContent fullscreen className="tema-content-loading">
          <div className="loading-container-tema">
            <IonSpinner name="circular" className="spinner-modern" />
            <p className="loading-text">Cargando tema...</p>
          </div>
        </IonContent>
      </IonPage>
    );
  }

  return (
    <IonPage>
      <IonHeader className="tema-header-modern">
        <IonToolbar className="tema-toolbar-modern">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/app/foro" text="Foro" className="back-btn-modern" />
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent fullscreen className={'tema-content-redesign ' + (!tema.foto ? 'has-no-image' : '')}>
        {tema.foto && (
          <div className="tema-hero-redesign">
            <img src={tema.foto} alt={tema.titulo} className="hero-img" />
            <div className="hero-gradient"></div>
          </div>
        )}

        <div className="tema-container-modern">
          <div className="tema-card-main">

            {tema.categoria && (
                <IonChip className="badge-categoria-tema">
                  <IonIcon icon={pricetagOutline} />
                  <span>{tema.categoria}</span>
                </IonChip>
            )}

            <h1 className="tema-title-redesign">{tema.titulo}</h1>
            
            <div className="tema-author-section" onClick={() => goToProfile(tema.iduser)}>
              <IonAvatar className="author-avatar-redesign">
                <img alt={tema.nombreuser} src={tema.avatar} />
              </IonAvatar>
              <div className="author-info-redesign">
                <div className="author-name-redesign">{tema.nombreuser}</div>
                <div className="author-date-redesign">
                  <IonIcon icon={timeOutline} />
                  <span>{formatDate(tema.fecha.seconds)}</span>
                </div>
              </div>
            </div>

            <div className="tema-body-redesign">
              <p>{tema.cuerpo}</p>
            </div>

            <div className="tema-interactions">
              <IonChip 
                className={`interaction-chip ${meGusta ? 'liked' : ''}`}
                onClick={toggleGusta} // <-- Llama a la nueva función toggle
              >
                <IonIcon icon={meGusta ? heart : heartOutline} />
                <span>{tema.n_gusta}</span>
                <span className="interaction-label">Me gusta</span>
              </IonChip>
              
              <IonChip className="interaction-chip">
                <IonIcon icon={chatboxEllipsesOutline} />
                <span>{comentarios.length}</span>
                <span className="interaction-label">Respuestas</span>
              </IonChip>
            </div>
          </div>

          <div className="divider-with-paw">
            <div className="divider-line"></div>
            <div className="divider-paw">🐾</div>
            <div className="divider-line"></div>
          </div>

          <div className="respuestas-header">
            <IonIcon icon={chatboxEllipsesOutline} className="respuestas-icon" />
            <h2 className="respuestas-title">Respuestas</h2>
            <IonChip className="respuestas-count">{comentarios.length}</IonChip>
          </div>

          <div className="comentarios-container">
            {comentarios.length === 0 ? (
              <div className="empty-comments">
                <div className="empty-icon-paw">🐾</div>
                <p>Sé el primero en responder</p>
              </div>
            ) : (
              comentarios.map((comentario, index) => (
                <div key={comentario.id} className="comentario-redesign" style={{ animationDelay: `${index * 0.1}s` }}>
                  <IonAvatar className="comment-avatar" onClick={() => goToProfile(comentario.c_iduser)}>
                    <img alt={comentario.c_nombre} src={comentario.c_avatar} />
                  </IonAvatar>
                  <div className="comment-content">
                    <div className="comment-header">
                      <span className="comment-author">{comentario.c_nombre}</span>
                      <span className="comment-time">{formatTimeAgo(comentario.c_fecha)}</span>
                    </div>
                    <p className="comment-text">{comentario.c_cuerpo}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <IonToast
          isOpen={showToast}
          onDidDismiss={() => setShowToast(false)}
          message="¡Te gusta este tema!"
          duration={2000}
          position="top"
          color="success"
          className="toast-redesign"
        />

        <div className="bg-paw bg-paw-1">🐾</div>
        <div className="bg-paw bg-paw-2">🐾</div>
        <div className="bg-paw bg-paw-3">🐾</div>
      </IonContent>

      <IonFooter>
        <IonToolbar className="comment-input-toolbar">
          <div className="comment-input-content">
            <IonAvatar className="input-user-avatar">
              <img alt="Tu perfil" src={user?.fotouser} />
            </IonAvatar>
            <div className="input-field-wrapper">
              <IonTextarea
                value={coment.c_cuerpo}
                onIonInput={handleComentChange}
                placeholder="Escribe tu respuesta..."
                className="comment-textarea"
                autoGrow
                rows={1}
                name="c_cuerpo"
              />
              <IonButton onClick={Comentar} disabled={!coment.c_cuerpo.trim()} className="send-comment-btn" fill="clear">
                <IonIcon icon={sendSharp} />
              </IonButton>
            </div>
          </div>
        </IonToolbar>
      </IonFooter>
    </IonPage>
  );
};

export default TemaPage;
