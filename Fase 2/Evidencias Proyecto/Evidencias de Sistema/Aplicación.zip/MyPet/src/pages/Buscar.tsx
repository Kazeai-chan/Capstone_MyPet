
import React, { useState, useEffect, useContext, useCallback, useRef } from 'react';
import {
  IonContent, IonHeader, IonPage, IonToolbar, IonIcon,
  IonButton, useIonToast, useIonAlert, IonButtons, IonSearchbar, IonList, IonItem, 
  IonLabel, IonAvatar, IonCard, 
  IonBadge,
  IonChip,
  IonModal
} from '@ionic/react';
import { storefrontOutline, paw, navigate, close, homeOutline, listOutline, chatbubbles, documentText, person, trophy, bandageOutline } from 'ionicons/icons';
import { APIProvider, Map, AdvancedMarker, MapMouseEvent, Pin, MapCameraChangedEvent } from '@vis.gl/react-google-maps';
import { collection, getDocs } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import VerMarcador from '../components/VerMarcador';
import ModMarcador from '../components/ModMarcador';
import CreaTienda from '../components/CreaTienda';
import ReporteMascota from '../components/ReporteMascota';
import PerfilModal from '../components/PerfilModal';
import './Buscar.css';
import { useHistory } from 'react-router-dom';
import DatosModal from 'components/DatosModal';

const API_KEY = "";

// Interfaces
interface BaseMarker { id: string; lat: number; lng: number; nombre: string; iduser: string; tipo: string; foto: string; descripcion: string; }
export interface StoreMarker extends BaseMarker { tipo: 'Veterinaria' | 'Tienda'; direccion: string; descripcion: string; }
export interface PetReportMarker extends BaseMarker { tipo: 'mascota'; tipo_r: 'Mascota Perdida' | 'Mascota Encontrada'; animal: string; tamano: string; color: string; fecha: string; }
type Marker = StoreMarker | PetReportMarker;
interface AutocompletePrediction {
  description: string;
  place_id: string;
}

function xhrFetch(url: string): Promise<any> {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    resolve(JSON.parse(xhr.responseText));
                } catch (e) {
                    reject(new Error('Failed to parse JSON response.'));
                }
            } else {
                reject(new Error(`Request failed with status: ${xhr.status} - ${xhr.statusText}`));
            }
        };
        xhr.onerror = () => reject(new Error('Network request failed.'));
        xhr.send();
    });
}

const Buscar: React.FC = () => {
  const { user } = useContext<UserContextType>(UserContext);
  const [center, setCenter] = useState({ lat: -33.45694, lng: -70.64827 });
  const [markers, setMarkers] = useState<Marker[]>([]);
  const [filteredMarkers, setFilteredMarkers] = useState<Marker[]>([]);
  const [visibleMarkers, setVisibleMarkers] = useState<Marker[]>([]);
  const [bounds, setBounds] = useState<any>(undefined);

  const [selectedMarker, setSelectedMarker] = useState<Marker | null>(null);
  const [activeMarker, setActiveMarker] = useState<Marker | null>(null);
  const [presentToast] = useIonToast();
  const [presentAlert] = useIonAlert();
  
  const searchbarRef = useRef<HTMLIonSearchbarElement>(null);
  const allowFocusOpen = useRef(true); // Guardian Flag

  // Modal States
  const [isVerMarcadorOpen, setIsVerMarcadorOpen] = useState(false);
  const [isModMarcadorOpen, setIsModMarcadorOpen] = useState(false);
  const [isCreaTiendaOpen, setIsCreaTiendaOpen] = useState(false);
  const [isReporteMascotaOpen, setIsReporteMascotaOpen] = useState(false);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);

  // Search and Autocomplete States
  const [searchQuery, setSearchQuery] = useState('');
  const [predictions, setPredictions] = useState<AutocompletePrediction[]>([]);

  // Marker Placement States
  const [newStoreLocation, setNewStoreLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [newReportLocation, setNewReportLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [editingReportId, setEditingReportId] = useState<string | undefined>(undefined);
  const [isPlacingMarker, setIsPlacingMarker] = useState(false);
  const [isPlacingPetReport, setIsPlacingPetReport] = useState(false);

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [viewMode, setViewMode] = useState('map'); // 'map' o 'list'
  const [selectedFilter, setSelectedFilter] = useState('todos');
  const [isDatosModalOpen, setDatosModalOpen] = useState(false);
  const history = useHistory();

  const filters = [
    { id: 'todos', label: 'Todos', icon: listOutline },
    { id: 'Mascota Perdida', label: 'Perdidos', icon: paw },
    { id: 'Mascota Encontrada', label: 'Encontrados', icon: paw },
    { id: 'Tienda', label: 'Tiendas', icon: storefrontOutline },
    { id: 'Veterinaria', label: 'Veterinarias', icon: storefrontOutline }
  ];

  const fetchMarkers = useCallback(async () => {
    const markersCollection = await getDocs(collection(firestore, 'marcadores'));
    const markersData = markersCollection.docs.map(doc => ({ id: doc.id, ...doc.data() } as Marker));
    setMarkers(markersData);
  }, []);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      setCenter({ lat: position.coords.latitude, lng: position.coords.longitude });
    });
    fetchMarkers();
  }, [fetchMarkers]);

  // Effect to filter markers by type (selectedFilter)
  useEffect(() => {
    if (selectedFilter === 'todos') {
      setFilteredMarkers(markers);
    } else {
      const filtered = markers.filter(marker => {
        if (marker.tipo === 'mascota') {
          return (marker as PetReportMarker).tipo_r === selectedFilter;
        }
        return marker.tipo === selectedFilter;
      });
      setFilteredMarkers(filtered);
    }
  }, [selectedFilter, markers]);

  // Effect to filter markers by map bounds
  useEffect(() => {
    if (!bounds || !filteredMarkers.length) {
      setVisibleMarkers([]);
      if (viewMode === 'list') {
          setVisibleMarkers(filteredMarkers);
      }
      return;
    }
    
    const b = bounds.toJSON ? bounds.toJSON() : bounds;

    const visible = filteredMarkers.filter(marker =>
        marker.lat >= b.south &&
        marker.lat <= b.north &&
        marker.lng >= b.west &&
        marker.lng <= b.east
    );
    setVisibleMarkers(visible);
  }, [filteredMarkers, bounds, viewMode]);

  const geolocate = () => {
    navigator.geolocation.getCurrentPosition((position) => {
      setCenter({ lat: position.coords.latitude, lng: position.coords.longitude });
    });
  };

  const handleCameraChange = useCallback((ev: MapCameraChangedEvent) => {
    setCenter(ev.detail.center);
    setBounds(ev.detail.bounds);
  }, []);

  const handleSearchInputChange = async (e: any) => {
    const input = e.detail.value!;
    setSearchQuery(input);
    if (input.length > 2) {
      const url = `/api/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&key=${API_KEY}&types=address`;
      try {
        const data = await xhrFetch(url);
        setPredictions(data.predictions || []);
      } catch (error) {
        console.error("[XHR-PROXY] Autocomplete request failed:", error);
      }
    } else {
      setPredictions([]);
    }
  };

  const handleSuggestionClick = async (place_id: string, description: string) => {
    setSearchQuery(description);
    setPredictions([]);
    const url = `https://maps.googleapis.com/maps/api/geocode/json?place_id=${place_id}&key=${API_KEY}`;
    try {
      const data = await xhrFetch(url);
      if (data.results && data.results.length > 0) {
        const location = data.results[0].geometry.location;
        setCenter({ lat: location.lat, lng: location.lng });
        closeSearchModal();
      } else {
        presentAlert({ header: 'Error', message: 'No se pudo obtener la ubicación de la dirección.', buttons: ['OK'] });
      }
    } catch (error) {
        console.error("[XHR-DIRECT] Geocode from Place ID failed:", error);
        presentAlert({ header: 'Error', message: 'Ocurrió un error al buscar la dirección.', buttons: ['OK'] });
    }
  };

  const handleSearchSubmit = async () => {
    if (!searchQuery) {
      presentToast({ message: 'Por favor ingrese una dirección para buscar.', duration: 2000, color: 'warning' });
      return;
    }
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(searchQuery)}&key=${API_KEY}`;
    try {
      const data = await xhrFetch(url);
      if (data.results && data.results.length > 0) {
        const location = data.results[0].geometry.location;
        setCenter({ lat: location.lat, lng: location.lng });
        closeSearchModal();
      } else {
        presentAlert({ header: 'Sin resultados', message: 'No se pudo encontrar la ubicación para la dirección ingresada.', buttons: ['OK'] });
      }
    } catch (error) {
        console.error("[XHR-DIRECT] Geocode from address failed:", error);
        presentAlert({ header: 'Error', message: 'Ocurrió un error al buscar la dirección.', buttons: ['OK'] });
    }
  };
  
  const closeSearchModal = () => {
    allowFocusOpen.current = false;
    setIsSearchModalOpen(false);
    setPredictions([]);
    setSearchQuery('');
    
    if (searchbarRef.current) {
      searchbarRef.current.getInputElement().then(input => {
        input.blur();
      });
    }

    setTimeout(() => {
      allowFocusOpen.current = true;
    }, 300);
  }

  const handleMarkerClick = (marker: Marker) => { setSelectedMarker(marker); setActiveMarker(marker); };
  const handleMapClick = (event: MapMouseEvent) => {
    if (!event.detail.latLng) return;
    const { lat, lng } = event.detail.latLng;
    if (isPlacingMarker) { setNewStoreLocation({ lat, lng }); setIsCreaTiendaOpen(true); }
    if (isPlacingPetReport) { setNewReportLocation({ lat, lng }); setIsReporteMascotaOpen(true); }
  };

  const closeVerMarcador = () => { setIsVerMarcadorOpen(false); setActiveMarker(null); fetchMarkers(); };
  const closeModMarcador = () => { setIsModMarcadorOpen(false); setActiveMarker(null); fetchMarkers(); };
  const closeCreaTienda = () => { setIsCreaTiendaOpen(false); setIsPlacingMarker(false); setNewStoreLocation(null); fetchMarkers(); };
  const closeReporteMascota = () => { setIsReporteMascotaOpen(false); setIsPlacingPetReport(false); setNewReportLocation(null); setEditingReportId(undefined); fetchMarkers(); };

  const startPlacingMarker = () => { setIsPlacingMarker(true); presentToast({ message: 'Haga clic en el mapa para colocar el marcador de la tienda', duration: 3000 }); };
  const startPlacingPetReport = () => { setIsPlacingPetReport(true); presentToast({ message: 'Haga clic en el mapa para reportar una mascota', duration: 3000 }); }
  const openEditReportModal = () => { if (activeMarker) { setEditingReportId(activeMarker.id); setIsReporteMascotaOpen(true); setSelectedMarker(null); } }

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="buscar-toolbar">
          <div className="buscar-header">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9" 
              alt="MyPet" 
              className="logo-buscar"
            />
            <IonButtons className="header-buttons">
              <IonButton fill="clear" onClick={() => setViewMode(viewMode === 'map' ? 'list' : 'map')}>
                <IonIcon icon={viewMode === 'map' ? listOutline : homeOutline} />
              </IonButton>
              <IonAvatar className="avatar-header" onClick={() => setShowProfileModal(true)}>
                <img src={user?.fotouser} alt="Perfil" />
              </IonAvatar>
            </IonButtons>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent className="buscar-content">
        <div className="map-container">
          <APIProvider apiKey={API_KEY}>
            <Map mapId={'DEMO_MAP_ID'} style={{ width: '100%', height: '100%' }} center={center} onCameraChanged={handleCameraChange} defaultZoom={15} onClick={handleMapClick} gestureHandling={'greedy'}>
              {filteredMarkers.map((marker) => (
                <AdvancedMarker className="marker-pin" key={marker.id} position={{ lat: marker.lat, lng: marker.lng }} onClick={() => handleMarkerClick(marker)}>
                  <Pin scale={2} background={getMarkerColor(marker.tipo === 'mascota' ? (marker as PetReportMarker).tipo_r : marker.tipo)} borderColor="#ffffff" glyphColor="#ffffff">
                    <IonIcon size="large" icon={getMarkerIcon(marker.tipo)} />
                  </Pin>
                </AdvancedMarker>
              ))}
            </Map>
          </APIProvider>

          {/* InfoWindow Mejorado */}
          {selectedMarker && activeMarker && (
            <div className="infowindow-overlay" onClick={() => setSelectedMarker(null)}>
              <div className="infowindow-card" onClick={(e) => e.stopPropagation()}>
                <IonButton 
                  fill="clear" 
                  className="infowindow-close" 
                  onClick={() => setSelectedMarker(null)}
                >
                  <IonIcon icon={close} />
                </IonButton>

                <div className="infowindow-image-container">
                  <img src={selectedMarker.foto} alt={selectedMarker.nombre} className="infowindow-image" />
                  <IonBadge className={`infowindow-badge ${selectedMarker.tipo}`}>
                    {selectedMarker.tipo === 'mascota' ? selectedMarker.tipo_r : selectedMarker.tipo}
                  </IonBadge>
                </div>

                <div className="infowindow-content">
                  <h3>{selectedMarker.nombre}</h3>
                  <p className="infowindow-description">{selectedMarker.descripcion}</p>
                  
                  <div className="infowindow-actions">
                    <IonButton 
                      expand="block" 
                      className="infowindow-btn primary"
                      onClick={() => setIsVerMarcadorOpen(true)}
                    >
                      Ver Detalles
                    </IonButton>
                    
                    {user?.uid === activeMarker.iduser && (
                      <IonButton 
                        expand="block" 
                        fill="outline"
                        className="infowindow-btn secondary"
                        onClick={activeMarker.tipo !== 'mascota' ? () => setIsModMarcadorOpen(true) : openEditReportModal}
                      >
                        Modificar
                      </IonButton>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="search-bar-floating">
            <IonSearchbar
              ref={searchbarRef}
              placeholder="Buscar dirección o mascota..."
              value={searchQuery}
              onIonFocus={() => {
                if (allowFocusOpen.current) {
                  setIsSearchModalOpen(true);
                }
              }}
              className="custom-searchbar"
            />
          </div>

          <div className="filters-container">
            {filters.map((filter) => (
              <IonChip
                key={filter.id}
                className={`filter-chip ${selectedFilter === filter.id ? 'active' : ''}`}
                onClick={() => setSelectedFilter(filter.id)}
              >
                <IonIcon icon={filter.icon} />
                <IonLabel>{filter.label}</IonLabel>
              </IonChip>
            ))}
          </div>

          {viewMode === 'list' && (
            <div className="markers-list-overlay">
              <div className="list-header">
                <h3>Marcadores Cercanos</h3>
                <IonBadge color="primary">{visibleMarkers.length}</IonBadge>
              </div>
              <div className="markers-scroll">
                {visibleMarkers.map((marker) => (
                  <IonCard key={marker.id} className="marker-card-compact">
                    <div className="marker-card-content">
                      <img src={marker.foto} alt={marker.nombre} className="marker-thumb" />
                      <div className="marker-info">
                        <h4>{marker.nombre}</h4>
                        <p>{marker.descripcion}</p>
                        <IonBadge className={`type-badge ${marker.tipo}`}>
                          {marker.tipo === 'mascota' ? (marker as PetReportMarker).tipo_r : marker.tipo}
                        </IonBadge>
                      </div>
                    </div>
                  </IonCard>
                ))}
              </div>
            </div>
          )}

          <div className="quick-actions-bottom">
            <IonButton 
              className="quick-action-btn"
              onClick={geolocate}
            >
              <IonIcon icon={navigate} slot="start" />
              Ubicación actual
            </IonButton>
            
            <IonButton 
              className="quick-action-btn secondary"
              onClick={startPlacingPetReport}
            >
              <IonIcon icon={paw} slot="start" />
              Reportar
            </IonButton>
            
            <IonButton 
              className="quick-action-btn secondary"
              onClick={startPlacingMarker}
            >
              <IonIcon icon={storefrontOutline} slot="start" />
              Tienda
            </IonButton>
          </div>
        </div>
        
        {/* -- Modals -- */}
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user} googleMapsApiKey={API_KEY}/>}
        <VerMarcador isOpen={isVerMarcadorOpen} onClose={closeVerMarcador} marker={activeMarker} />
        {activeMarker && activeMarker.tipo !== 'mascota' && <ModMarcador isOpen={isModMarcadorOpen} onClose={closeModMarcador} markerId={activeMarker.id} />}
        <CreaTienda isOpen={isCreaTiendaOpen} onClose={closeCreaTienda} location={newStoreLocation} googleMapsApiKey={API_KEY} />
        <ReporteMascota isOpen={isReporteMascotaOpen} onClose={closeReporteMascota} location={newReportLocation} reportId={editingReportId} googleMapsApiKey={API_KEY} />
        <DatosModal isOpen={isDatosModalOpen} onClose={() => setDatosModalOpen(false)} />

      </IonContent>

      <IonModal 
        isOpen={isSearchModalOpen} 
        onDidDismiss={closeSearchModal}
        className="search-modal"
      >
        <div className="search-modal-content">
          <div className="search-modal-header">
            <div className="modal-handle"></div>
            <h2>Buscar Ubicación</h2>
            <IonButton fill="clear" onClick={closeSearchModal} className="close-btn-small">
              <IonIcon icon={close} />
            </IonButton>
          </div>

          <div className="search-input-container">
            <IonSearchbar
              placeholder="Ingresa una dirección"
              value={searchQuery}
              className="modal-searchbar"
              autoFocus
              onIonInput={handleSearchInputChange}
            />
          </div>

          <div className="suggestions-container">
            {predictions.length > 0 ? (
              <IonList className="suggestions-list">
                {predictions.map((p) => (
                  <IonItem 
                    key={p.place_id} 
                    button 
                    detail={false}
                    className="suggestion-item"
                    onClick={() => handleSuggestionClick(p.place_id, p.description)}
                  >
                    <IonIcon icon={navigate} slot="start" color="primary" />
                    <IonLabel className="suggestion-label">{p.description}</IonLabel>
                  </IonItem>
                ))}
              </IonList>
            ) : (
              <div className="empty-state">
                <IonIcon icon={navigate} className="empty-icon" />
                <p>Escribe una dirección para buscar</p>
              </div>
            )}
          </div>

          <div className="modal-footer">
            <IonButton 
              expand="block" 
              className="search-submit-btn"
              disabled={!searchQuery}
              onClick={handleSearchSubmit}
            >
              <IonIcon icon={navigate} slot="start" />
              Ir a esta ubicación
            </IonButton>
          </div>
        </div>
      </IonModal>
      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mi Perfil</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/conversations'); }}>
                <IonIcon icon={chatbubbles} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => setDatosModalOpen(true)}>
                <IonIcon icon={documentText} />
                <span>Datos</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/puntos')}}>
                <IonIcon icon={trophy} />
                <span>Mis Puntos</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline">
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

const getMarkerIcon = (type: string): string => {
  switch (type) {
    case 'Veterinaria': return bandageOutline;
    case 'Tienda': return storefrontOutline;
    case 'mascota': return paw;
    default: return paw;
  }
};

const getMarkerColor = (type: string): string => {
  switch (type) {
    case 'Mascota Encontrada': return "#27ae60";
    case 'Tienda': return "#445a14";
    case 'Mascota Perdida': return "#e74c3c";
    default: return "#445a14";
  }
};

export default Buscar;
