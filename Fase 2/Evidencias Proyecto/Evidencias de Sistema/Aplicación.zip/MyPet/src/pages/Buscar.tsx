
import React, { useState, useEffect, useContext, useCallback, useRef } from 'react';
import {
  IonContent, IonHeader, IonPage, IonToolbar, IonIcon,
  IonButton, useIonToast, useIonAlert, IonButtons, IonSearchbar, IonList, IonItem, 
  IonLabel, IonAvatar, IonCard, 
  IonBadge,
  IonChip,
  IonModal,
  IonSpinner
} from '@ionic/react';
import { storefrontOutline, paw, navigate, close, homeOutline, listOutline, chatbubbles, documentText, person, businessOutline, star, cutOutline, pawOutline } from 'ionicons/icons';
import { APIProvider, Map, AdvancedMarker, MapMouseEvent, MapCameraChangedEvent } from '@vis.gl/react-google-maps';
import { collection, getDocs } from 'firebase/firestore';
import { firestore, GOOGLE_MAPS_API_KEY } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import VerMarcador from '../components/VerMarcador';
import ModMarcador from '../components/ModMarcador';
import CreaTienda from '../components/CreaTienda';
import ReporteMascota from '../components/ReporteMascota';
import PerfilModal from '../components/PerfilModal';
import './Buscar.css';
import { useHistory } from 'react-router-dom';
import CustomMapPin from '../components/CustomMapPin';
import { useLocation } from 'react-router-dom';


const API_KEY = GOOGLE_MAPS_API_KEY;

// Interfaces
interface BaseMarker { id: string; lat: number; lng: number; nombre: string; iduser: string; tipo: string; foto: string; descripcion: string; isGooglePlace: boolean; }
export interface StoreMarker extends BaseMarker { tipo: 'Veterinaria' | 'Tienda' | 'Peluquería'; direccion: string; descripcion: string; }
export interface PetReportMarker extends BaseMarker { tipo: 'mascota'; tipo_r: 'Mascota Perdida' | 'Mascota Encontrada'; animal: string; tamano: string; color: string; fecha: string; }
type Marker = StoreMarker | PetReportMarker;
interface AutocompletePrediction {
  description: string;
  place_id: string;
}

// --- NUEVA INTERFAZ PARA GOOGLE PLACES -- -
interface GooglePetPlace {
  id: string;
  name: string;
  address: string;
  location: { lat: number; lng: number; };
  rating: number;
  userRatingsTotal: number;
  types: string[];
  isOpen: boolean | null;
  photoUrl?: string;
  nombre: string;
  descripcion: string;
  lat: number;
  lng: number;
  tipo: 'Veterinaria' | 'Peluquería' | 'Tienda'; 
  foto: string;
  isGooglePlace: boolean;
  iduser?: undefined; 
}



function xhrFetch(url: string): Promise<any> {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    resolve(JSON.parse(xhr.responseText));
                } catch (e) {
                    reject(new Error('Failed to parse JSON response.'));
                }
            } else {
                reject(new Error(`Request failed with status: ${xhr.status} - ${xhr.statusText}`));
            }
        };
        xhr.onerror = () => reject(new Error('Network request failed.'));
        xhr.send();
    });
}

// --- NUEVA FUNCIÓN DE CATEGORIZACIÓN ---
const categorizePlace = (name: string, types: string[]): 'Veterinaria' | 'Peluquería' | 'Tienda' => {
  const lowerCaseName = name.toLowerCase();
  if (types.includes('veterinary_care') || lowerCaseName.includes('veterinari') || lowerCaseName.includes('clínica veterinaria')) {
      return 'Veterinaria';
  }
  if (types.includes('pet_store') || lowerCaseName.includes('tienda de mascotas') || lowerCaseName.includes('pet shop')) {
      return 'Tienda';
  }
  if (types.includes('pet_grooming_service') || lowerCaseName.includes('peluquería') || lowerCaseName.includes('grooming') || lowerCaseName.includes('wash')) {
    return 'Peluquería';
  }
  return 'Tienda'; // Default
};


const Buscar: React.FC = () => {
  const { user } = useContext<UserContextType>(UserContext);
  const [mapCenter, setMapCenter] = useState({ lat: -33.45694, lng: -70.64827 });
  const [markers, setMarkers] = useState<Marker[]>([]);
  const [petPlaces, setPetPlaces] = useState<GooglePetPlace[]>([]);
  
  // --- ESTADOS DE DATOS FILTRADOS Y VISIBLES UNIFICADOS ---
  const [visibleMarkers, setVisibleMarkers] = useState<(Marker | GooglePetPlace)[]>([]);
  
  const [bounds, setBounds] = useState<any>(undefined);
  const [loadingPetPlaces, setLoadingPetPlaces] = useState(true);
  const fetchPlacesTimeout = useRef<NodeJS.Timeout | null>(null);

  const [selectedMarker, setSelectedMarker] = useState<Marker | GooglePetPlace | null>(null);
  const [activeMarker, setActiveMarker] = useState<Marker | GooglePetPlace | null>(null);
  
  const [presentToast] = useIonToast();
  const [presentAlert] = useIonAlert();
  
  const searchbarRef = useRef<HTMLIonSearchbarElement>(null);
  const allowFocusOpen = useRef(true);

  // Modal States
  //const [isVerMarcadorOpen, setIsVerMarcadorOpen] = useState(false);
  const [isModMarcadorOpen, setIsModMarcadorOpen] = useState(false);
  const [isCreaTiendaOpen, setIsCreaTiendaOpen] = useState(false);
  const [isReporteMascotaOpen, setIsReporteMascotaOpen] = useState(false);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);

  // Search and Autocomplete States
  const [searchQuery, setSearchQuery] = useState('');
  const [predictions, setPredictions] = useState<AutocompletePrediction[]>([]);

  // Marker Placement States
  const [newStoreLocation, setNewStoreLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [newReportLocation, setNewReportLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [editingReportId, setEditingReportId] = useState<string | undefined>(undefined);
  const [isPlacingMarker, setIsPlacingMarker] = useState(false);
  const [isPlacingPetReport, setIsPlacingPetReport] = useState(false);

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [viewMode, setViewMode] = useState('map');
  const [selectedFilter, setSelectedFilter] = useState('todos');
  const history = useHistory();
  // Estados para el nuevo VerMarcador
  const [isVerMarcadorOpen, setIsVerMarcadorOpen] = useState(false);
  const [markerForModal, setMarkerForModal] = useState<Marker | GooglePetPlace | null>(null);


  // --- FILTROS ACTUALIZADOS ---
  const filters = [
    { id: 'todos', label: 'Todos', icon: listOutline },
    { id: 'Mascota Perdida', label: 'Perdidos', icon: paw },
    { id: 'Mascota Encontrada', label: 'Encontrados', icon: paw },
    { id: 'Tienda', label: 'Tiendas', icon: storefrontOutline },
    { id: 'Veterinaria', label: 'Veterinarias', icon: businessOutline },
    { id: 'Peluquería', label: 'Peluquerías', icon: cutOutline }
  ];

  const fetchMarkers = useCallback(async () => {
    const markersCollection = await getDocs(collection(firestore, 'marcadores'));
    const markersData = markersCollection.docs.map(doc => ({ id: doc.id, ...doc.data(), isGooglePlace: false } as Marker));
    setMarkers(markersData);
  }, []);

  // --- FETCHPETPLACES ACTUALIZADO ---
  const fetchPetPlaces = useCallback(async (lat: number, lng: number) => {
    if (!API_KEY) return;
    setLoadingPetPlaces(true);
    try {
      const url = `https://us-central1-instant-vent-423002-f1.cloudfunctions.net/findPetPlaces?lat=${lat}&lng=${lng}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('La respuesta de la red no fue correcta');
      
      const data = await response.json();
      const placesData: GooglePetPlace[] = (data.places || []).map((p: any) => ({
        ...p,
        nombre: p.name,
        descripcion: p.address,
        lat: p.location.lat,
        lng: p.location.lng,
        // --- Usando la nueva función ---
        tipo: categorizePlace(p.name, p.types),
        foto: p.photoUrl || 'https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png',
        isGooglePlace: true
      }));

      setPetPlaces(placesData);
    } catch (error) {
      console.error("Error al obtener lugares de mascotas:", error);
    } finally {
      setLoadingPetPlaces(false);
    }
  }, []);

  // --- LÓGICA DE GEOLOCALIZACIÓN CORREGIDA Y SIMPLIFICADA ---
  useEffect(() => {
    fetchMarkers();

    const handlePosition = (position: GeolocationPosition) => {
      console.log('ÉXITO: Ubicación obtenida en la carga inicial.');
      const newCenter = { lat: position.coords.latitude, lng: position.coords.longitude };
      setMapCenter(newCenter);
      fetchPetPlaces(newCenter.lat, newCenter.lng);
    };

    const loadDefaultLocation = (error?: GeolocationPositionError) => {
      if (error) {
        console.log(`FALLO: ${error.message}. Cargando ubicación por defecto.`);
      } else {
        console.log("SIN PERMISO o NAVEGADOR NO COMPATIBLE. Cargando ubicación por defecto.");
      }
      fetchPetPlaces(mapCenter.lat, mapCenter.lng);
    };

    // Opciones de geolocalización más flexibles para móviles.
    const geoOptions = {
      timeout: 10000, // 10 segundos de tiempo de espera.
      maximumAge: 0,
    };

    if (!navigator.geolocation) {
      loadDefaultLocation();
      return;
    }

    // Lógica de permisos simplificada y correcta:
    navigator.permissions.query({ name: 'geolocation' }).then(permissionStatus => {
      if (permissionStatus.state === 'granted') {
        // Si ya hay permiso, lo usa.
        navigator.geolocation.getCurrentPosition(handlePosition, loadDefaultLocation, geoOptions);
      } 
      else if (permissionStatus.state === 'prompt') {
        // Si debe preguntar, AHORA SÍ lo hará.
        navigator.geolocation.getCurrentPosition(handlePosition, loadDefaultLocation, geoOptions);
      } 
      else { // El estado es 'denied'
        // Si está denegado, carga la ubicación por defecto sin molestar.
        loadDefaultLocation();
      }
    });

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchMarkers]);

  // --- LÓGICA DE FILTRADO Y VISIBILIDAD UNIFICADA ---
  useEffect(() => {
    const allMarkers = [...markers, ...petPlaces];
    
    const filteredMarkers = selectedFilter === 'todos'
      ? allMarkers
      : allMarkers.filter(marker => {
          const type = marker.tipo === 'mascota' ? (marker as PetReportMarker).tipo_r : marker.tipo;
          return type === selectedFilter;
        });

    if (!bounds) {
        setVisibleMarkers([]);
        return;
    }

    const b = bounds.toJSON ? bounds.toJSON() : bounds;
    const visible = filteredMarkers.filter(m => 
        m.lat >= b.south && m.lat <= b.north && m.lng >= b.west && m.lng <= b.east
    );
    setVisibleMarkers(visible);

  }, [selectedFilter, markers, petPlaces, bounds, viewMode]);

  const geolocate = () => {
    if (!navigator.geolocation) {
      presentToast({ message: 'La geolocalización no es soportada por este navegador.', duration: 3000, color: 'danger' });
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const newCenter = { lat: position.coords.latitude, lng: position.coords.longitude };
        setMapCenter(newCenter);
        fetchPetPlaces(newCenter.lat, newCenter.lng);
        presentToast({ message: 'Ubicación actualizada.', duration: 2000, color: 'success' });
      },
      () => {
        presentAlert({ header: 'Error de Ubicación', message: 'No se pudo obtener tu ubicación. Asegúrate de tener los permisos activados en tu navegador.', buttons: ['OK'], });
      }
    );
  };

  const location = useLocation<{ refresh?: boolean }>();

  useEffect(() => {
    if (location.state?.refresh) {
      // 1. Ocultar la infowindow si estaba abierta
      setSelectedMarker(null);
      setActiveMarker(null);
      
      // 2. Volver a cargar los marcadores desde Firestore
      fetchMarkers();
      
      // 3. Limpiar el estado para que no se recargue de nuevo si el usuario navega
      history.replace('/app/buscar', undefined);
    }
  }, [location, fetchMarkers, history]);

  const handleCameraChange = useCallback((ev: MapCameraChangedEvent) => {
    const newBounds = ev.detail.bounds;
    setBounds(newBounds);
    const newCenter = ev.detail.center;

    setMapCenter(currentCenter => {
      if (currentCenter.lat.toFixed(4) !== newCenter.lat.toFixed(4) || 
          currentCenter.lng.toFixed(4) !== newCenter.lng.toFixed(4)) {
        return newCenter;
      }
      return currentCenter;
    });

    if (fetchPlacesTimeout.current) clearTimeout(fetchPlacesTimeout.current);
    fetchPlacesTimeout.current = setTimeout(() => {
      fetchPetPlaces(newCenter.lat, newCenter.lng);
    }, 800);
  }, [fetchPetPlaces]);

  // --- FUNCIÓN ORIGINAL DE BÚSQUEDA (SIN CAMBIOS) ---
  const handleSearchInputChange = async (e: any) => {
    const input = e.detail.value!;
    setSearchQuery(input);
    if (input.length > 2) {
      const url = `/api/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&key=${API_KEY}&types=address`;
      try {
        const data = await xhrFetch(url);
        setPredictions(data.predictions || []);
      } catch (error) {
        console.error("[XHR-PROXY] Autocomplete request failed:", error);
      }
    } else {
      setPredictions([]);
    }
  };

  // --- FUNCIÓN ORIGINAL DE SUGERENCIA (SIN CAMBIOS) ---
  const handleSuggestionClick = async (place_id: string, description: string) => {
    setSearchQuery(description);
    setPredictions([]);
    const url = `https://maps.googleapis.com/maps/api/geocode/json?place_id=${place_id}&key=${API_KEY}`;
    try {
      const data = await xhrFetch(url);
      if (data.results && data.results.length > 0) {
        const location = data.results[0].geometry.location;
        setMapCenter({ lat: location.lat, lng: location.lng });
        fetchPetPlaces(location.lat, location.lng);
        closeSearchModal();
      } else {
        presentAlert({ header: 'Error', message: 'No se pudo obtener la ubicación de la dirección.', buttons: ['OK'] });
      }
    } catch (error) {
        console.error("[XHR-DIRECT] Geocode from Place ID failed:", error);
        presentAlert({ header: 'Error', message: 'Ocurrió un error al buscar la dirección.', buttons: ['OK'] });
    }
  };

  const handleSearchSubmit = async () => {
    if (!searchQuery) {
      presentToast({ message: 'Por favor ingrese una dirección para buscar.', duration: 2000, color: 'warning' });
      return;
    }
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(searchQuery)}&key=${API_KEY}`;
    try {
      const data = await xhrFetch(url);
      if (data.results && data.results.length > 0) {
        const location = data.results[0].geometry.location;
        setMapCenter({ lat: location.lat, lng: location.lng });
        fetchPetPlaces(location.lat, location.lng);
        closeSearchModal();
      } else {
        presentAlert({ header: 'Sin resultados', message: 'No se pudo encontrar la ubicación para la dirección ingresada.', buttons: ['OK'] });
      }
    } catch (error) {
        console.error("[XHR-DIRECT] Geocode from address failed:", error);
        presentAlert({ header: 'Error', message: 'Ocurrió un error al buscar la dirección.', buttons: ['OK'] });
    }
  };
  
  const closeSearchModal = () => {
    allowFocusOpen.current = false;
    setIsSearchModalOpen(false);
    setPredictions([]);
    setSearchQuery('');
    if (searchbarRef.current) {
      searchbarRef.current.getInputElement().then(input => {
        input.blur();
      });
    }
    setTimeout(() => {
      allowFocusOpen.current = true;
    }, 300);
  };

  const handleMarkerClick = (marker: Marker | GooglePetPlace) => { 
      setSelectedMarker(marker); 
      setActiveMarker(marker); 
  };
  const handleMapClick = (event: MapMouseEvent) => {
    if (!event.detail.latLng) return;
    const { lat, lng } = event.detail.latLng;
    if (isPlacingMarker) { setNewStoreLocation({ lat, lng }); setIsCreaTiendaOpen(true); }
    if (isPlacingPetReport) { setNewReportLocation({ lat, lng }); setIsReporteMascotaOpen(true); }
  };

  const closeVerMarcador = () => {
    setIsVerMarcadorOpen(false);
    setMarkerForModal(null); // <-- Limpia el objeto completo
    setActiveMarker(null);
    fetchMarkers();
  };  
  

  const openVerMarcadorModal = (marker: Marker | GooglePetPlace) => {
    // La lógica para mascotas no cambia
    if (marker.tipo === 'mascota') {
      history.push(`/app/reporte/${marker.id}`);
    } else {
      setMarkerForModal(marker); // <-- Guarda el objeto completo
      setIsVerMarcadorOpen(true);
      setSelectedMarker(null); // Ocultar infowindow al abrir el modal
    }
  };  
  const handleLogout = () => {
    setShowProfileModal(false);
    logout();
  };
  
  const closeModMarcador = () => { setIsModMarcadorOpen(false); setActiveMarker(null); fetchMarkers(); };
  const closeCreaTienda = () => { setIsCreaTiendaOpen(false); setIsPlacingMarker(false); setNewStoreLocation(null); fetchMarkers(); };
  const closeReporteMascota = () => { setIsReporteMascotaOpen(false); setIsPlacingPetReport(false); setNewReportLocation(null); setEditingReportId(undefined); fetchMarkers(); };
  
  const startPlacingMarker = () => { setIsPlacingMarker(true); presentToast({ message: 'Haga clic en el mapa para colocar el marcador de la tienda', duration: 3000 }); };
  const startPlacingPetReport = () => { setIsPlacingPetReport(true); presentToast({ message: 'Haga clic en el mapa para reportar una mascota', duration: 3000 }); };
  const openEditReportModal = () => { if (activeMarker && 'iduser' in activeMarker) { setEditingReportId(activeMarker.id); setIsReporteMascotaOpen(true); setSelectedMarker(null); } };

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="buscar-toolbar">
          <div className="buscar-header">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9" 
              alt="MyPet" 
              className="logo-buscar"
            />
            <IonButtons className="header-buttons">
              <IonButton fill="clear" onClick={() => setViewMode(viewMode === 'map' ? 'list' : 'map')}>
                <IonIcon icon={viewMode === 'map' ? listOutline : homeOutline} />
              </IonButton>
              <IonAvatar className="avatar-header" onClick={() => setShowProfileModal(true)}>
                <img src={user?.fotouser} alt="Perfil" />
              </IonAvatar>
            </IonButtons>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent className="buscar-content">
        <div className="map-container">
          <APIProvider apiKey={API_KEY}>
            <Map 
              mapId={'DEMO_MAP_ID'} 
              style={{ width: '100%', height: '100%' }} 
              center={mapCenter} 
              onCameraChanged={handleCameraChange} 
              defaultZoom={15} 
              onClick={handleMapClick} 
              gestureHandling={'greedy'}
            >
              {/* --- RENDERIZADO UNIFICADO --- */}
              {visibleMarkers.map((marker) => {
                const markerType = marker.tipo === 'mascota' ? (marker as PetReportMarker).tipo_r : marker.tipo;
                return (
                  <AdvancedMarker 
                    key={marker.id} 
                    position={{ lat: marker.lat, lng: marker.lng }}
                  >
                    <CustomMapPin 
                      tipo={markerType}
                      onClick={() => handleMarkerClick(marker)}
                    />
                  </AdvancedMarker>
                );
              })}
            </Map>
          </APIProvider>

          {loadingPetPlaces && (
              <div className="map-loading-overlay">
                  <IonSpinner name="crescent" />
              </div>
          )}

          {selectedMarker && activeMarker && (
            <div className="infowindow-overlay" onClick={() => setSelectedMarker(null)}>
              <div className="infowindow-card" onClick={(e) => e.stopPropagation()}>
                <IonButton fill="clear" className="infowindow-close" onClick={() => setSelectedMarker(null)}>
                  <IonIcon icon={close} />
                </IonButton>

                <div className="infowindow-image-container">
                  <img src={selectedMarker.foto} alt={selectedMarker.nombre} className="infowindow-image" />
                  <IonBadge className={`infowindow-badge ${selectedMarker.tipo}`}>
                     {selectedMarker.tipo === 'mascota' ? (selectedMarker as PetReportMarker).tipo_r : selectedMarker.tipo}
                  </IonBadge>
                </div>

                <div className="infowindow-content">
                  <h3>{selectedMarker.nombre}</h3>
                  <p className="infowindow-description">{selectedMarker.descripcion}</p>
                  
                  {'rating' in selectedMarker && selectedMarker.rating > 0 && (
                      <div className="infowindow-rating">
                          <IonIcon icon={star} color="warning"/>
                          <span>{selectedMarker.rating} ({selectedMarker.userRatingsTotal} reseñas)</span>
                      </div>
                  )}

                  <div className="infowindow-actions">
                    <IonButton expand="block" className="infowindow-btn primary" onClick={() => openVerMarcadorModal(selectedMarker)}>
                        Ver Detalles y Comentarios
                    </IonButton>
                    
                    {'iduser' in selectedMarker && user?.uid === activeMarker.iduser && (
                        <IonButton expand="block" fill="outline" className="infowindow-btn secondary" onClick={(activeMarker as Marker).tipo !== 'mascota' ? () => setIsModMarcadorOpen(true) : openEditReportModal}>
                        Modificar
                        </IonButton>
                    )}
                    {!('iduser' in selectedMarker) && (
                          <IonButton 
                            expand="block" 
                            fill="outline" 
                            className="infowindow-btn secondary" 
                            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedMarker.nombre)}&query_place_id=${selectedMarker.id}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            Ver en Google Maps
                          </IonButton>
                    )}
                  </div>

                </div>
              </div>
            </div>
          )}

          <div className="search-bar-floating">
            <IonSearchbar
              ref={searchbarRef}
              placeholder="Buscar dirección..."
              value={searchQuery}
              onIonFocus={() => {
                if (allowFocusOpen.current) {
                  setIsSearchModalOpen(true);
                }
              }}
              className="custom-searchbar"
            />
          </div>

          <div className="filters-container">
            {filters.map((filter) => (
              <IonChip
                key={filter.id}
                className={`filter-chip ${selectedFilter === filter.id ? 'active' : ''}`}
                onClick={() => setSelectedFilter(filter.id)}
              >
                <IonIcon icon={filter.icon} />
                <IonLabel>{filter.label}</IonLabel>
              </IonChip>
            ))}
          </div>

          {viewMode === 'list' && (
            <div className="markers-list-overlay">
              <div className="list-header">
                <h3>Resultados en la lista</h3>
                <IonBadge color="primary">{visibleMarkers.length}</IonBadge>
              </div>
              <div className="markers-scroll">
                {visibleMarkers.map((marker) => (
                  <IonCard key={marker.id} className="marker-card-compact" onClick={() => { setViewMode('map'); setMapCenter({lat: marker.lat, lng: marker.lng}); handleMarkerClick(marker); }}>
                    <div className="marker-card-content">
                      <img src={marker.foto} alt={marker.nombre} className="marker-thumb" />
                      <div className="marker-info">
                        <h4>{marker.nombre}</h4>
                        <p>{marker.descripcion}</p>
                        <IonBadge className={`type-badge ${marker.tipo}`}>
                          {marker.tipo === 'mascota' ? (marker as PetReportMarker).tipo_r : marker.tipo}
                        </IonBadge>
                      </div>
                    </div>
                  </IonCard>
                ))}
              </div>
            </div>
          )}

          <div className="quick-actions-bottom">
            <IonButton 
              className="quick-action-btn"
              onClick={geolocate}
            >
              <IonIcon icon={navigate} slot="start" />
              Ubicación actual
            </IonButton>
            
            <IonButton 
              className="quick-action-btn secondary"
              onClick={startPlacingPetReport}
            >
              <IonIcon icon={paw} slot="start" />
              Reportar
            </IonButton>
            
            {(user?.admin || user?.tienda) && (
              <IonButton 
                className="quick-action-btn secondary"
                onClick={startPlacingMarker}
              >
                <IonIcon icon={storefrontOutline} slot="start" />
                Tienda
              </IonButton>
            )}
          </div>
        </div>
        
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user}/>}
        <VerMarcador
          isOpen={isVerMarcadorOpen}
          onClose={closeVerMarcador}
          marker={markerForModal} // <-- Pasa el objeto completo
        />
        {activeMarker && activeMarker.tipo !== 'mascota' && <ModMarcador isOpen={isModMarcadorOpen} onClose={closeModMarcador} markerId={activeMarker.id} /> }
        <CreaTienda isOpen={isCreaTiendaOpen} onClose={closeCreaTienda} location={newStoreLocation} googleMapsApiKey={API_KEY} />
        <ReporteMascota isOpen={isReporteMascotaOpen} onClose={closeReporteMascota} location={newReportLocation} reportId={editingReportId} googleMapsApiKey={API_KEY} />

      </IonContent>

      <IonModal 
        isOpen={isSearchModalOpen} 
        onDidDismiss={closeSearchModal}
        className="search-modal"
      >
        <div className="search-modal-content">
          <div className="search-modal-header">
            <div className="modal-handle"></div>
            <h2>Buscar Ubicación</h2>
            <IonButton fill="clear" onClick={closeSearchModal} className="close-btn-small">
              <IonIcon icon={close} />
            </IonButton>
          </div>

          <div className="search-input-container">
            <IonSearchbar
              placeholder="Ingresa una dirección"
              value={searchQuery}
              className="modal-searchbar"
              autoFocus
              onIonInput={handleSearchInputChange}
            />
          </div>

          <div className="suggestions-container">
            {predictions.length > 0 ? (
              <IonList className="suggestions-list">
                {predictions.map((p) => (
                  <IonItem 
                    key={p.place_id} 
                    button 
                    detail={false}
                    className="suggestion-item"
                    onClick={() => handleSuggestionClick(p.place_id, p.description)}
                  >
                    <IonIcon icon={navigate} slot="start" color="primary" />
                    <IonLabel className="suggestion-label">{p.description}</IonLabel>
                  </IonItem>
                ))}
              </IonList>
            ) : (
              <div className="empty-state">
                <IonIcon icon={navigate} className="empty-icon" />
                <p>Escribe una dirección para buscar</p>
              </div>
            )}
          </div>

          <div className="modal-footer">
            <IonButton 
              expand="block" 
              className="search-submit-btn"
              disabled={!searchQuery}
              onClick={handleSearchSubmit}
            >
              <IonIcon icon={navigate} slot="start" />
              Ir a esta ubicación
            </IonButton>
          </div>
        </div>
      </IonModal>
      
      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mis Conexiones</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/conversations'); }}>
                <IonIcon icon={chatbubbles} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/dato'); }}>
                <IonIcon icon={documentText} />
                <span>Datos de Reportes</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/mascotavirtual'); }}>
                <IonIcon icon={pawOutline} />
                <span>Mi Mascota</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline" onClick={handleLogout}>
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

export default Buscar;
function logout() {
  throw new Error('Function not implemented.');
}

