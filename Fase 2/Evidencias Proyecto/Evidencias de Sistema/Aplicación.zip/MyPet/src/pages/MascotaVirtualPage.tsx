
import React, { useState, useRef, useEffect, useContext, useCallback } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonFooter,
  IonInput,
  IonButton,
  IonIcon,
  IonAvatar,
  IonModal,
  IonRadioGroup,
  IonRadio,
  IonLabel,
  IonChip,
  IonToast,
  IonSpinner,
  IonTextarea,
  IonBackButton,
  IonButtons,
} from '@ionic/react';
import {
  send,
  happy,
  heart,
  cafe,
  gameController,
  sparkles,
  chevronForward,
  chatbubbleEllipsesOutline,
  informationCircleOutline,
} from 'ionicons/icons';
import './MascotaVirtualPage.css';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { firestore } from '../firebase';
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  updateDoc,
  addDoc,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import { UserContext } from '../context/UserContext';

// --- INTERFACES ---
interface Pet {
  id: string;
  nombre: string;
  animal: string;
  foto: string;
  raza: string;
  personalidad?: string;
  virtual?: boolean;
}

// MODIFIED: Added optional 'action' field
interface Message {
  id?: string;
  from: 'user' | 'pet';
  text: string;
  action?: string; // To store the pet's physical actions
  timestamp: Timestamp;
}

// Interface for the AI's structured response
interface PetAIResponse {
  dialogue: string;
  action: string;
}

// --- SETUP WIZARD COMPONENT ---
const SetupWizard: React.FC<{
  userPets: Pet[];
  onFinish: (petId: string, personality: string) => Promise<void>;
  onClose: () => void;
}> = ({ userPets, onFinish, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);
  const [personality, setPersonality] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!selectedPetId || !personality.trim()) return;
    setIsSaving(true);
    try {
      await onFinish(selectedPetId, personality.trim());
    } catch (error) {
      setIsSaving(false);
    }
  };

  return (
    <IonModal 
      isOpen={true} 
      onDidDismiss={onClose} 
      backdropDismiss={false}
      className="setup-modal-mypet"
    >
      <div className="setup-wizard-container">
        {/* Header con progreso */}
        <div className="setup-wizard-header">
          <div className="progress-dots">
            <div className={`dot ${step >= 1 ? 'active' : ''}`}></div>
            <div className="progress-line"></div>
            <div className={`dot ${step >= 2 ? 'active' : ''}`}></div>
          </div>
          
          <div className="wizard-icon-container">
            <div className="wizard-icon-bg">
              <span className="wizard-emoji">🐾</span>
            </div>
          </div>
          
          <h2 className="wizard-title">
            {step === 1 ? 'Elige tu Compañero' : 'Personaliza tu Mascota'}
          </h2>
          <p className="wizard-subtitle">
            {step === 1 
              ? 'Selecciona qué mascota será tu amigo virtual' 
              : 'Cuéntame sobre su personalidad única'}
          </p>
        </div>

        {/* Contenido de los pasos */}
        <div className="setup-wizard-content">
          {step === 1 && (
            <div className="wizard-step">
              <div className="pets-grid">
                <IonRadioGroup 
                  value={selectedPetId} 
                  onIonChange={(e) => setSelectedPetId(e.detail.value)}
                >
                  {userPets.length > 0 ? userPets.map(pet => (
                    <div 
                      key={pet.id} 
                      className={`pet-selection-card-mypet ${selectedPetId === pet.id ? 'selected' : ''}`}
                      onClick={() => setSelectedPetId(pet.id)}
                    >
                      <div className="pet-card-content">
                        <IonAvatar className="pet-card-avatar">
                          <img src={pet.foto} alt={pet.nombre} />
                        </IonAvatar>
                        
                        <div className="pet-card-info">
                          <h3>{pet.nombre}</h3>
                          <IonChip className="pet-type-chip">
                            <span>{pet.animal}</span>
                          </IonChip>
                          <span className="pet-breed">{pet.raza}</span>
                        </div>

                        <div className="radio-check">
                          <IonRadio value={pet.id} />
                        </div>
                      </div>
                      
                      {selectedPetId === pet.id && (
                        <div className="selected-indicator">
                          <div className="paw-indicator">🐾</div>
                        </div>
                      )}
                    </div>
                  )) : (
                    <div className="no-pets-state">
                      <div className="empty-icon">😿</div>
                      <p>No tienes mascotas registradas</p>
                      <span>Ve a inicio para agregar una</span>
                    </div>
                  )}
                </IonRadioGroup>
              </div>

              <div className="wizard-actions">
                <IonButton 
                  expand="block" 
                  onClick={() => setStep(2)} 
                  disabled={!selectedPetId}
                  className="wizard-btn-primary"
                >
                  Continuar
                  <IonIcon slot="end" icon={chevronForward} />
                </IonButton>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="wizard-step step-personality">
              <div className="personality-card-mypet">
                <div className="personality-header">
                  <div className="personality-icon">✨</div>
                  <h3>Personalidad de {userPets.find(p => p.id === selectedPetId)?.nombre}</h3>
                  <p>Describe cómo es tu mascota para crear conversaciones más reales</p>
                </div>

                <div className="personality-examples">
                  <div className="example-tip">
                    <IonIcon icon={informationCircleOutline} />
                    <span>Ejemplo: "Es juguetón, le encantan las siestas al sol..."</span>
                  </div>
                </div>

                <IonTextarea
                  className="personality-input-mypet"
                  placeholder="Escribe aquí la personalidad de tu mascota..."
                  value={personality}
                  onIonInput={(e) => setPersonality(e.detail.value ?? '')}
                  rows={6}
                  autoGrow={true}
                />

                <div className="char-counter">
                  {personality.length} caracteres
                </div>
              </div>

              <div className="wizard-actions-double">
                <IonButton 
                  fill="outline" 
                  onClick={() => setStep(1)}
                  className="wizard-btn-back"
                >
                  Atrás
                </IonButton>
                
                <IonButton 
                  expand="block" 
                  onClick={handleSave} 
                  disabled={!personality.trim() || isSaving}
                  className="wizard-btn-finish"
                >
                  {isSaving ? (
                    <>
                      <IonSpinner name="crescent" />
                      <span>Guardando...</span>
                    </>
                  ) : (
                    <>
                      <span>Empezar a Chatear</span>
                      <IonIcon slot="end" icon={chatbubbleEllipsesOutline} />
                    </>
                  )}
                </IonButton>
              </div>
            </div>
          )}
        </div>
      </div>
    </IonModal>
  );
};


// --- MAIN PAGE COMPONENT ---
const MascotaVirtualPage: React.FC = () => {
  const [virtualPet, setVirtualPet] = useState<Pet | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [userPetsForSetup, setUserPetsForSetup] = useState<Pet[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [, setErrorToast] = useState<string | null>(null);

  const contentRef = useRef<HTMLIonContentElement>(null);
  const { user } = useContext(UserContext);

  useEffect(() => {
    if (!user?.uid) {
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    const q = query(collection(firestore, 'mascotas'), where('iduser', '==', user.uid));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const allPets = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pet));
      const existingVirtualPet = allPets.find(p => p.virtual === true);

      if (existingVirtualPet) {
        setVirtualPet(existingVirtualPet);
        setNeedsSetup(false);
      } else {
        setVirtualPet(null);
        setUserPetsForSetup(allPets);
        setNeedsSetup(true);
      }
      setIsLoading(false);
    }, (error) => {
      console.error("Error fetching pets:", error);
      setErrorToast("No se pudieron cargar los datos de tus mascotas.");
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!virtualPet?.id) {
      setMessages([]);
      return;
    }
    const messagesQuery = query(
      collection(firestore, 'mascotas', virtualPet.id, 'mensajes_virtuales'),
      orderBy('timestamp', 'asc')
    );
    const unsubscribe = onSnapshot(messagesQuery, (snapshot) => {
      const messagesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
      setMessages(messagesData);
      setTimeout(() => contentRef.current?.scrollToBottom(500), 300);
    }, (err) => {
      console.error("Error fetching messages:", err);
      setErrorToast("No se pudo cargar el historial del chat.");
    });
    return () => unsubscribe();
  }, [virtualPet]);

  const handleCompleteSetup = useCallback(async (petId: string, personality: string) => {
    const petToUpdate = userPetsForSetup.find(p => p.id === petId);
    if (!petToUpdate) {
      setErrorToast("Error: No se pudo encontrar la mascota para actualizar.");
      throw new Error("Pet to update not found");
    }

    try {
      const petRef = doc(firestore, 'mascotas', petId);
      await updateDoc(petRef, { personalidad: personality, virtual: true });
      setVirtualPet({ ...petToUpdate, personalidad: personality, virtual: true });
      setNeedsSetup(false);
    } catch (error) {
      console.error("Error setting up virtual pet:", error);
      setErrorToast("Hubo un error al guardar la configuración.");
      throw error;
    }
  }, [userPetsForSetup]);

  // MODIFIED: Updated to handle new response format
  const handleSendMessage = useCallback(async () => {
    if (!newMessage.trim() || !virtualPet?.id || !virtualPet.personalidad || isSending) return;

    setIsSending(true);
    const text = newMessage;
    setNewMessage('');
    
    const userMsg: Message = { from: 'user' as const, text, timestamp: Timestamp.now() };
    const messagesCol = collection(firestore, 'mascotas', virtualPet.id, 'mensajes_virtuales');

    try {
      // Add user message to Firestore immediately for responsiveness
      await addDoc(messagesCol, userMsg);
      
      const functions = getFunctions();
      const chatWithPet = httpsCallable(functions, 'chatWithPet');

      // Send the last 15 messages for context
      const historyForAI = [...messages, userMsg]
        .slice(-15)
        .map(({ from, text }) => ({ from, text }));

      const result = await chatWithPet({
        pet: { 
          nombre: virtualPet.nombre, 
          animal: virtualPet.animal, 
          personalidad: virtualPet.personalidad 
        },
        messages: historyForAI,
      });

      // Process the structured JSON response from the backend
      const petResponse = (result.data as { response: PetAIResponse }).response;
      
      if (!petResponse || (!petResponse.dialogue && !petResponse.action)) {
        throw new Error("La IA no devolvió una respuesta válida.");
      }

      // Create the pet's message object with both dialogue and action
      const petMsg: Message = {
        from: 'pet',
        text: petResponse.dialogue, // The spoken part
        action: petResponse.action, // The physical action
        timestamp: Timestamp.now(),
      };

      // Save the complete pet message to Firestore
      await addDoc(messagesCol, petMsg);

    } catch (error) {
      console.error("Error sending message:", error);
      setErrorToast("No se pudo obtener una respuesta. Inténtalo de nuevo.");
    } finally {
      setIsSending(false);
    }
  }, [newMessage, virtualPet, isSending, messages]);

  const quickActions = [
    { id: 1, texto: '¿Cómo estás?', icon: happy, emoji: '😊' },
    { id: 2, texto: 'Te quiero', icon: heart, emoji: '❤️' },
    { id: 3, texto: '¿Tienes hambre?', icon: cafe, emoji: '🍖' },
    { id: 4, texto: '¿Quieres jugar?', icon: gameController, emoji: '🎾' },
  ];

  if (isLoading) {
    return (
      <IonPage>
        <IonContent><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}><IonSpinner name="crescent" /></div></IonContent>
      </IonPage>
    );
  }

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="virtual-header-toolbar">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/home" text="" className="back-btn-virtual" />
          </IonButtons>
          
          <div className="virtual-header-content">
            <div className="pet-avatar-header">
              <IonAvatar className="header-avatar-mypet">
                <img src={virtualPet?.foto} alt={virtualPet?.nombre} />
              </IonAvatar>
              <div className="online-pulse"></div>
            </div>
            
            <div className="pet-info-header">
              <h1>{virtualPet?.nombre || 'Mascota Virtual'}</h1>
              <div className="status-badge">
                <span className="status-dot"></span>
                <span>En línea</span>
              </div>
            </div>
          </div>

          <IonButtons slot="end">
            <IonButton fill="clear" className="info-btn-header">
              <IonIcon icon={informationCircleOutline} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent ref={contentRef} className="virtual-content-mypet" scrollEvents={true}>
        <div className="chat-background-pattern">
          <div className="pattern-paw paw-1">🐾</div>
          <div className="pattern-paw paw-2">🐾</div>
          <div className="pattern-paw paw-3">🐾</div>
        </div>

        {needsSetup && (
          <SetupWizard 
            userPets={userPetsForSetup} 
            onFinish={handleCompleteSetup} 
            onClose={() => setNeedsSetup(false)} 
          />
        )}

        <div className="messages-container-mypet">
          <div className="date-divider">
            <span>Hoy</span>
          </div>

          {messages.map((msg, index) => (
            <div key={msg.id || index} className={`message-wrapper-mypet ${msg.from}`}>
              {msg.from === 'pet' && (
                <IonAvatar className="message-avatar-mypet">
                  <img src={virtualPet?.foto} alt={virtualPet?.nombre} />
                </IonAvatar>
              )}
              
              <div className="message-content-mypet">
                {msg.from === 'pet' && (
                  <span className="message-author">{virtualPet?.nombre}</span>
                )}
                
                {/* MODIFIED: Display the action text if it exists */}
                {msg.from === 'pet' && msg.action && (
                  <p className="message-action-mypet">{msg.action}</p>
                )}

                {/* Only render the bubble if there is text dialogue */}
                {msg.text && (
                    <div className={`message-bubble-mypet ${msg.from === 'user' ? 'user-bubble' : 'pet-bubble'}`}>
                        <p className="message-text-mypet">{msg.text}</p>
                        <span className="message-time-mypet">
                        {msg.timestamp.toDate().toLocaleTimeString('es-ES', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                        })}
                        </span>
                    </div>
                )}
              </div>
            </div>
          ))}

          {isSending && (
            <div className="message-wrapper-mypet pet">
              <IonAvatar className="message-avatar-mypet">
                <img src={virtualPet?.foto} alt={virtualPet?.nombre} />
              </IonAvatar>
              <div className="message-content-mypet">
                <span className="message-author">{virtualPet?.nombre}</span>
                <div className="typing-indicator-mypet">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
        </div>
      </IonContent>

      <div className="quick-actions-bar">
        <div className="quick-actions-label">
          <IonIcon icon={sparkles} />
          <span>Respuestas rápidas</span>
        </div>
        <div className="quick-actions-scroll-mypet">
          {quickActions.map(action => (
            <IonChip 
              key={action.id} 
              className="quick-action-chip-mypet" 
              onClick={() => setNewMessage(action.texto)}
            >
              <span className="action-emoji">{action.emoji}</span>
              <IonLabel>{action.texto}</IonLabel>
            </IonChip>
          ))}
        </div>
      </div>

      <IonFooter className="ion-no-border">
        <IonToolbar className="virtual-footer-mypet">
          <div className="input-container-mypet">
            <div className="input-wrapper-mypet">
              <IonInput 
                value={newMessage} 
                onIonInput={e => setNewMessage(e.detail.value!)} 
                placeholder={`Mensaje para ${virtualPet?.nombre}...`}
                className="virtual-input-mypet" 
                onKeyPress={e => e.key === 'Enter' && handleSendMessage()} 
                disabled={isSending}
              />
              <IonButton 
                fill="clear" 
                className="send-btn-mypet" 
                onClick={handleSendMessage} 
                disabled={!newMessage.trim() || isSending}
              >
                <IonIcon icon={send} />
              </IonButton>
            </div>
          </div>
        </IonToolbar>
      </IonFooter>

      <IonToast 
        isOpen={false} 
        message="" 
        duration={4000} 
        color="danger" 
        position="top" 
      />
    </IonPage>
  );
};

export default MascotaVirtualPage;
