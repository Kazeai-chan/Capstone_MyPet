import React, { useState, useRef, useEffect } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonFooter,
  IonInput,
  IonButton,
  IonIcon,
  IonAvatar,
  IonModal,
  IonCard,
  IonCardContent,
  IonRadioGroup,
  IonRadio,
  IonLabel,
  IonChip,
} from '@ionic/react';
import {
  pawOutline,
  send,
  happy,
  heart,
  cafe,
  gameController,
  informationCircleOutline,
  close,
  sparkles
} from 'ionicons/icons';

interface Pet {
  id: number;
  nombre: string;
  animal: string;
  foto: string;
  personalidad: string;
}

interface Message {
  id: number;
  from: 'user' | 'pet';
  text: string;
  timestamp: string;
}

const MascotaVirtualPage = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [showSetupModal, setShowSetupModal] = useState(true);
  const [selectedPet, setSelectedPet] = useState<Pet | null>(null);
  //const [petMood, setPetMood] = useState('feliz');
  const [isTyping, setIsTyping] = useState(false);
  const contentRef = useRef<HTMLIonContentElement>(null);

  const misMascotas = [
    { 
      id: 1, 
      nombre: 'Rocky', 
      animal: 'Perro',
      foto: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=300',
      personalidad: 'juguetón y energético'
    },
    { 
      id: 2, 
      nombre: 'Luna', 
      animal: 'Gato',
      foto: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=300',
      personalidad: 'independiente y curiosa'
    },
    { 
      id: 3, 
      nombre: 'Max', 
      animal: 'Perro',
      foto: 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=300',
      personalidad: 'tranquilo y cariñoso'
    }
  ];

  const quickActions = [
    { id: 1, texto: '¿Cómo estás?', icon: happy },
    { id: 2, texto: 'Te quiero', icon: heart },
    { id: 3, texto: '¿Tienes hambre?', icon: cafe },
    { id: 4, texto: '¿Quieres jugar?', icon: gameController }
  ];

  useEffect(() => {
    if (selectedPet && messages.length === 0) {
      const welcomeMessage: Message = {
        id: Date.now(),
        from: 'pet',
        text: `¡Guau! 🐾 Soy ${selectedPet.nombre}, tu mascota virtual. ¡Estoy muy feliz de conocerte! ¿Quieres jugar conmigo?`,
        timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages([welcomeMessage]);
    }
  }, [selectedPet, messages.length]);

  const handleSelectPet = (pet: Pet | undefined) => {
    setSelectedPet(pet || null);
    setShowSetupModal(false);
  };

  const generateResponse = (userMessage: string): string => {
    const responses: { [key: string]: string[] } = {
      'hola': [
        `¡Guau guau! 🐾 ¡Hola amigo! ¡Qué alegría verte!`,
        `¡Woof! 😊 ¡Hola! ¡Mi cola no para de moverse de felicidad!`
      ],
      'cómo estás': [
        `¡Estoy súper feliz! 😄 Especialmente ahora que estás aquí. ¿Y tú cómo estás?`,
        `¡Genial! 🎉 He estado esperando para jugar contigo. ¿Hacemos algo divertido?`
      ],
      'te quiero': [
        `¡Awww! 💕 ¡Yo también te quiero muchísimo! Eres la mejor persona del mundo.`,
        `¡Mi corazón está lleno de amor por ti! 💖 *mueve la cola felizmente*`
      ],
      'hambre': [
        `¡Sí! 🍖 ¡Siempre tengo hambre! ¿Me das una galleta? *ojos de cachorro*`,
        `¡Mmm! 😋 Un snack estaría genial ahora. ¿Tienes algo rico?`
      ],
      'jugar': [
        `¡Sííí! 🎾 ¡Me encanta jugar! ¿Traes la pelota? *salta emocionado*`,
        `¡Woohoo! 🎉 ¡Vamos a jugar! Soy el mejor atrapando cosas.`
      ],
      'triste': [
        `¿Estás triste? 😢 Ven aquí, te daré todos mis lamidos y abrazos. Todo estará bien.`,
        `*se acerca y pone la cabeza en tu regazo* 💙 Estoy aquí para ti, siempre.`
      ],
      'paseo': [
        `¡PASEO! ¡PASEO! 🚶 *gira en círculos* ¡Ya tengo mi correa lista!`,
        `¡Yujuuu! 🌳 ¡Me encantan los paseos! ¿Vamos al parque?`
      ],
      'default': [
        `¡Woof! 🐾 Eso suena interesante. Cuéntame más.`,
        `*ladea la cabeza* 🤔 Hmm, no entendí del todo, ¿puedes explicarme?`,
        `¡Me gusta cuando hablas conmigo! 😊 Sigue contándome cosas.`,
        `*mueve la cola* 🐕 ¡Estoy escuchando! Dime más.`
      ]
    };

    const lowerMessage = userMessage.toLowerCase();
    let selectedResponses = responses.default;

    for (const key in responses) {
      if (lowerMessage.includes(key)) {
        selectedResponses = responses[key];
        break;
      }
    }

    return selectedResponses[Math.floor(Math.random() * selectedResponses.length)];
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const userMsg: Message = {
      id: Date.now(),
      from: 'user',
      text: newMessage,
      timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setNewMessage('');
    setIsTyping(true);

    // Simular respuesta de la mascota
    setTimeout(() => {
      const petResponse: Message = {
        id: Date.now() + 1,
        from: 'pet',
        text: generateResponse(newMessage),
        timestamp: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, petResponse]);
      setIsTyping(false);
      
      // Scroll al final
      setTimeout(() => {
        contentRef.current?.scrollToBottom(300);
      }, 100);
    }, 1000 + Math.random() * 1000);
  };

  const handleQuickAction = (texto: string) => {
    setNewMessage(texto);
  };

  return (
    <IonPage>
      {/* Header */}
      <IonHeader className="ion-no-border">
        <IonToolbar className="mascota-virtual-toolbar">
          <div className="virtual-header">
            <div className="header-pet-info">
              <IonAvatar className="header-pet-avatar">
                <img src={selectedPet?.foto || 'https://via.placeholder.com/60'} alt={selectedPet?.nombre} />
                <div className="online-indicator-pet"></div>
              </IonAvatar>
              <div className="pet-info-text">
                <h1>{selectedPet?.nombre || 'Mi Mascota Virtual'}</h1>
                <span className="pet-status">🟢 En línea</span>
              </div>
            </div>
            <IonButton 
              fill="clear" 
              className="info-btn-virtual"
              onClick={() => setShowSetupModal(true)}
            >
              <IonIcon icon={informationCircleOutline} />
            </IonButton>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent ref={contentRef} className="virtual-content">
        {!selectedPet ? (
          <div className="empty-state-virtual">
            <div className="empty-icon-container-virtual">
              <IonIcon icon={pawOutline} />
            </div>
            <h3>Selecciona tu Mascota Virtual</h3>
            <p>Elige una de tus mascotas para comenzar a conversar</p>
            <IonButton onClick={() => setShowSetupModal(true)}>
              <IonIcon icon={sparkles} slot="start" />
              Comenzar
            </IonButton>
          </div>
        ) : (
          <>
            {/* Messages */}
            <div className="messages-container-virtual" >
              {messages.map((msg) => (
                <div key={msg.id} className={`message-wrapper-virtual ${msg.from}`}>
                  {msg.from === 'pet' && (
                    <IonAvatar className="message-avatar-virtual">
                      <img src={selectedPet.foto} alt={selectedPet.nombre} />
                    </IonAvatar>
                  )}
                  
                  <div className={`message-bubble-virtual ${msg.from === 'user' ? 'user-bubble' : 'pet-bubble'}`}>
                    <p className="message-text-virtual">{msg.text}</p>
                    <span className="message-time-virtual">{msg.timestamp}</span>
                  </div>
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="message-wrapper-virtual pet">
                  <IonAvatar className="message-avatar-virtual">
                    <img src={selectedPet.foto} alt={selectedPet.nombre} />
                  </IonAvatar>
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="quick-actions-container">
              <div className="quick-actions-scroll">
                {quickActions.map(action => (
                  <IonChip 
                    key={action.id} 
                    className="quick-action-chip"
                    onClick={() => handleQuickAction(action.texto)}
                  >
                    <IonIcon icon={action.icon} />
                    <IonLabel>{action.texto}</IonLabel>
                  </IonChip>
                ))}
              </div>
            </div>
          </>
        )}
      </IonContent>

      {/* Footer Input */}
      {selectedPet && (
        <IonFooter className="ion-no-border">
          <IonToolbar className="virtual-footer-toolbar">
            <div className="virtual-input-container">
              <IonInput
                value={newMessage}
                onIonChange={e => setNewMessage(e.detail.value!)}
                placeholder={`Escribe a ${selectedPet.nombre}...`}
                className="virtual-input"
                onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
              />
              <IonButton
                fill="clear"
                className="send-btn-virtual"
                onClick={handleSendMessage}
                disabled={!newMessage.trim()}
              >
                <IonIcon icon={send} />
              </IonButton>
            </div>
          </IonToolbar>
        </IonFooter>
      )}

      {/* Setup Modal */}
      <IonModal 
        isOpen={showSetupModal} 
        onDidDismiss={() => selectedPet && setShowSetupModal(false)}
        className="setup-modal"
      >
        <div className="setup-content">
          <IonButton 
            fill="clear" 
            className="close-setup-btn"
            onClick={() => selectedPet && setShowSetupModal(false)}
          >
            <IonIcon icon={close} />
          </IonButton>

          <div className="setup-header">
            <div className="sparkles-icon">
              <IonIcon icon={sparkles} />
            </div>
            <h2>Mi Mascota Virtual</h2>
            <p>Selecciona una de tus mascotas para crear tu compañero virtual</p>
          </div>

          <div className="pets-selection-virtual">
            <IonRadioGroup value={selectedPet?.id} onIonChange={e => {
              const pet = misMascotas.find(p => p.id === parseInt(e.detail.value));
              handleSelectPet(pet);
            }}>
              {misMascotas.map(pet => (
                <IonCard key={pet.id} className="pet-selection-card">
                  <IonCardContent className="pet-selection-content">
                    <IonRadio value={pet.id} className="pet-radio" />
                    <IonAvatar className="pet-selection-avatar">
                      <img src={pet.foto} alt={pet.nombre} />
                    </IonAvatar>
                    <div className="pet-selection-info">
                      <h3>{pet.nombre}</h3>
                      <span className="pet-animal">{pet.animal}</span>
                      <p className="pet-personality">{pet.personalidad}</p>
                    </div>
                  </IonCardContent>
                </IonCard>
              ))}
            </IonRadioGroup>
          </div>

          <div className="setup-footer">
            <IonIcon icon={informationCircleOutline} className="info-icon-small" />
            <p>Tu mascota virtual responderá según su personalidad y podrás conversar con ella cuando quieras</p>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

// CSS Styles
const styles = `
:root {
  --mypet-primary: #445a14;
  --mypet-primary-light: #5a7519;
  --mypet-accent: #d8e59c;
  --mypet-accent-light: #e5f0b8;
  --mypet-cream: #f5f3e8;
  --mypet-cream-dark: #e8e5d3;
  --mypet-white: #ffffff;
  --mypet-text: #2d3436;
  --mypet-text-light: #636e72;
  --mypet-shadow: rgba(68, 90, 20, 0.08);
}

/* Header */
.mascota-virtual-toolbar {
  --background: var(--mypet-white);
  --border-width: 0;
  --min-height: 70px;
  box-shadow: 0 2px 8px var(--mypet-shadow);
}

.virtual-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
}

.header-pet-info {
  display: flex;
  align-items: center;
  gap: 12px;
  flex: 1;
}

.header-pet-avatar {
  width: 48px;
  height: 48px;
  border: 3px solid var(--mypet-accent);
  position: relative;
}

.online-indicator-pet {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 14px;
  height: 14px;
  background: #27ae60;
  border-radius: 50%;
  border: 2px solid var(--mypet-white);
}

.pet-info-text h1 {
  font-size: 18px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 4px 0;
}

.pet-status {
  font-size: 12px;
  color: #27ae60;
  font-weight: 600;
}

.info-btn-virtual {
  --color: var(--mypet-primary);
  margin: 0;
}

.info-btn-virtual ion-icon {
  font-size: 24px;
}

/* Content */
.virtual-content {
  --background: linear-gradient(to bottom, var(--mypet-cream) 0%, #f9f7f2 100%);
}

/* Empty State */
.empty-state-virtual {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 70vh;
  padding: 32px;
  text-align: center;
}

.empty-icon-container-virtual {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: var(--mypet-accent-light);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 24px;
}

.empty-icon-container-virtual ion-icon {
  font-size: 64px;
  color: var(--mypet-primary);
}

.empty-state-virtual h3 {
  font-size: 22px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 8px 0;
}

.empty-state-virtual p {
  font-size: 14px;
  color: var(--mypet-text-light);
  margin: 0 0 24px 0;
  max-width: 280px;
}

.empty-state-virtual ion-button {
  --background: var(--mypet-primary);
  --border-radius: 12px;
  height: 48px;
  font-weight: 600;
}

/* Messages Container */
.messages-container-virtual {
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 100%;
}

.message-wrapper-virtual {
  display: flex;
  gap: 8px;
  align-items: flex-end;
  max-width: 85%;
  animation: messageSlideIn 0.3s ease-out;
}

.message-wrapper-virtual.user {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.message-wrapper-virtual.pet {
  align-self: flex-start;
}

.message-avatar-virtual {
  width: 36px;
  height: 36px;
  flex-shrink: 0;
  border: 2px solid var(--mypet-white);
  box-shadow: 0 2px 6px var(--mypet-shadow);
}

.message-bubble-virtual {
  padding: 12px 16px;
  border-radius: 18px;
  max-width: 100%;
  word-wrap: break-word;
  box-shadow: 0 2px 6px var(--mypet-shadow);
}

.user-bubble {
  background: var(--mypet-primary);
  color: var(--mypet-white);
  border-bottom-right-radius: 4px;
}

.pet-bubble {
  background: var(--mypet-white);
  color: var(--mypet-text);
  border-bottom-left-radius: 4px;
}

.message-text-virtual {
  margin: 0 0 4px 0;
  font-size: 15px;
  line-height: 1.4;
  word-break: break-word;
}

.message-time-virtual {
  font-size: 11px;
  opacity: 0.7;
}

/* Typing Indicator */
.typing-indicator {
  background: var(--mypet-white);
  padding: 16px 20px;
  border-radius: 18px;
  border-bottom-left-radius: 4px;
  display: flex;
  gap: 6px;
  align-items: center;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--mypet-text-light);
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    transform: translateY(0);
    opacity: 0.7;
  }
  30% {
    transform: translateY(-10px);
    opacity: 1;
  }
}

@keyframes messageSlideIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Quick Actions */
.quick-actions-container {
  padding: 12px 16px 8px 16px;
  background: var(--mypet-white);
  border-top: 1px solid var(--mypet-cream-dark);
}

.quick-actions-scroll {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  scrollbar-width: none;
  padding-bottom: 8px;
}

.quick-actions-scroll::-webkit-scrollbar {
  display: none;
}

.quick-action-chip {
  --background: var(--mypet-accent-light);
  --color: var(--mypet-primary);
  flex-shrink: 0;
  font-weight: 600;
  height: 36px;
  cursor: pointer;
}

.quick-action-chip ion-icon {
  font-size: 18px;
  margin-right: 4px;
}

/* Footer */
.virtual-footer-toolbar {
  --background: var(--mypet-white);
  --border-width: 0;
  --padding-top: 8px;
  --padding-bottom: 8px;
  box-shadow: 0 -2px 8px var(--mypet-shadow);
  padding-bottom: env(safe-area-inset-bottom, 0);
}

.virtual-input-container {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  background: var(--mypet-cream);
  border-radius: 24px;
  margin: 0 12px;
}

.virtual-input {
  flex: 1;
  --background: transparent;
  --padding-start: 16px;
  --padding-end: 8px;
  --placeholder-color: var(--mypet-text-light);
  font-size: 15px;
  min-height: 44px;
}

.send-btn-virtual {
  --padding-start: 8px;
  --padding-end: 8px;
  --color: var(--mypet-primary);
  margin: 0;
  flex-shrink: 0;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  transition: all 0.2s;
}

.send-btn-virtual:not([disabled]) {
  --background: var(--mypet-primary);
  --color: var(--mypet-white);
}

.send-btn-virtual[disabled] {
  --color: var(--mypet-text-light);
  opacity: 0.4;
}

.send-btn-virtual ion-icon {
  font-size: 20px;
}

/* Setup Modal */
.setup-modal {
  --height: 85vh;
  --border-radius: 24px 24px 0 0;
}

.setup-content {
  background: var(--mypet-cream);
  height: 100%;
  border-radius: 24px 24px 0 0;
  display: flex;
  flex-direction: column;
  position: relative;
}

.close-setup-btn {
  position: absolute;
  top: 16px;
  right: 16px;
  z-index: 10;
  --color: var(--mypet-text-light);
  margin: 0;
}

.setup-header {
  text-align: center;
  padding: 40px 24px 24px 24px;
  background: var(--mypet-white);
  border-radius: 24px 24px 0 0;
}

.sparkles-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--mypet-accent) 0%, var(--mypet-accent-light) 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px auto;
}

.sparkles-icon ion-icon {
  font-size: 40px;
  color: var(--mypet-primary);
}

.setup-header h2 {
  font-size: 24px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 8px 0;
}

.setup-header p {
  font-size: 14px;
  color: var(--mypet-text-light);
  margin: 0;
  line-height: 1.5;
}

.pets-selection-virtual {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.pet-selection-card {
  margin-bottom: 12px;
  border-radius: 16px;
  box-shadow: 0 2px 8px var(--mypet-shadow);
  cursor: pointer;
  transition: transform 0.2s;
}

.pet-selection-card:active {
  transform: scale(0.98);
}

.pet-selection-content {
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 12px;
}

.pet-radio {
  margin-right: 4px;
  --color-checked: var(--mypet-primary);
}

.pet-selection-avatar {
  width: 60px;
  height: 60px;
  border: 3px solid var(--mypet-accent-light);
  flex-shrink: 0;
}

.pet-selection-info {
  flex: 1;
}

.pet-selection-info h3 {
  font-size: 16px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 4px 0;
}

.pet-animal {
  display: inline-block;
  background: var(--mypet-accent);
  color: var(--mypet-primary);
  padding: 2px 8px;
  border-radius: 8px;
  font-size: 11px;
  font-weight: 600;
  margin-bottom: 6px;
}

.pet-personality {
  font-size: 12px;
  color: var(--mypet-text-light);
  margin: 0;
  font-style: italic;
}

.setup-footer {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 20px;
  background: var(--mypet-accent-light);
  border-top: 1px solid var(--mypet-accent);
}

.info-icon-small {
  font-size: 20px;
  color: var(--mypet-primary);
  flex-shrink: 0;
}

.setup-footer p {
  font-size: 12px;
  color: var(--mypet-text);
  margin: 0;
  line-height: 1.4;
}

/* Responsive */
@media (max-width: 576px) {
  .pet-info-text h1 {
    font-size: 16px;
  }
  
  .message-wrapper-virtual {
    max-width: 90%;
  }
}
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

export default MascotaVirtualPage;