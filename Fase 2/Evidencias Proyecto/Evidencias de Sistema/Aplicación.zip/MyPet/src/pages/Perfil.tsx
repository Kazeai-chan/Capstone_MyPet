
import React, { useState, useRef, useEffect, useContext } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonButton,
  IonIcon,
  IonAvatar,
  IonChip,
  IonSegment,
  IonSegmentButton,
  IonLabel,
  IonBadge,
  IonSpinner,
  IonModal,
} from '@ionic/react';
import {
  pawOutline,
  heartOutline,
  calendarOutline,
  locationOutline,
  chatbubbleEllipsesOutline,
  personAddOutline,
  notifications,
  imageOutline,
  sendOutline,
  closeCircleOutline,
  checkmarkCircleOutline,
  chatbubbles,
  documentText,
  person,
  trophy,
  close
} from 'ionicons/icons';
import { useHistory, useParams } from 'react-router-dom';
import { collection, query, where, getDocs, doc, getDoc, addDoc, deleteDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { firestore } from '../firebase';
import { User, UserContext, UserContextType } from '../context/UserContext';
import './Perfil.css';
import PerfilModal from 'components/PerfilModal';
import DatosModal from 'components/DatosModal';

const API_KEY = "";

interface Pet {
  id: string;
  nombre: string;
  raza: string;
  nacimiento: any; 
  animal: string;
  foto: string;
  color: string;
}

const Perfil = () => {
  const { id: profileIdFromUrl } = useParams<{ id?: string }>();
  const { user: loggedInUser } = useContext(UserContext);
  const history = useHistory();
  
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [pets, setPets] = useState<Pet[]>([]);
  const [friends, setFriends] = useState<User[]>([]);
  const [friendRequests, setFriendRequests] = useState<User[]>([]);
  const [stats, setStats] = useState({ temas: 0, comentarios: 0, gustas: 0 });
  const [friendshipStatus, setFriendshipStatus] = useState<'loading' | 'friends' | 'pending_sent' | 'pending_received' | 'not_friends'>('loading');
  const [friendshipDocId, setFriendshipDocId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const [segmentValue, setSegmentValue] = useState('perfil');
  const coverInputRef = useRef<HTMLInputElement>(null);
  const { user } = useContext<UserContextType>(UserContext);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const { logout } = useContext(UserContext);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isDatosModalOpen, setDatosModalOpen] = useState(false);

  useEffect(() => {
    const userIdToLoad = profileIdFromUrl || loggedInUser?.uid;
    if (!userIdToLoad) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const fetchProfileData = async () => {
      try {
        const userDocRef = doc(firestore, 'usuarios', userIdToLoad);
        const userDocSnap = await getDoc(userDocRef);
        if (userDocSnap.exists()) {
          setProfileUser({ uid: userDocSnap.id, ...userDocSnap.data() } as User);
        } else {
          setProfileUser(null);
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    const fetchPets = async () => {
        try {
            const petsQuery = query(collection(firestore, 'mascotas'), where('iduser', '==', userIdToLoad));
            const petsSnapshot = await getDocs(petsQuery);
            const petsData = petsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Pet));
            setPets(petsData);
        } catch (error) {
            console.error("Error fetching pets:", error);
        }
    };
    
    const fetchUserStats = async () => {
      try {
        const temasQuery = query(collection(firestore, 'temas'), where('iduser', '==', userIdToLoad));
        const comentariosQuery = query(collection(firestore, 'comentarios'), where('c_iduser', '==', userIdToLoad));
        const gustasQuery = query(collection(firestore, 'gustas'), where('iduser', '==', userIdToLoad));

        const [temasSnapshot, comentariosSnapshot, gustasSnapshot] = await Promise.all([
          getDocs(temasQuery),
          getDocs(comentariosQuery),
          getDocs(gustasQuery)
        ]);

        setStats({
          temas: temasSnapshot.size,
          comentarios: comentariosSnapshot.size,
          gustas: gustasSnapshot.size
        });
      } catch (error) {
        console.error("Error fetching user stats:", error);
      }
    };

    Promise.all([fetchProfileData(), fetchPets(), fetchUserStats()]).finally(() => setIsLoading(false));

  }, [profileIdFromUrl, loggedInUser]);

  useEffect(() => {
    if (!profileUser) return;

    const fetchFriendsAndRequests = async () => {
      const friendshipsQuery = query(
        collection(firestore, 'friendships'),
        where('users', 'array-contains', profileUser.uid)
      );
      const friendshipsSnapshot = await getDocs(friendshipsQuery);

      const friendIds: string[] = [];
      const requestUserIds: string[] = [];

      friendshipsSnapshot.docs.forEach(doc => {
        const data = doc.data();
        const otherUserId = data.users[0] === profileUser.uid ? data.users[1] : data.users[0];
        if (data.status === 'accepted') {
          friendIds.push(otherUserId);
        } else if (data.status === 'pending' && data.requestedBy !== profileUser.uid) {
          requestUserIds.push(otherUserId);
        }
      });

      if (friendIds.length > 0) {
        const friendsQuery = query(collection(firestore, 'usuarios'), where('__name__', 'in', friendIds));
        const friendsSnapshot = await getDocs(friendsQuery);
        const friendsData = friendsSnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as User));
        setFriends(friendsData);
      } else {
        setFriends([]);
      }

      if (requestUserIds.length > 0) {
        const requestsQuery = query(collection(firestore, 'usuarios'), where('__name__', 'in', requestUserIds));
        const requestsSnapshot = await getDocs(requestsQuery);
        const requestsData = requestsSnapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as User));
        setFriendRequests(requestsData);
      } else {
        setFriendRequests([]);
      }
    };
    
    const checkFriendshipStatus = async () => {
      if (!loggedInUser || loggedInUser.uid === profileUser.uid) {
        setFriendshipStatus('not_friends');
        return;
      }
      setFriendshipStatus('loading');
      const q = query(collection(firestore, 'friendships'), where('users', 'in', [[loggedInUser.uid, profileUser.uid], [profileUser.uid, loggedInUser.uid]]));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const doc = snapshot.docs[0];
        setFriendshipDocId(doc.id);
        if (doc.data().status === 'accepted') {
          setFriendshipStatus('friends');
        } else if (doc.data().requestedBy === loggedInUser.uid) {
          setFriendshipStatus('pending_sent');
        } else {
          setFriendshipStatus('pending_received');
        }
      } else {
        setFriendshipStatus('not_friends');
      }
    };

    fetchFriendsAndRequests();
    checkFriendshipStatus();
  }, [profileUser, loggedInUser]);

  const calculateAge = (nacimiento: any) => {
    if (!nacimiento) return 'N/A';
    let birthDate: Date;
    if (nacimiento.seconds) {
      birthDate = new Date(nacimiento.seconds * 1000);
    } else if (typeof nacimiento === 'string') {
      birthDate = new Date(nacimiento.replace(/-/g, '/'));
    } else {
      return 'N/A';
    }
    if (isNaN(birthDate.getTime())) return 'N/A';

    const today = new Date();
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    if (months < 0 || (months === 0 && today.getDate() < birthDate.getDate())) {
        years--;
        months = (months + 12) % 12;
    }
    if (years > 0) return `${years} año${years > 1 ? 's' : ''}`;
    if (months > 0) return `${months} mes${months > 1 ? 'es' : ''}`;
    const days = Math.floor((today.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24));
    if (days > 0) return `${days} día${days > 1 ? 's' : ''}`;
    return 'Recién nacido';
  };
  
  const getColorForAnimal = (animal: string) => {
    switch (animal?.toLowerCase()) {
      case 'perro':
        return '#3880ff'; // Azul
      case 'gato':
        return '#f59e0b'; // Naranja
      case 'pájaro':
        return '#ffc409'; // Amarillo
      case 'conejo':
        return '#92949c'; // Gris
      default:
        return '#F59E0B'; // Color por defecto
    }
  };

  const addFriend = async () => {
    if (!loggedInUser || !profileUser) return;
    try {
      const newDocRef = await addDoc(collection(firestore, 'friendships'), {
        users: [loggedInUser.uid, profileUser.uid],
        status: 'pending',
        requestedBy: loggedInUser.uid,
        createdAt: serverTimestamp(),
      });
      setFriendshipDocId(newDocRef.id);
      setFriendshipStatus('pending_sent');
    } catch (error) { console.error("Error sending request:", error); }
  };

  const acceptFriendRequest = async (requesterId: string) => {
    if (!loggedInUser) return;
    const q = query(collection(firestore, 'friendships'), where('users', 'in', [[loggedInUser.uid, requesterId], [requesterId, loggedInUser.uid]]));
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
        const docId = snapshot.docs[0].id;
        await updateDoc(doc(firestore, 'friendships', docId), { status: 'accepted' });
        setFriendRequests(prev => prev.filter(user => user.uid !== requesterId));
        const newFriend = friendRequests.find(user => user.uid === requesterId);
        if (newFriend) setFriends(prev => [...prev, newFriend]);
    }
  };

  const rejectFriendRequest = async (requesterId: string) => {
    if (!loggedInUser) return;
    const q = query(collection(firestore, 'friendships'), where('users', 'in', [[loggedInUser.uid, requesterId], [requesterId, loggedInUser.uid]]));
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
        const docId = snapshot.docs[0].id;
        await deleteDoc(doc(firestore, 'friendships', docId));
        setFriendRequests(prev => prev.filter(user => user.uid !== requesterId));
    }
  };

  const removeFriend = async () => {
    if (!friendshipDocId) return;
    try {
      await deleteDoc(doc(firestore, 'friendships', friendshipDocId));
      setFriendshipStatus('not_friends');
      setFriendshipDocId(null);
    } catch (error) { console.error("Error removing friend:", error); }
  };

  const formatFechaRegistro = (fecha: any) => {
    if (!fecha || !fecha.seconds) return '';
    const date = new Date(fecha.seconds * 1000);
    const meses = Math.floor((new Date().getTime() - date.getTime()) / (1000 * 60 * 60 * 24 * 30));
    return meses < 1 ? 'Este mes' : meses < 12 ? `Hace ${meses} meses` : `Hace ${Math.floor(meses / 12)} año(s)`;
  };

  const handleLogout = () => {
    setShowProfileModal(false);
    logout();
    //history.push('/login');
  };

  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => { /* Logic to be implemented */ };
  const isOwnProfile = loggedInUser?.uid === profileUser?.uid;

  if (isLoading || !profileUser) {
    return <IonPage><IonContent className="ion-text-center"><IonSpinner name="crescent" /></IonContent></IonPage>;
  }

  const renderFriendshipButtons = () => {
    if (isOwnProfile) return null;

    let friendshipButton = null;

    switch (friendshipStatus) {
      case 'friends':
        friendshipButton = (
          <IonButton expand="block" className="add-friend-btn" fill="outline" color="danger" onClick={removeFriend}>
            <IonIcon icon={closeCircleOutline} slot="start" /> Eliminar Amigo
          </IonButton>
        );
        break; 
      case 'pending_sent':
        friendshipButton = <IonButton expand="block" className="add-friend-btn" fill="outline" disabled><IonIcon icon={sendOutline} slot="start" /> Solicitud Enviada</IonButton>;
        break;
      case 'pending_received':
        friendshipButton = (
          <>
            <IonButton expand="block" className="accept-btn" onClick={() => acceptFriendRequest(profileUser.uid)}><IonIcon icon={checkmarkCircleOutline} slot="start" /> Aceptar Solicitud</IonButton>
            <IonButton expand="block" className="add-friend-btn" fill="outline" color="danger" onClick={() => rejectFriendRequest(profileUser.uid)}><IonIcon icon={closeCircleOutline} slot="start" /> Rechazar</IonButton>
          </>
        );
        break;
      case 'not_friends':
        friendshipButton = <IonButton expand="block" className="add-friend-btn" fill="outline" onClick={addFriend}><IonIcon icon={personAddOutline} slot="start" /> Agregar Amigo</IonButton>;
        break;
      case 'loading':
        friendshipButton = <IonSpinner name="dots" />;
        break;
    }

    return (
        <>
            <IonButton expand="block" className="message-btn" onClick={() => history.push(`/chat/${profileUser.uid}`)}>
                <IonIcon icon={sendOutline} slot="start" /> Enviar Mensaje
            </IonButton>
            {friendshipButton}
        </>
    );
  }

  return (
    <IonPage>
      {/* Header Mobile-First */}
      <IonHeader className="ion-no-border">
        <IonToolbar className="header-toolbar">
          <div className="header-mobile">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9" 
              alt="MyPet" 
              className="logo-mobile"
            />
            <div className="header-actions">
              <IonButton fill="clear" className="icon-btn">
                <IonIcon icon={notifications} />
                <IonBadge className="badge-notification">3</IonBadge>
              </IonButton>
              <IonAvatar className="avatar-small" onClick={() => setShowProfileModal(true)}>
                <img src={user?.fotouser || 'https://via.placeholder.com/150'} alt="Perfil" />
              </IonAvatar>
            </div>
          </div>
        </IonToolbar>
      </IonHeader>
      <IonContent className="perfil-content">
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user} googleMapsApiKey={API_KEY}/>}
        <DatosModal isOpen={isDatosModalOpen} onClose={() => setDatosModalOpen(false)} />
        
        <div className="perfil-hero">
          <div 
            className="hero-background-image"
            style={{ backgroundImage: `url(${profileUser.portada})` }}
          >
            <div className="hero-overlay"></div>
            {isOwnProfile && (
              <button 
                className="change-cover-btn"
                onClick={() => coverInputRef.current?.click()}
              >
                <IonIcon icon={imageOutline} />
                <span>Cambiar portada</span>
              </button>
            )}
            <input ref={coverInputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleCoverImageChange} />
          </div>

          <div className="perfil-info-container">
            <div className="avatar-section">
              <div className="avatar-wrapper">
                <IonAvatar className="perfil-avatar">
                  <img src={profileUser.fotouser} alt={profileUser.name} />
                </IonAvatar>
              </div>
            </div>

            <div className="user-info">
              <h1 className="user-name">{profileUser.name}</h1>
              <p className="user-bio">{profileUser.descripcion}</p>
              
              <div className="user-meta">
                <div className="meta-item">
                  <IonIcon icon={calendarOutline} />
                  <span>Miembro desde {formatFechaRegistro(profileUser.fechainicio)}</span>
                </div>
                {profileUser.ciudad && (
                  <div className="meta-item">
                    <IonIcon icon={locationOutline} />
                    <span>{profileUser.ciudad}</span>
                  </div>
                )}
              </div>

              <div className="profile-action-buttons">
                {renderFriendshipButtons()}
              </div>
            </div>
          </div>
        </div>

        <div className="stats-section">
          <div className="stat-card">
            <div className="stat-icon-wrapper temas"><IonIcon icon={chatbubbleEllipsesOutline} /></div>
            <div className="stat-info"><div className="stat-number">{stats.temas}</div><div className="stat-label">Temas</div></div>
          </div>
          <div className="stat-card">
            <div className="stat-icon-wrapper comentarios"><IonIcon icon={pawOutline} /></div>
            <div className="stat-info"><div className="stat-number">{stats.comentarios}</div><div className="stat-label">Comentarios</div></div>
          </div>
          <div className="stat-card">
            <div className="stat-icon-wrapper likes"><IonIcon icon={heartOutline} /></div>
            <div className="stat-info"><div className="stat-number">{stats.gustas}</div><div className="stat-label">Me Gusta</div></div>
          </div>
        </div>

        <div className="segment-container-perfil">
          <IonSegment value={segmentValue} onIonChange={(e) => setSegmentValue(String(e.detail.value))} className="perfil-segment" mode="ios">
            <IonSegmentButton value="perfil"><IonLabel>Mi Familia ({pets.length})</IonLabel></IonSegmentButton>
            <IonSegmentButton value="amigos"><IonLabel>Amigos ({friends.length})</IonLabel></IonSegmentButton>
          </IonSegment>
        </div>

        {segmentValue === 'perfil' && (
          <div className="mascotas-section">
            <div className="section-header-mascotas">
              <h2 className="section-title-mascotas"><IonIcon icon={pawOutline} /> Mis Mascotas</h2>
            </div>
            <div className="mascotas-grid">
              {pets.map(mascota => (
                <div key={mascota.id} className="mascota-card">
                  <div className="mascota-image-wrapper">
                    <img src={mascota.foto} alt={mascota.nombre} className="mascota-image" />
                    <div className="mascota-overlay" style={{ background: `linear-gradient(to top, ${getColorForAnimal(mascota.animal)}dd, transparent)` }}>
                      <div className="mascota-name">{mascota.nombre}</div>
                    </div>
                  </div>
                  <div className="mascota-info">
                    <div className="mascota-detail"><span className="detail-label">Raza</span><span className="detail-value">{mascota.raza}</span></div>
                    <div className="mascota-detail"><span className="detail-label">Edad</span><span className="detail-value">{calculateAge(mascota.nacimiento)}</span></div>
                    <IonChip className="tipo-chip" style={{ '--background': getColorForAnimal(mascota.animal) }}>{mascota.animal}</IonChip>
                  </div>
                </div>
              ))}
              {pets.length === 0 && <div className="ion-padding ion-text-center">Este usuario aún no ha añadido ninguna mascota.</div>}
            </div>
          </div>
        )}

        {segmentValue === 'amigos' && (
          <div className="amigos-section">
            {isOwnProfile && friendRequests.length > 0 && (
              <div className="solicitudes-section">
                <div className="section-header-amigos"><h2 className="section-title-amigos"><IonIcon icon={personAddOutline} /> Solicitudes de Amistad ({friendRequests.length})</h2></div>
                <div className="amigos-list">
                  {friendRequests.map(solicitud => (
                    <div key={solicitud.uid} className="amigo-card">
                      <IonAvatar className="amigo-avatar" onClick={() => history.push(`/perfil/${solicitud.uid}`)}><img src={solicitud.fotouser} alt={solicitud.name} /></IonAvatar>
                      <div className="amigo-info" onClick={() => history.push(`/perfil/${solicitud.uid}`)}>
                        <h3 className="amigo-nombre">{solicitud.name}</h3>
                        <div className="amigo-meta"><span className="amigo-ubicacion"><IonIcon icon={locationOutline}/> {solicitud.direccion || 'Ubicación no disponible'}</span></div>
                      </div>
                      <div className="solicitud-actions">
                        <IonButton size="small" className="accept-btn" onClick={() => acceptFriendRequest(solicitud.uid)}><IonIcon icon={checkmarkCircleOutline}/></IonButton>
                        <IonButton size="small" fill="outline" color="danger" onClick={() => rejectFriendRequest(solicitud.uid)}><IonIcon icon={closeCircleOutline}/></IonButton>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="section-header-amigos"><h2 className="section-title-amigos"><IonIcon icon={person} /> Amigos ({friends.length})</h2></div>
            <div className="amigos-list">
              {friends.length > 0 ? friends.map(amigo => (
                <div key={amigo.uid} className="amigo-card" onClick={() => history.push(`/perfil/${amigo.uid}`)}>
                  <IonAvatar className="amigo-avatar"><img src={amigo.fotouser} alt={amigo.name} /></IonAvatar>
                  <div className="amigo-info">
                    <h3 className="amigo-nombre">{amigo.name}</h3>
                    <div className="amigo-meta"><span className="amigo-ubicacion"><IonIcon icon={locationOutline}/> {amigo.direccion || 'Ubicación no disponible'}</span></div>
                  </div>
                  <IonButton fill="clear" className="message-amigo-btn" onClick={(e) => { e.stopPropagation(); history.push(`/chat/${amigo.uid}`); }}><IonIcon icon={chatbubbleEllipsesOutline} /></IonButton>
                </div>
              )) : <div className="ion-padding ion-text-center">No tienes amigos para mostrar.</div>}
            </div>
          </div>
        )}
      </IonContent>
      {/* Modal de Perfil */}
      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mi Perfil</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/conversations'); }}>
                <IonIcon icon={chatbubbles} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => setDatosModalOpen(true)}>
                <IonIcon icon={documentText} />
                <span>Datos</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/puntos'); }}>
                <IonIcon icon={trophy} />
                <span>Mis Puntos</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline" onClick={handleLogout}>
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

export default Perfil;
