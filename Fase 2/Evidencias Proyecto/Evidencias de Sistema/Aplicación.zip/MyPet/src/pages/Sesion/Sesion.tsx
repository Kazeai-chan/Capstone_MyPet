
import React, { useContext, useEffect, useState } from 'react'; // 1. Importar useState
import { IonContent, IonPage,  IonButton, IonIcon } from '@ionic/react';
import { useLocation, useHistory } from 'react-router-dom';
import { UserContext, UserContextType } from '../../context/UserContext';
import './Sesion.css';
import { pawOutline, heartOutline, shieldCheckmarkOutline, logoGoogle } from 'ionicons/icons';

const Sesion: React.FC = () => {
  const { user, loginWithGoogle } = useContext<UserContextType>(UserContext);
  const location = useLocation();
  const history = useHistory();
  const [isRedirecting, setIsRedirecting] = useState(false); // 2. Añadir estado de "cerrojo"

  useEffect(() => {
    // Solo actuar si hay un usuario Y si no hemos iniciado ya una redirección
    if (user && !isRedirecting) {
      // 3. "Cerrar el cerrojo" para prevenir ejecuciones futuras
      setIsRedirecting(true); 

      const redirectUrl = sessionStorage.getItem('redirectUrl');
      if (redirectUrl) {
        sessionStorage.removeItem('redirectUrl');
      }
      
      const finalRedirectUrl = redirectUrl || new URLSearchParams(location.search).get('redirect');

      // Redirigir a la URL final. Esta es ahora la única vez que esta línea se ejecutará.
      history.replace(finalRedirectUrl || '/app/home');
    }
  }, [user, history, location.search, isRedirecting]); // 4. Añadir isRedirecting a las dependencias

  const handleGoogleLogin = async () => {
    try {
      const params = new URLSearchParams(location.search);
      const redirectUrl = params.get('redirect');
      if (redirectUrl) {
        sessionStorage.setItem('redirectUrl', redirectUrl);
      }
      await loginWithGoogle();
    } catch (err) {
      console.error('Error en login:', err);
    }
  };

  return (
    <IonPage>
      <IonContent className="login-content">
        {/* ... (el resto del JSX no cambia) ... */}
        <div className="login-hero">
          <div className="logo-container">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
              alt="MyPet Logo"
              className="logo-main"
            />
          </div>
          
          <h1 className="welcome-title">¡Bienvenido!</h1>
          <p className="welcome-subtitle">Tu comunidad de mascotas te espera</p>
        </div>
        <div className="image-section">
          <div className="image-container">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/aplicaciones_mascotas.jpeg?alt=media&token=38e6403e-b97f-4c48-9a9a-d79dcc82440d"
              alt="Mascota con smartphone"
              className="hero-image"
            />
            <div className="image-overlay"></div>
          </div>
        </div>
        <div className="features-section">
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={pawOutline} />
            </div>
            <span>Reporta mascotas perdidas</span>
          </div>
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={heartOutline} />
            </div>
            <span>Conecta con la comunidad</span>
          </div>
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={shieldCheckmarkOutline} />
            </div>
            <span>Datos seguros y privados</span>
          </div>
        </div>
        <div className="login-section">
          <div className="login-card">
            <h3>Inicia sesión para continuar</h3>
            <p>Usa tu cuenta de Google para acceder de forma rápida y segura</p>
            <IonButton 
              expand="block" 
              className="google-login-btn"
              onClick={handleGoogleLogin}
            >
              <IonIcon icon={logoGoogle} slot="start" />
              Continuar con Google
            </IonButton>
            <div className="terms-text">
              Al continuar, aceptas nuestros términos y condiciones
            </div>
          </div>
        </div>
        <div className="decorative-paw paw-1">🐾</div>
        <div className="decorative-paw paw-2">🐾</div>
        <div className="decorative-paw paw-3">🐾</div>
      </IonContent>
    </IonPage>
  );
};

export default Sesion;
