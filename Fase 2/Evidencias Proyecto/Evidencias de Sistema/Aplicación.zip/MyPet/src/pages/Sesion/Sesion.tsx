import React, { useContext } from 'react';
import { IonContent, IonPage,  IonButton, IonIcon } from '@ionic/react';
import { UserContext, UserContextType } from '../../context/UserContext';
import './Sesion.css';
import { pawOutline, heartOutline, shieldCheckmarkOutline, logoGoogle } from 'ionicons/icons';

const Sesion: React.FC = () => {
  const { loginWithGoogle } = useContext<UserContextType>(UserContext);

  const handleGoogleLogin = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error('Error en login:', err);
    }
  };

  return (
    <IonPage>
      <IonContent className="login-content">
        {/* Hero Section */}
        <div className="login-hero">
          <div className="logo-container">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
              alt="MyPet Logo"
              className="logo-main"
            />
          </div>
          
          <h1 className="welcome-title">¡Bienvenido!</h1>
          <p className="welcome-subtitle">Tu comunidad de mascotas te espera</p>
        </div>

        {/* Image Section */}
        <div className="image-section">
          <div className="image-container">
            <img 
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/aplicaciones_mascotas.jpeg?alt=media&token=38e6403e-b97f-4c48-9a9a-d79dcc82440d"
              alt="Mascota con smartphone"
              className="hero-image"
            />
            <div className="image-overlay"></div>
          </div>
        </div>

        {/* Features Cards */}
        <div className="features-section">
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={pawOutline} />
            </div>
            <span>Reporta mascotas perdidas</span>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={heartOutline} />
            </div>
            <span>Conecta con la comunidad</span>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon">
              <IonIcon icon={shieldCheckmarkOutline} />
            </div>
            <span>Datos seguros y privados</span>
          </div>
        </div>

        {/* Login Section */}
        <div className="login-section">
          <div className="login-card">
            <h3>Inicia sesión para continuar</h3>
            <p>Usa tu cuenta de Google para acceder de forma rápida y segura</p>
            
            <IonButton 
              expand="block" 
              className="google-login-btn"
              onClick={handleGoogleLogin}
            >
              <IonIcon icon={logoGoogle} slot="start" />
              Continuar con Google
            </IonButton>

            <div className="terms-text">
              Al continuar, aceptas nuestros términos y condiciones
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="decorative-paw paw-1">🐾</div>
        <div className="decorative-paw paw-2">🐾</div>
        <div className="decorative-paw paw-3">🐾</div>
      </IonContent>
    </IonPage>
  );
};

export default Sesion;
