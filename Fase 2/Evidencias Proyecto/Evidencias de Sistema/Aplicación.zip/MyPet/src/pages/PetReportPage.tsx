
// src/pages/PetReportPage.tsx

import React, { useState, useEffect, useContext, useCallback } from 'react';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton,
  IonCard, IonCardContent, IonSpinner,
  IonIcon, IonLabel, IonItem, IonBadge, IonText, useIonAlert, IonButton, IonTextarea, IonAvatar,
  IonChip,
  IonModal
} from '@ionic/react';
import { useParams, useHistory } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, addDoc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { firestore } from '../firebase';
import { UserContext } from '../context/UserContext';

// --- Iconos ---
import { 
  locationOutline, calendarOutline, pawOutline, sparkles, colorPaletteOutline, 
  resizeOutline, bodyOutline, eyeOutline, informationCircleOutline, checkmarkCircleOutline, 
  chatbubblesOutline, sendOutline, 
  shareOutline,
  alertCircleOutline,
  heartOutline,
  personOutline,
  timeOutline,
  closeCircle
} from 'ionicons/icons';

// --- Componentes ---
import AportarDato from '../components/AportarDato';

// --- CSS ---
import './PetReportPage.css';

// --- Interfaces ---
interface ReportData {
  id: string;
  iduser: string;
  nombre: string;
  foto: string;
  descripcion: string;
  direccion: string;
  fecha: string;
  tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
  animal: string;
  raza: string;
  tamano: string;
  color: string;
  pelaje: string;
  colorOjos: string;
}

interface SimilarPetResult extends ReportData {
    similarity: number;
}

interface Comentario {
    id: string;
    idmarker: string;
    iduser: string;
    nombre: string;
    cuerpo: string;
    c_fecha: any;
    avatar: string;
}

interface ReportOwner {
    name: string;
    uid: string;
    fotouser:string;
}

const formatTimeAgo = (date: Date): string => {
  let d = date
  if (!(d instanceof Date) || isNaN(d.getTime())) { return 'hace un momento'; }
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  
  if (diffMins < 1) return 'Ahora';
  if (diffMins < 60) return `Hace ${diffMins}m`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `Hace ${diffHours}h`;
  const diffDays = Math.floor(diffHours / 24);
  return `Hace ${diffDays}d`;
};

const PetReportPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const history = useHistory();
  const { user } = useContext(UserContext);
  const [presentAlert] = useIonAlert();

  // --- Estados del Reporte ---
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [owner, setOwner] = useState<ReportOwner | null>(null);

  // --- Estados de Mascotas Similares ---
  const [similarPets, setSimilarPets] = useState<SimilarPetResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // --- Estados de Comentarios y Acciones (traídos de VerMarcador) ---
  const [comentarios, setComentarios] = useState<Comentario[]>([]);
  const [nuevoComentario, setNuevoComentario] = useState('');
  const [isAportarDatoModalOpen, setIsAportarDatoModalOpen] = useState(false);
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false); 

  // --- Carga de datos principales y comentarios ---
  useEffect(() => {
    const fetchAllData = async () => {
      if (!id) return;

      try {
        setLoading(true);
        setError(null);
        setOwner(null);
        setComentarios([]);

        // 1. Cargar el reporte
        const docRef = doc(firestore, 'marcadores', id);
        const docSnap = await getDoc(docRef);

        if (!docSnap.exists()) {
          throw new Error('El reporte no fue encontrado.');
        }
        
        const reportData = { id, ...docSnap.data() } as ReportData;
        setReport(reportData);

        // 2. Cargar datos del dueño
        if (reportData.iduser) {
          const userDocRef = doc(firestore, 'usuarios', reportData.iduser);
          const userDocSnap = await getDoc(userDocRef);
          if (userDocSnap.exists()) {
            setOwner({ uid: reportData.iduser, name: userDocSnap.data().name, fotouser: userDocSnap.data().fotouser });
          }
        }

        // 3. Cargar comentarios
        const comentariosQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', id));
        const querySnapshot = await getDocs(comentariosQuery);
        let comentariosData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comentario));
        comentariosData.sort((a, b) => (b.c_fecha?.toDate?.() || 0) - (a.c_fecha?.toDate?.() || 0));
        setComentarios(comentariosData);

      } catch (err: any) {
        setError('Ocurrió un error al cargar el reporte: ' + err.message);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, [id]);

  // --- Carga de mascotas similares ---
  useEffect(() => {
    if (!report || !id) return;

    const findSimilar = async () => {
      setIsSearching(true);
      setSearchError(null);
      try {
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        const functions = getFunctions();
        const findSimilarPets = httpsCallable(functions, 'findSimilarPets');
        const result = await findSimilarPets({ reportId: id });
        const data = result.data as { similarPets: SimilarPetResult[] };
        
        setSimilarPets(data.similarPets || []);

      } catch (err: any) {
        if (!err.message.includes('embedding aún no está listo')) {
           setSearchError('No se pudieron cargar las coincidencias. ' + err.message);
        }
        console.error(err);
      } finally {
        setIsSearching(false);
      }
    };

    findSimilar();
  }, [report, id]);

  // --- Funciones de Acciones y Comentarios (traídas y adaptadas de VerMarcador) ---
  const handlePostComentario = useCallback(async () => {
    if (!user) return presentAlert({ header: 'Error', message: 'Debes iniciar sesión para comentar.', buttons: ['OK'] });
    if (!report) return;
    if (nuevoComentario.trim() === '') return;

    try {
      const newComment = {
        idmarker: report.id,
        iduser: user.uid,
        nombre: user.name,
        cuerpo: nuevoComentario,
        c_fecha: serverTimestamp(),
        avatar: user.fotouser
      };
      
      const docRef = await addDoc(collection(firestore, 'comen-marcador'), newComment);
      
      setComentarios(prev => [{ ...newComment, id: docRef.id, c_fecha: new Date() }, ...prev]);
      setNuevoComentario('');
    } catch (error) {
        presentAlert({ header: 'Error', message: 'No se pudo publicar tu comentario.', buttons: ['OK'] });
    }
  }, [user, report, nuevoComentario, presentAlert]);

  const contactOwner = useCallback((header: string, message: string) => {
      if (!user || !owner || !report) return;
      if (user.uid === owner.uid) return presentAlert({ header: 'Aviso', message: 'Este es tu propio reporte.', buttons: ['OK'] });

      presentAlert({
          header,
          message,
          buttons: [
              { text: 'No', role: 'cancel' },
              { text: 'Sí, avisar', handler: () => {
                  addDoc(collection(firestore, 'mensajes'), { 
                      de: user.uid, 
                      para: owner.uid, 
                      fecha: serverTimestamp(), 
                      mensaje: `${user.name} ${message}`,
                      idReporte: report.id 
                  })
                  .then(() => presentAlert({ header: 'Aviso Enviado', message: `Mensaje enviado a ${owner.name}.`, buttons: ['OK'] }))
                  .catch(() => presentAlert({ header: 'Error', message: 'No se pudo enviar el aviso.', buttons: ['OK'] }));
              }}
          ]
      });
  }, [user, owner, report, presentAlert]);

  const handleMascotaEncontrada = () => contactOwner(
    '¿Confirmar hallazgo?',
    `ha encontrado a ${report?.nombre || 'la mascota que reportaste'}.`
  );

  const handleEsMiMascota = () => contactOwner(
    '¿Confirmar propiedad?',
    `dice que la mascota que encontraste (${report?.nombre || 'sin nombre'}) le pertenece.`
  );

  const handleAportarDatoClose = (submitted: boolean) => {
    setIsAportarDatoModalOpen(false);
    if (submitted) {
      presentAlert({
        header: '¡Gracias!',
        message: 'Dato enviado. Gracias por ayudar a la comunidad, ¡has ganado 1 PetPunto!',
        buttons: ['OK'],
      });
    }
  };

  const handleCerrarReporte = () => {
      if (!report) return;
      presentAlert({ header: 'Confirmar Cierre', message: '¿Seguro que deseas cerrar este reporte?', buttons: [
        { text: 'Cancelar', role: 'cancel' },
        { text: 'Sí, cerrar', handler: () => {
            const markerRef = doc(firestore, 'marcadores', report.id);
            const commentsQuery = query(collection(firestore, 'comen-marcador'), where('idmarker', '==', report.id));
            getDocs(commentsQuery).then(commentsSnapshot => {
                const batch = writeBatch(firestore);
                commentsSnapshot.forEach(commentDoc => batch.delete(commentDoc.ref));
                batch.delete(markerRef);
                return batch.commit();
            }).then(() => {
                presentAlert({ header: 'Reporte Cerrado', message: 'El reporte ha sido eliminado.', buttons: ['OK'] });
                history.push('/app/buscar', { refresh: true }); // <--- LÍNEA MODIFICADA
            }).catch(() => presentAlert({ header: 'Error', message: 'No se pudo cerrar el reporte.', buttons: ['OK'] }));
        }}
      ]});
  };

  const goToProfile = (userId?: string) => {
    if (userId) history.push(`/app/perfil/${userId}`);
  };


  const renderDetailItem = (icon: string, label: string, value: string | undefined) => (
    <IonItem lines="none" className="detail-item">
      <IonIcon icon={icon} slot="start" color="medium" />
      <IonLabel>
        <h2>{label}</h2>
        <p>{value || 'No especificado'}</p>
      </IonLabel>
    </IonItem>
  );

  // --- RENDERIZADO ---
  if (loading) {
    return (
      <IonPage>
        <IonContent fullscreen>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <IonSpinner name="crescent" />
          </div>
        </IonContent>
      </IonPage>
    );
  }  

  if (error) {
    return (
      <IonPage>
        <IonHeader><IonToolbar><IonButtons slot="start"><IonBackButton defaultHref="/app/buscar" /></IonButtons><IonTitle>Error</IonTitle></IonToolbar></IonHeader>
        <IonContent fullscreen className="ion-padding ion-text-center"><IonText color="danger"><h3>{error}</h3></IonText></IonContent>
      </IonPage>
    );
  }

  const isPerdida = report?.tipo_r === 'Mascota Perdida';
  const isEncontrada = report?.tipo_r === 'Mascota Encontrada';
  const isOwner = user?.uid === report?.iduser;

  return (
    <IonPage className="pet-report-page-mypet">
      <IonHeader className="ion-no-border">
        <IonToolbar className="report-header-toolbar">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/app/buscar" text="" className="back-btn-report" />
          </IonButtons>
          <IonTitle className="report-title-header">Detalle del Reporte</IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear">
              <IonIcon icon={shareOutline} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="report-content-mypet">
        {report && (
          <>
            {/* Hero Image con Status Badge */}
            <div className="report-hero-section">
              <div 
                className="hero-bg-image" 
                style={{ backgroundImage: `url(${report.foto})` }}
              >
                <div className="hero-overlay-gradient"></div>
              </div>
              
              <IonBadge 
                className={`status-badge-mypet ${isPerdida ? 'perdida' : 'encontrada'}`}
              >
                <IonIcon icon={isPerdida ? alertCircleOutline : checkmarkCircleOutline} />
                <span>{report.tipo_r}</span>
              </IonBadge>
            </div>

            {/* Main Content Card */}
            <div className="report-main-container">
              {/* Pet Info Card */}
              <IonCard className="pet-info-card-mypet">
                <IonCardContent>
                  {/* Avatar y Nombre */}
                  <div className="pet-header-mypet">
                    <div className="pet-avatar-container-mypet" onClick={() => setIsAvatarModalOpen(true)}>
                      <IonAvatar className="pet-main-avatar">
                        <img src={report.foto} alt={report.nombre} />
                      </IonAvatar>
                      <div className="paw-decoration-report">🐾</div>
                    </div>
                    
                    <div className="pet-title-section">
                      <h1 className="pet-name-report">
                        {isPerdida ? report.nombre : 'Mascota Encontrada'}
                      </h1>
                      <IonChip className="breed-chip-report">
                        <IonIcon icon={pawOutline} />
                        <span>{report.animal} · {report.raza}</span>
                      </IonChip>
                    </div>
                  </div>

                  {/* Descripción */}
                  <div className="description-section-mypet">
                    <h3 className="section-subtitle">
                      <IonIcon icon={informationCircleOutline} />
                      Descripción
                    </h3>
                    <p className="description-text">{report.descripcion}</p>
                  </div>

                  {/* Detalles Grid */}
                  <div className="details-grid-mypet">
                    {renderDetailItem(locationOutline, 'Ubicación', report.direccion)}
                    {renderDetailItem(calendarOutline, 'Fecha', report.fecha)}
                    {renderDetailItem(resizeOutline, 'Tamaño', report.tamano)}
                    {renderDetailItem(colorPaletteOutline, 'Color', report.color)}
                    {renderDetailItem(bodyOutline, 'Pelaje', report.pelaje)}
                    {renderDetailItem(eyeOutline, 'Color de Ojos', report.colorOjos)}
                  </div>

                  {/* Owner Info */}
                  <div className="owner-info-section-mypet" onClick={() => goToProfile(owner?.uid)}>
                    <h3 className="section-subtitle">
                      <IonIcon icon={personOutline} />
                      Reportado por
                    </h3>
                    <div className="owner-card-report">
                      <IonAvatar className="owner-avatar-report">
                        <img src={owner?.fotouser || 'https://via.placeholder.com/150'} alt={owner?.name} />
                      </IonAvatar>
                      <div className="owner-details">
                        <strong>{owner?.name}</strong>
                        <span>Ver perfil</span>
                      </div>
                      <IonChip className="verified-chip-report">
                        <span>✓</span>
                      </IonChip>
                    </div>
                  </div>
                </IonCardContent>
              </IonCard>

              {/* Action Buttons */}
              {!isOwner && (
                <div className="action-buttons-mypet">
                  {isPerdida && (
                    <>
                      <IonButton 
                        expand="block" 
                        fill="outline"
                        className="action-btn-secondary-mypet"
                        onClick={() => setIsAportarDatoModalOpen(true)}
                      >
                        <IonIcon icon={informationCircleOutline} slot="start" />
                        Aportar Dato
                      </IonButton>
                      <IonButton 
                        expand="block" 
                        className="action-btn-primary-mypet"
                        onClick={handleMascotaEncontrada}
                      >
                        <IonIcon icon={checkmarkCircleOutline} slot="start" />
                        La Encontré
                      </IonButton>
                    </>
                  )}
                  {isEncontrada && (
                    <>
                      <IonButton 
                        expand="block" 
                        fill="outline"
                        className="action-btn-secondary-mypet"
                        onClick={() => setIsAportarDatoModalOpen(true)}
                      >
                        <IonIcon icon={informationCircleOutline} slot="start" />
                        Aportar Dato
                      </IonButton>
                      <IonButton 
                        expand="block" 
                        className="action-btn-success-mypet"
                        onClick={handleEsMiMascota}
                      >
                        <IonIcon icon={heartOutline} slot="start" />
                        Es Mi Mascota
                      </IonButton>
                    </>
                  )}
                </div>
              )}

              {/* Divider con patita */}
              <div className="section-divider-report">
                <div className="divider-line-report"></div>
                <div className="divider-icon-report">🐾</div>
                <div className="divider-line-report"></div>
              </div>

              {/* Similar Pets Section */}
              <div className="similar-pets-section-mypet">
                <h2 className="section-title-mypet">
                  <IonIcon icon={sparkles} />
                  <span>Posibles Coincidencias</span>
                  <IonBadge className="count-badge">{similarPets.length}</IonBadge>
                </h2>
                {searchError && <IonText color="danger" className="ion-padding">{searchError}</IonText>}
                {!isSearching && similarPets.length === 0 && !searchError && (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '24px 0' }}>
                    <IonText><p className="ion-text-center ion-padding-horizontal">No se encontraron reportes con alta similitud visual por ahora.</p></IonText>
                  </div>
                )} 
                {isSearching ? (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '24px 0' }}>
                    <IonSpinner name="crescent" />
                    <p style={{ marginTop: '12px', color: 'var(--mypet-text-light)', fontWeight: 600 }}>Buscando coincidencias...</p>
                  </div>
                ) : (
                  <div className="similar-pets-scroll-mypet">
                    {similarPets.map(pet => (
                      <div key={pet.id} className="similar-pet-card-mypet" onClick={() => history.push(`/app/reporte/${pet.id}`)}>
                        <div 
                          className="similar-pet-image-wrapper"
                          style={{ backgroundImage: `url(${pet.foto})` }}
                        >
                          <div className="similarity-badge-mypet">
                            <IonIcon icon={sparkles} />
                            <span>{Math.round(pet.similarity * 100)}%</span>
                          </div>
                          <div className="similar-pet-overlay-mypet">
                            <IonBadge 
                              className={`type-badge ${pet.tipo_r === 'Mascota Perdida' ? 'perdida' : 'encontrada'}`}
                            >
                              {pet.tipo_r === 'Mascota Perdida' ? 'Perdida' : 'Encontrada'}
                            </IonBadge>
                            <div className="similar-pet-info-mypet">
                              <h4>{pet.tipo_r === 'Mascota Perdida' ? pet.nombre : 'Encontrado'}</h4>
                              <p>
                                <IonIcon icon={pawOutline} />
                                {pet.raza}
                              </p>
                              <p>
                                <IonIcon icon={locationOutline} />
                                {pet.direccion}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Divider */}
              <div className="section-divider-report">
                <div className="divider-line-report"></div>
                <div className="divider-icon-report">💬</div>
                <div className="divider-line-report"></div>
              </div>

              {/* Comments Section */}
              <div className="comments-section-mypet">
                <h2 className="section-title-mypet">
                  <IonIcon icon={chatbubblesOutline} />
                  <span>Comentarios</span>
                  <IonBadge className="count-badge">{comentarios.length}</IonBadge>
                </h2>

                <div className="comments-list-mypet">
                  {comentarios.map(comentario => (
                    <div key={comentario.id} className="comment-card-mypet">
                      <IonAvatar className="comment-avatar-mypet" onClick={() => goToProfile(comentario.iduser)}>
                        <img src={comentario.avatar} alt={comentario.nombre} />
                      </IonAvatar>
                      <div className="comment-content-mypet">
                        <div className="comment-header-mypet">
                          <strong>{comentario.nombre}</strong>
                          <span className="comment-time">
                            <IonIcon icon={timeOutline} />
                            {formatTimeAgo(comentario.c_fecha)}
                          </span>
                        </div>
                        <p className="comment-text-mypet">{comentario.cuerpo}</p>
                      </div>
                    </div>
                  ))}

                  {comentarios.length === 0 && (
                    <div className="empty-comments-mypet">
                      <div className="empty-icon">💬</div>
                      <p>No hay comentarios todavía</p>
                      <span>¡Sé el primero en comentar!</span>
                    </div>
                  )}
                </div>

                {/* New Comment Input */}
                {user && (
                  <div className="new-comment-box-mypet">
                    <IonAvatar className="current-user-avatar-mypet">
                      <img src={user.fotouser} alt={user.name} />
                    </IonAvatar>
                    <div className="comment-input-wrapper-mypet">
                      <IonTextarea
                        placeholder="Escribe un comentario..."
                        value={nuevoComentario}
                        onIonInput={e => setNuevoComentario(e.detail.value!)}
                        className="comment-input-mypet"
                        autoGrow
                        rows={1}
                      />
                      <IonButton 
                        fill="clear" 
                        className="send-comment-btn-mypet"
                        onClick={handlePostComentario}
                        disabled={!nuevoComentario.trim()}
                      >
                        <IonIcon icon={sendOutline} />
                      </IonButton>
                    </div>
                  </div>
                )}
              </div>
              {isOwner && (
                <div className="owner-actions">
                  <IonButton expand="block" fill="outline" className="action-btn danger" color="danger" onClick={handleCerrarReporte}>Cerrar Reporte</IonButton>
                </div>
              )}
            </div>

            {/* Decorative paws */}
            <div className="report-decoration paw-1">🐾</div>
            <div className="report-decoration paw-2">🐾</div>
            <div className="report-decoration paw-3">🐾</div>
          </>
        )}
      </IonContent>

      {/* --- MODAL DE APORTAR DATO --- */}
      {report && (
        <AportarDato
            isOpen={isAportarDatoModalOpen}
            onClose={handleAportarDatoClose}
            markerId={report.id}
            markerNombre={report.nombre}
            markerFecha={report.fecha}
            ownerId={report.iduser}
        />
      )}
      {/* --- MODAL DE FOTO AMPLIADA --- */}
      <IonModal isOpen={isAvatarModalOpen} onDidDismiss={() => setIsAvatarModalOpen(false)} className="photo-modal">
        <div className="photo-modal-content">
          <IonButton fill="clear" className="close-modal-button" onClick={() => setIsAvatarModalOpen(false)}>
            <IonIcon icon={closeCircle} />
          </IonButton>
          <img src={report?.foto} alt="Foto de la mascota ampliada" />
        </div>
      </IonModal>
    </IonPage>
  );
};

export default PetReportPage;
