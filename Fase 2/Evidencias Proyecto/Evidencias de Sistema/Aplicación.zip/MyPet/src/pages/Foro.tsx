
import {
  IonAvatar,
  IonBadge,
  IonButton,
  IonChip,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonLabel,
  IonModal,
  IonPage,
  IonSearchbar,
  IonSegment,
  IonSegmentButton,
  IonToolbar,
} from '@ionic/react';
import { add, chatboxEllipsesOutline, close, flameOutline, heart, heartOutline, notifications, person, personCircleOutline, sparklesOutline, trendingUpOutline, trophy } from 'ionicons/icons';
import { useContext, useEffect, useState, useMemo } from 'react'; // Import useMemo
import { useHistory } from 'react-router-dom';

import { collection, getDocs, Timestamp } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';

import './Foro.css';
import { Tema } from '../components/Tema';
import { CreaTema } from '../components/CreaTema';
import React from 'react';
import PerfilModal from 'components/PerfilModal';
import DatosModal from 'components/DatosModal';

const API_KEY = "";

const Foro: React.FC = () => {
  const { user } = useContext<UserContextType>(UserContext);
  const [temas, setTemas] = useState<any[]>([]); // A single state for all themes
  const [showModal, setShowModal] = useState(false);
  const [selectedTema, setSelectedTema] = useState<string | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isDatosModalOpen, setDatosModalOpen] = useState(false);
  const { logout } = useContext(UserContext);
  const [segmentValue, setSegmentValue] = useState('todos');
  const [searchText, setSearchText] = useState('');

  // Fetch all themes once on component mount
  useEffect(() => {
    const fetchTemas = async () => {
      const temasCollection = collection(firestore, 'temas');
      const temasSnapshot = await getDocs(temasCollection);
      const temasData = temasSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTemas(temasData);
    };

    fetchTemas();
  }, []);

  const formatDate = (timestamp: Timestamp): string => {
    return timestamp ? new Date(timestamp.seconds * 1000).toLocaleDateString() : '';
  };

  const openModal = (idTema: string) => {
    setSelectedTema(idTema);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedTema(null);
  };

  const openCreaTema = () => {
    setShowModal(true);
  };

  const handleLogout = () => {
    setShowProfileModal(false);
    logout();
  };

  const history = useHistory();

  // Memoized filtering for performance
  const temasToShow = useMemo(() => {
    let filteredTemas = temas;

    if (segmentValue === 'mis' && user) {
      filteredTemas = temas.filter(tema => tema.iduser === user.uid);
    }

    if (searchText.trim() !== '') {
      filteredTemas = filteredTemas.filter(tema =>
        tema.titulo.toLowerCase().includes(searchText.toLowerCase())
      );
    }

    return filteredTemas;
  }, [temas, segmentValue, searchText, user]);

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="header-toolbar">
          <div className="header-mobile">
            <img
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
              alt="MyPet"
              className="logo-mobile"
            />
            <div className="header-actions">
              <IonButton fill="clear" className="icon-btn">
                <IonIcon icon={notifications} />
                <IonBadge className="badge-notification">3</IonBadge>
              </IonButton>
              <IonAvatar className="avatar-small" onClick={() => setShowProfileModal(true)}>
                <img src={user?.fotouser || 'https://via.placeholder.com/150'} alt="Perfil" />
              </IonAvatar>
            </div>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="foro-content">
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user} googleMapsApiKey={API_KEY}/>}
        <DatosModal isOpen={isDatosModalOpen} onClose={() => setDatosModalOpen(false)} />

        <div className="hero-section">
          <div className="hero-content">
            <div className="hero-text">
              <h1 className="hero-title">
                <IonIcon icon={sparklesOutline} className="hero-icon" />
                Comunidad MyPet
              </h1>
              <p className="hero-subtitle">Comparte, aprende y conecta con otros dueños</p>
            </div>
            <IonSearchbar
              value={searchText}
              onIonInput={(e) => setSearchText(e.detail.value || '')}
              placeholder="Buscar temas..."
              className="hero-searchbar"
              mode="ios"
              animated
            />
          </div>
        </div>

        <div className="segment-wrapper">
          <IonSegment
            value={segmentValue}
            onIonChange={(e) => setSegmentValue(String(e.detail.value || 'todos'))}
            className="modern-segment"
            mode="ios"
          >
            <IonSegmentButton value="todos" className="segment-btn">
              <IonLabel>
                <div className="segment-content">
                  <IonIcon icon={flameOutline} />
                  <span>Todos</span>
                </div>
              </IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="mis" className="segment-btn">
              <IonLabel>
                <div className="segment-content">
                  <IonIcon icon={personCircleOutline} />
                  <span>Mis Temas</span>
                </div>
              </IonLabel>
            </IonSegmentButton>
          </IonSegment>
        </div>

        <div className="temas-container">
          {temasToShow.map((tema, index) => (
            <div
              key={tema.id}
              className="tema-card-modern"
              onClick={() => openModal(tema.id)}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="tema-badges">
                {tema.trending && (
                  <IonChip className="badge-trending">
                    <IonIcon icon={trendingUpOutline} />
                    <span>Trending</span>
                  </IonChip>
                )}
              </div>

              <div className="tema-header-modern">
                <IonAvatar className="tema-avatar-modern">
                  <img alt={tema.nombreuser} src={tema.avatar} />
                  <div className="avatar-ring"></div>
                </IonAvatar>
                <div className="tema-info-modern">
                  <div className="tema-user-date">
                    <span className="tema-username">{tema.nombreuser}</span>
                    <span className="tema-dot">•</span>
                    <span className="tema-date">{formatDate(tema.fecha)}</span>
                  </div>
                  <h3 className="tema-titulo-modern">{tema.titulo}</h3>
                </div>
              </div>

              {tema.comentario && (
                <div className="ultimo-comentario-modern">
                  <div className="comentario-author">
                    <IonAvatar className="comentario-avatar-small">
                      <img alt={tema.c_nombre} src={tema.c_avatar} />
                    </IonAvatar>
                    <div className="comentario-info">
                      <span className="comentario-nombre">{tema.c_nombre}</span>
                      <p className="comentario-texto-modern">{tema.comentario}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="tema-footer-modern">
                <div className="stat-item">
                  <IonIcon icon={chatboxEllipsesOutline} className="stat-icon" />
                  <span className="stat-number">{tema.n_com}</span>
                  <span className="stat-label">respuestas</span>
                </div>
                <div className="stat-divider"></div>
                <div className="stat-item">
                  <IonIcon icon={tema.n_gusta > 5 ? heart : heartOutline} className="stat-icon stat-heart" />
                  <span className="stat-number">{tema.n_gusta}</span>
                  <span className="stat-label">me gusta</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <IonFab vertical="bottom" horizontal="end" slot="fixed">
          <IonFabButton onClick={openCreaTema} className="fab-button-modern">
            <IonIcon icon={add} />
            <div className="fab-pulse"></div>
          </IonFabButton>
        </IonFab>

        <IonModal isOpen={showModal && !!selectedTema} onDidDismiss={closeModal}>
          {selectedTema && <Tema idTema={selectedTema} onClose={closeModal} />}
        </IonModal>

        <IonModal isOpen={showModal && !selectedTema} onDidDismiss={() => setShowModal(false)}>
          <CreaTema onClose={() => setShowModal(false)} />
        </IonModal>
      </IonContent>

      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mi Perfil</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/conversations'); }}>
                <IonIcon icon={trophy} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => setDatosModalOpen(true)}>
                <IonIcon icon={trophy} />
                <span>Datos</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/puntos'); }}>
                <IonIcon icon={trophy} />
                <span>Mis Puntos</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline" onClick={handleLogout}>
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

export default Foro;
