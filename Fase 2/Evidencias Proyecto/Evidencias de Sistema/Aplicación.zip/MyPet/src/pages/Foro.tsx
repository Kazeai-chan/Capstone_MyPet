
import {
  IonAvatar,
  IonButton,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonLabel,
  IonModal,
  IonPage,
  IonSearchbar,
  IonSegment,
  IonSegmentButton,
  IonToolbar,
  IonChip,
  useIonViewWillEnter,
  IonSpinner,
  IonAlert // <-- 1. IMPORTAR IONALERT
} from '@ionic/react';
import { add, chatboxEllipsesOutline, chatbubbles, close, documentText, flameOutline, heart, heartOutline, pawOutline, person, personCircleOutline, pricetagOutline, sparklesOutline, trendingUpOutline } from 'ionicons/icons';
import { useContext, useState, useMemo } from 'react';
import { useHistory } from 'react-router-dom';

import { collection, getDocs, Timestamp, query, orderBy, where } from 'firebase/firestore'; // <-- 2. IMPORTAR WHERE
import { firestore } from '../firebase';
import { UserContext } from '../context/UserContext';

import './Foro.css';
import { CreaTema } from '../components/CreaTema';
import PerfilModal from 'components/PerfilModal';

// --- MEJORA: Definir el tipo de resultado del modal ---
interface CreaTemaResult {
  status: 'created' | 'blocked' | 'closed';
}

const Foro: React.FC = () => {
  const { user, logout } = useContext(UserContext);
  const history = useHistory();

  const [temas, setTemas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreaTemaModal, setShowCreaTemaModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [segmentValue, setSegmentValue] = useState('todos');
  const [searchText, setSearchText] = useState('');
  
  // <-- 3. AÑADIR ESTADO PARA LA ALERTA ---
  const [showBlockedAlert, setShowBlockedAlert] = useState(false);

  const fetchTemas = async () => {
    setLoading(true);
    try {
      const temasCollection = collection(firestore, 'temas');
      // <-- 4. MODIFICAR QUERY PARA FILTRAR TEMAS NO VISIBLES ---
      const temasQuery = query(temasCollection, where("visible", "==", true), orderBy('fecha', 'desc'));
      const temasSnapshot = await getDocs(temasQuery);
      const temasData = temasSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTemas(temasData);
    } catch (error) {
      console.error("Error al cargar los temas:", error);
    } finally {
      setLoading(false);
    }
  };

  useIonViewWillEnter(() => {
    fetchTemas();
  });

  // <-- 5. MODIFICAR MANEJADOR DEL MODAL ---
  const handleCloseCreaTemaModal = (result?: CreaTemaResult) => {
    setShowCreaTemaModal(false);
    if (result?.status === 'created') {
      fetchTemas(); // Recarga si se creó un tema
    } else if (result?.status === 'blocked') {
      setShowBlockedAlert(true); // Muestra alerta si fue bloqueado
    }
    // Si es 'closed' o undefined, solo se cierra el modal
  };

  const formatDate = (timestamp: Timestamp): string => {
    return timestamp ? new Date(timestamp.seconds * 1000).toLocaleDateString() : '';
  };

  const handleLogout = () => {
    setShowProfileModal(false);
    logout();
  };

  const temasToShow = useMemo(() => {
    let filteredTemas = temas;

    if (segmentValue === 'mis' && user) {
      filteredTemas = temas.filter(tema => tema.iduser === user.uid);
    }

    if (searchText.trim() !== '') {
      filteredTemas = filteredTemas.filter(tema =>
        tema.titulo.toLowerCase().includes(searchText.toLowerCase())
      );
    }

    return filteredTemas;
  }, [temas, segmentValue, searchText, user]);

  const goToTema = (id: string) => {
    history.push(`/app/tema/${id}`);
  };

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="header-toolbar">
          <div className="header-mobile">
            <img
              src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
              alt="MyPet"
              className="logo-mobile"
            />
            <div className="header-actions">
              <IonAvatar className="avatar-small" onClick={() => setShowProfileModal(true)}>
                <img src={user?.fotouser || 'https://via.placeholder.com/150'} alt="Perfil" />
              </IonAvatar>
            </div>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="foro-content">
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user}/>}

        <div className="hero-section">
          <div className="hero-content">
            <div className="hero-text">
              <h1 className="hero-title">
                <IonIcon icon={sparklesOutline} className="hero-icon" />
                Comunidad MyPet
              </h1>
              <p className="hero-subtitle">Comparte, aprende y conecta con otros dueños</p>
            </div>
            <IonSearchbar
              value={searchText}
              onIonInput={(e) => setSearchText(e.detail.value || '')}
              placeholder="Buscar temas..."
              className="hero-searchbar"
              mode="ios"
              animated
            />
          </div>
        </div>

        <div className="segment-wrapper">
          <IonSegment
            value={segmentValue}
            onIonChange={(e) => setSegmentValue(String(e.detail.value || 'todos'))}
            className="modern-segment"
            mode="ios"
          >
            <IonSegmentButton value="todos" className="segment-btn">
              <IonLabel>
                <div className="segment-content">
                  <IonIcon icon={flameOutline} />
                  <span>Todos</span>
                </div>
              </IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="mis" className="segment-btn">
              <IonLabel>
                <div className="segment-content">
                  <IonIcon icon={personCircleOutline} />
                  <span>Mis Temas</span>
                </div>
              </IonLabel>
            </IonSegmentButton>
          </IonSegment>
        </div>

        <div className="temas-container">
          {loading ? (
            <div className="loading-container"><IonSpinner name="crescent" /></div>
          ) : (
            temasToShow.map((tema, index) => (
              <div
                key={tema.id}
                className="tema-card-modern"
                onClick={() => goToTema(tema.id)}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="tema-badges">
                  {tema.categoria && (
                    <IonChip className="badge-categoria">
                      <IonIcon icon={pricetagOutline} />
                      <span>{tema.categoria}</span>
                    </IonChip>
                  )}
                  {tema.trending && (
                    <IonChip className="badge-trending">
                      <IonIcon icon={trendingUpOutline} />
                      <span>Trending</span>
                    </IonChip>
                  )}
                </div>

                <div className="tema-header-modern">
                  <IonAvatar className="tema-avatar-modern">
                    <img alt={tema.nombreuser} src={tema.avatar} />
                    <div className="avatar-ring"></div>
                  </IonAvatar>
                  <div className="tema-info-modern">
                    <div className="tema-user-date">
                      <span className="tema-username">{tema.nombreuser}</span>
                      <span className="tema-dot">•</span>
                      <span className="tema-date">{formatDate(tema.fecha)}</span>
                    </div>
                    <h3 className="tema-titulo-modern">{tema.titulo}</h3>
                  </div>
                </div>

                {tema.comentario && (
                  <div className="ultimo-comentario-modern">
                    <div className="comentario-author">
                      <IonAvatar className="comentario-avatar-small">
                        <img alt={tema.c_nombre} src={tema.c_avatar} />
                      </IonAvatar>
                      <div className="comentario-info">
                        <span className="comentario-nombre">{tema.c_nombre}</span>
                        <p className="comentario-texto-modern">{tema.comentario}</p>
                      </div>
                    </div>
                  </div>
                )}

                <div className="tema-footer-modern">
                  <div className="stat-item">
                    <IonIcon icon={chatboxEllipsesOutline} className="stat-icon" />
                    <span className="stat-number">{tema.n_com}</span>
                    <span className="stat-label">respuestas</span>
                  </div>
                  <div className="stat-divider"></div>
                  <div className="stat-item">
                    <IonIcon icon={tema.n_gusta > 5 ? heart : heartOutline} className="stat-icon stat-heart" />
                    <span className="stat-number">{tema.n_gusta}</span>
                    <span className="stat-label">me gusta</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <IonFab vertical="bottom" horizontal="end" slot="fixed">
          <IonFabButton onClick={() => setShowCreaTemaModal(true)} className="fab-button-modern">
            <IonIcon icon={add} />
            <div className="fab-pulse"></div>
          </IonFabButton>
        </IonFab>

        {/* <-- 6. MODIFICAR MODAL Y AÑADIR ALERTA --_> */}
        <IonModal isOpen={showCreaTemaModal} onDidDismiss={() => handleCloseCreaTemaModal({ status: 'closed' })}>
          <CreaTema onClose={handleCloseCreaTemaModal} />
        </IonModal>

        <IonAlert
          isOpen={showBlockedAlert}
          onDidDismiss={() => setShowBlockedAlert(false)}
          header={'Publicación Bloqueada'}
          message={'Tu tema ha sido eliminado por no cumplir con las normas de la comunidad. Revisa tus notificaciones para más detalles'}
          buttons={['ENTENDIDO']}
          cssClass={"custom-alert"}
        />
      </IonContent>

      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mis Conexiones</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/conversations'); }}>
                <IonIcon icon={chatbubbles} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/dato'); }}>
                <IonIcon icon={documentText} />
                <span>Datos de Reportes</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/mascotavirtual'); }}>
                <IonIcon icon={pawOutline} />
                <span>Mi Mascota</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline" onClick={handleLogout}>
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>
    </IonPage>
  );
};

export default Foro;
