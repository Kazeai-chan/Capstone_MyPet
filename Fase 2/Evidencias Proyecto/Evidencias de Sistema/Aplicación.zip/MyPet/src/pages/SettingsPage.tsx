
import React, { useState, useEffect } from 'react';
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonIcon, IonList, IonItem, IonLabel, useIonToast } from '@ionic/react';
import { cogOutline } from 'ionicons/icons';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import './SettingsPage.css';

const SettingsPage: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [present] = useIonToast();

  // Efecto para obtener el estado de autenticación del usuario
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    // Limpiar la suscripción al desmontar el componente
    return () => unsubscribe();
  }, []);

  // Efecto para mostrar mensajes (toasts) después de la redirección de Aqara
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const aqaraStatus = params.get('aqara');
    const details = params.get('details');

    if (aqaraStatus) {
      const message = aqaraStatus === 'success'
        ? '¡Conexión con Aqara exitosa!'
        : `Error en la conexión con Aqara: ${details || 'Inténtalo de nuevo.'}`;
      
      present({
        message: message,
        duration: 5000,
        color: aqaraStatus === 'success' ? 'success' : 'danger',
        position: 'top',
      });

      // Limpia la URL para no mostrar el mensaje de nuevo si se recarga la página
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [present]);

  const handleConnectAqara = () => {
    if (user) {
      // Adjuntamos el UID del usuario como un query parameter
      const uid = user.uid;
      const aqaraAuthUrl = `https://us-central1-instant-vent-423002-f1.cloudfunctions.net/aqaraAuthRedirect?uid=${uid}`;
      window.location.href = aqaraAuthUrl;
    } else {
      present({
        message: 'Debes iniciar sesión para conectar servicios.',
        duration: 3000,
        color: 'warning',
        position: 'top',
      });
      console.error("Usuario no autenticado. No se puede iniciar la conexión con Aqara.");
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Ajustes</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonList>
          <IonItem lines="full">
            <IonIcon icon={cogOutline} slot="start" />
            <IonLabel>
              <h2>Conexiones de Terceros</h2>
              <p>Conecta tus dispositivos y servicios</p>
            </IonLabel>
          </IonItem>
          <IonItem>
            <IonLabel>Cámara Aqara</IonLabel>
            {/* El botón se deshabilita si el usuario no ha iniciado sesión */}
            <IonButton slot="end" onClick={handleConnectAqara} disabled={!user}>
              Conectar
            </IonButton>
          </IonItem>
        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default SettingsPage;
