import React, { useState } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonCard,
  IonCardContent,
  IonButton,
  IonIcon,
  IonChip,
  IonSegment,
  IonSegmentButton,
  IonLabel,
  IonModal,
  IonAvatar,
  IonProgressBar
} from '@ionic/react';
import {
  trophyOutline,
  giftOutline,
  pricetag,
  storefrontOutline,
  imageOutline,
  chevronForward,
  checkmarkCircle,
  close,
  informationCircleOutline,
  flashOutline,
} from 'ionicons/icons';

interface Reward {
  id: number;
  tipo: 'fondo' | 'descuento' | 'producto';
  nombre: string;
  descripcion: string;
  puntos: number;
  imagen: string;
  destacado?: boolean;
  tienda?: string;
}

const PetPuntosPage = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState<Reward | null>(null);

  const user = {
    nombre: 'María González',
    puntos: 1250,
    nivel: 'Oro',
    proximoNivel: 2000,
    fotouser: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150'
  };
  
  const rewards: Reward[] = [
    {
      id: 1,
      tipo: 'fondo',
      nombre: 'Fondo Tropical Pets',
      descripcion: 'Fondo colorido con temática tropical para tu perfil',
      puntos: 100,
      imagen: 'https://images.unsplash.com/photo-1540206395-68808572332f?w=400',
      destacado: true
    },
    {
      id: 2,
      tipo: 'fondo',
      nombre: 'Fondo Galaxia Pet',
      descripcion: 'Fondo espacial con estrellas y galaxias',
      puntos: 150,
      imagen: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400'
    },
    {
      id: 3,
      tipo: 'descuento',
      nombre: '20% Descuento Veterinaria San Diego',
      descripcion: 'Descuento en consultas veterinarias',
      puntos: 300,
      imagen: 'https://images.unsplash.com/photo-1628407285501-b895b0f1c1b4?w=400',
      tienda: 'Veterinaria San Diego'
    },
    {
      id: 4,
      tipo: 'producto',
      nombre: 'Correa Premium para Perros',
      descripcion: 'Correa resistente con diseño ergonómico',
      puntos: 500,
      imagen: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400',
      tienda: 'PetShop Central',
      destacado: true
    },
    {
      id: 5,
      tipo: 'descuento',
      nombre: '15% en Productos de Aseo',
      descripcion: 'Descuento en shampoos, cepillos y más',
      puntos: 200,
      imagen: 'https://images.unsplash.com/photo-1601758174114-e711c0cbaa69?w=400',
      tienda: 'PetCare Store'
    },
    {
      id: 6,
      tipo: 'producto',
      nombre: 'Juguete Interactivo',
      descripcion: 'Juguete con dispensador de premios',
      puntos: 400,
      imagen: 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=400',
      tienda: 'ToysPet'
    },
    {
      id: 7,
      tipo: 'fondo',
      nombre: 'Fondo Naturaleza Verde',
      descripcion: 'Fondo con paisajes naturales y vegetación',
      puntos: 120,
      imagen: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400'
    },
    {
      id: 8,
      tipo: 'producto',
      nombre: 'Cama Ortopédica',
      descripcion: 'Cama cómoda para mascotas grandes',
      puntos: 800,
      imagen: 'https://images.unsplash.com/photo-1591856419760-0ec6be4b7e9e?w=400',
      tienda: 'Comfort Pets'
    }
  ];

  const historial = [
    { id: 1, accion: 'Reportar mascota perdida', puntos: 50, fecha: '2025-10-09' },
    { id: 2, accion: 'Ayudar a encontrar mascota', puntos: 100, fecha: '2025-10-08' },
    { id: 3, accion: 'Comentar en reporte', puntos: 10, fecha: '2025-10-07' },
    { id: 4, accion: 'Crear tienda verificada', puntos: 200, fecha: '2025-10-05' }
  ];

  const filteredRewards = selectedCategory === 'all' 
    ? rewards 
    : rewards.filter(r => r.tipo === selectedCategory);

  const handleCanjeClick = (reward: Reward) => {
    setSelectedReward(reward);
    setShowRewardModal(true);
  };

  const handleConfirmCanje = () => {
    console.log('Canjeando:', selectedReward);
    setShowRewardModal(false);
    // Aquí iría la lógica de canje
  };

  const progressToNextLevel = (user.puntos / user.proximoNivel) * 100;

  const getRewardIcon = (tipo: string) => {
    switch(tipo) {
      case 'fondo': return imageOutline;
      case 'descuento': return pricetag;
      case 'producto': return giftOutline;
      default: return giftOutline;
    }
  };

  return (
    <IonPage>
      {/* Header */}
      <IonHeader className="ion-no-border">
        <IonToolbar className="petpuntos-toolbar">
          <div className="petpuntos-header">
            <div className="header-title-section">
              <IonIcon icon={trophyOutline} className="header-icon-puntos" />
              <h1 className="petpuntos-title">Mis PetPuntos</h1>
            </div>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="petpuntos-content">
        {/* Points Card */}
        <div className="points-hero">
          <IonCard className="points-card">
            <IonCardContent className="points-content">
              <div className="user-points-section">
                <IonAvatar className="user-avatar-points">
                  <img src={user.fotouser} alt={user.nombre} />
                </IonAvatar>
                <div className="points-info">
                  <h2>{user.nombre}</h2>
                  <div className="nivel-badge">
                    <IonIcon icon={trophyOutline} />
                    <span>Nivel {user.nivel}</span>
                  </div>
                </div>
              </div>

              <div className="points-display">
                <div className="points-circle">
                  <IonIcon icon={trophyOutline} className="trophy-icon" />
                  <span className="points-number">{user.puntos}</span>
                  <span className="points-label">PetPuntos</span>
                </div>
              </div>

              <div className="progress-section">
                <div className="progress-info">
                  <span>Próximo nivel: {user.proximoNivel} pts</span>
                  <span>{Math.round(progressToNextLevel)}%</span>
                </div>
                <IonProgressBar 
                  value={progressToNextLevel / 100} 
                  className="level-progress"
                />
              </div>
            </IonCardContent>
          </IonCard>
        </div>

        {/* Info Banner */}
        <div className="info-banner">
          <IonIcon icon={informationCircleOutline} />
          <p>¡Gana puntos reportando mascotas, ayudando a la comunidad y más!</p>
        </div>

        {/* Category Segment */}
        <div className="category-section">
          <IonSegment 
            value={selectedCategory} 
            onIonChange={e => {
              if (e.detail.value !== undefined) {
                setSelectedCategory(String(e.detail.value));
              }
            }}
            className="category-segment"
          >
            <IonSegmentButton value="all">
              <IonLabel>Todos</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="fondo">
              <IonIcon icon={imageOutline} />
              <IonLabel>Fondos</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="descuento">
              <IonIcon icon={pricetag} />
              <IonLabel>Descuentos</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="producto">
              <IonIcon icon={giftOutline} />
              <IonLabel>Productos</IonLabel>
            </IonSegmentButton>
          </IonSegment>
        </div>

        {/* Rewards Grid */}
        <div className="rewards-section">
          <h3 className="section-title">Canjea tus Puntos</h3>
          <div className="rewards-grid">
            {filteredRewards.map(reward => (
              <IonCard key={reward.id} className={`reward-card ${reward.destacado ? 'destacado' : ''}`}>
                {reward.destacado && (
                  <div className="destacado-badge">
                    <IonIcon icon={flashOutline} />
                    <span>Popular</span>
                  </div>
                )}
                
                <div className="reward-image-container">
                  <img src={reward.imagen} alt={reward.nombre} className="reward-image" />
                  <div className="reward-type-badge">
                    <IonIcon icon={getRewardIcon(reward.tipo)} />
                  </div>
                </div>

                <IonCardContent className="reward-content">
                  <h4 className="reward-name">{reward.nombre}</h4>
                  <p className="reward-description">{reward.descripcion}</p>
                  
                  {reward.tienda && (
                    <IonChip className="tienda-chip">
                      <IonIcon icon={storefrontOutline} />
                      <IonLabel>{reward.tienda}</IonLabel>
                    </IonChip>
                  )}

                  <div className="reward-footer">
                    <div className="reward-points">
                      <IonIcon icon={trophyOutline} />
                      <span>{reward.puntos} pts</span>
                    </div>
                    <IonButton
                      size="small"
                      className={`canje-btn ${user.puntos >= reward.puntos ? 'disponible' : 'insuficiente'}`}
                      onClick={() => handleCanjeClick(reward)}
                      disabled={user.puntos < reward.puntos}
                    >
                      {user.puntos >= reward.puntos ? 'Canjear' : 'Sin puntos'}
                      <IonIcon icon={chevronForward} slot="end" />
                    </IonButton>
                  </div>
                </IonCardContent>
              </IonCard>
            ))}
          </div>
        </div>

        {/* Historial */}
        <div className="historial-section">
          <h3 className="section-title">Historial de Puntos</h3>
          <IonCard className="historial-card">
            <IonCardContent className="historial-content">
              {historial.map(item => (
                <div key={item.id} className="historial-item">
                  <div className="historial-icon">
                    <IonIcon icon={trophyOutline} />
                  </div>
                  <div className="historial-info">
                    <p className="historial-accion">{item.accion}</p>
                    <span className="historial-fecha">{new Date(item.fecha).toLocaleDateString('es-ES')}</span>
                  </div>
                  <div className="historial-puntos">
                    <span className="puntos-ganados">+{item.puntos}</span>
                  </div>
                </div>
              ))}
            </IonCardContent>
          </IonCard>
        </div>

        <div style={{ height: '80px' }}></div>
      </IonContent>

      {/* Modal de Confirmación */}
      <IonModal 
        isOpen={showRewardModal} 
        onDidDismiss={() => setShowRewardModal(false)}
        className="reward-modal"
      >
        {selectedReward && (
          <div className="reward-modal-content">
            <IonButton 
              fill="clear" 
              className="close-modal-btn"
              onClick={() => setShowRewardModal(false)}
            >
              <IonIcon icon={close} />
            </IonButton>

            <div className="modal-image">
              <img src={selectedReward.imagen} alt={selectedReward.nombre} />
            </div>

            <div className="modal-body">
              <IonIcon icon={getRewardIcon(selectedReward.tipo)} className="modal-icon" />
              <h2>{selectedReward.nombre}</h2>
              <p>{selectedReward.descripcion}</p>

              {selectedReward.tienda && (
                <IonChip className="tienda-chip-modal">
                  <IonIcon icon={storefrontOutline} />
                  <IonLabel>{selectedReward.tienda}</IonLabel>
                </IonChip>
              )}

              <div className="modal-points-info">
                <div className="points-required">
                  <span className="label">Costo:</span>
                  <div className="points-value">
                    <IonIcon icon={trophyOutline} />
                    <span>{selectedReward.puntos} pts</span>
                  </div>
                </div>
                <div className="points-remaining">
                  <span className="label">Te quedarán:</span>
                  <span className="value">{user.puntos - selectedReward.puntos} pts</span>
                </div>
              </div>

              <IonButton
                expand="block"
                className="confirm-canje-btn"
                onClick={handleConfirmCanje}
              >
                <IonIcon icon={checkmarkCircle} slot="start" />
                Confirmar Canje
              </IonButton>
            </div>
          </div>
        )}
      </IonModal>
    </IonPage>
  );
};

// CSS Styles
const styles = `
:root {
  --mypet-primary: #445a14;
  --mypet-primary-light: #5a7519;
  --mypet-accent: #d8e59c;
  --mypet-accent-light: #e5f0b8;
  --mypet-cream: #f5f3e8;
  --mypet-cream-dark: #e8e5d3;
  --mypet-white: #ffffff;
  --mypet-text: #2d3436;
  --mypet-text-light: #636e72;
  --mypet-shadow: rgba(68, 90, 20, 0.08);
}

/* Header */
.petpuntos-toolbar {
  --background: var(--mypet-white);
  --border-width: 0;
  --min-height: 60px;
  box-shadow: 0 2px 8px var(--mypet-shadow);
}

.petpuntos-header {
  padding: 12px 20px;
}

.header-title-section {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-icon-puntos {
  font-size: 32px;
  color: #f39c12;
}

.petpuntos-title {
  font-size: 24px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0;
}

/* Content */
.petpuntos-content {
  --background: var(--mypet-cream);
}

/* Points Hero */
.points-hero {
  padding: 20px 16px;
}

.points-card {
  background: linear-gradient(135deg, var(--mypet-primary) 0%, var(--mypet-primary-light) 100%);
  border-radius: 20px;
  box-shadow: 0 8px 24px rgba(68, 90, 20, 0.2);
  margin: 0;
}

.points-content {
  padding: 24px;
}

.user-points-section {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
}

.user-avatar-points {
  width: 60px;
  height: 60px;
  border: 3px solid var(--mypet-white);
}

.points-info h2 {
  color: var(--mypet-white);
  font-size: 18px;
  font-weight: 700;
  margin: 0 0 8px 0;
}

.nivel-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: rgba(255, 255, 255, 0.2);
  padding: 4px 12px;
  border-radius: 12px;
  backdrop-filter: blur(10px);
}

.nivel-badge ion-icon {
  color: #f39c12;
  font-size: 16px;
}

.nivel-badge span {
  color: var(--mypet-white);
  font-size: 13px;
  font-weight: 600;
}

.points-display {
  display: flex;
  justify-content: center;
  margin-bottom: 24px;
}

.points-circle {
  width: 180px;
  height: 180px;
  border-radius: 50%;
  background: var(--mypet-white);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  position: relative;
}

.trophy-icon {
  font-size: 48px;
  color: #f39c12;
  margin-bottom: 8px;
}

.points-number {
  font-size: 40px;
  font-weight: 700;
  color: var(--mypet-primary);
  line-height: 1;
}

.points-label {
  font-size: 14px;
  color: var(--mypet-text-light);
  font-weight: 600;
  margin-top: 4px;
}

.progress-section {
  background: rgba(255, 255, 255, 0.15);
  padding: 16px;
  border-radius: 12px;
  backdrop-filter: blur(10px);
}

.progress-info {
  display: flex;
  justify-content: space-between;
  color: var(--mypet-white);
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 8px;
}

.level-progress {
  --background: rgba(255, 255, 255, 0.3);
  --progress-background: #f39c12;
  height: 8px;
  border-radius: 4px;
}

/* Info Banner */
.info-banner {
  display: flex;
  align-items: center;
  gap: 12px;
  background: var(--mypet-accent-light);
  padding: 16px 20px;
  margin: 0 16px 20px 16px;
  border-radius: 12px;
  border-left: 4px solid var(--mypet-primary);
}

.info-banner ion-icon {
  font-size: 24px;
  color: var(--mypet-primary);
  flex-shrink: 0;
}

.info-banner p {
  font-size: 14px;
  color: var(--mypet-text);
  margin: 0;
  line-height: 1.4;
}

/* Category Segment */
.category-section {
  padding: 0 16px 20px 16px;
}

.category-segment {
  --background: var(--mypet-white);
  border-radius: 12px;
  padding: 4px;
  box-shadow: 0 2px 8px var(--mypet-shadow);
}

.category-segment ion-segment-button {
  --indicator-color: var(--mypet-accent);
  --color: var(--mypet-text-light);
  --color-checked: var(--mypet-primary);
  min-height: 40px;
  font-size: 13px;
  font-weight: 600;
}

.category-segment ion-segment-button ion-icon {
  font-size: 18px;
  margin-bottom: 2px;
}

/* Rewards Section */
.rewards-section {
  padding: 0 16px 20px 16px;
}

.section-title {
  font-size: 18px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 16px 0;
}

.rewards-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}

.reward-card {
  margin: 0;
  border-radius: 16px;
  box-shadow: 0 4px 12px var(--mypet-shadow);
  overflow: hidden;
  position: relative;
  transition: transform 0.2s;
}

.reward-card:active {
  transform: scale(0.98);
}

.reward-card.destacado {
  border: 2px solid #f39c12;
}

.destacado-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
  color: var(--mypet-white);
  padding: 6px 12px;
  border-radius: 20px;
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  font-weight: 700;
  z-index: 10;
  box-shadow: 0 2px 8px rgba(243, 156, 18, 0.4);
}

.destacado-badge ion-icon {
  font-size: 14px;
}

.reward-image-container {
  position: relative;
  height: 160px;
  overflow: hidden;
}

.reward-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.reward-type-badge {
  position: absolute;
  bottom: 12px;
  left: 12px;
  background: rgba(255, 255, 255, 0.95);
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.reward-type-badge ion-icon {
  font-size: 20px;
  color: var(--mypet-primary);
}

.reward-content {
  padding: 16px;
}

.reward-name {
  font-size: 15px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 8px 0;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.reward-description {
  font-size: 13px;
  color: var(--mypet-text-light);
  line-height: 1.4;
  margin: 0 0 12px 0;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.tienda-chip {
  --background: var(--mypet-accent-light);
  --color: var(--mypet-primary);
  height: 28px;
  font-size: 11px;
  font-weight: 600;
  margin-bottom: 12px;
}

.tienda-chip ion-icon {
  font-size: 14px;
}

.reward-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.reward-points {
  display: flex;
  align-items: center;
  gap: 6px;
  background: var(--mypet-accent-light);
  padding: 8px 12px;
  border-radius: 20px;
}

.reward-points ion-icon {
  font-size: 18px;
  color: #f39c12;
}

.reward-points span {
  font-size: 14px;
  font-weight: 700;
  color: var(--mypet-primary);
}

.canje-btn {
  --padding-start: 16px;
  --padding-end: 12px;
  height: 36px;
  font-size: 13px;
  font-weight: 600;
  text-transform: none;
  margin: 0;
}

.canje-btn.disponible {
  --background: var(--mypet-primary);
  --color: var(--mypet-white);
}

.canje-btn.insuficiente {
  --background: var(--mypet-cream-dark);
  --color: var(--mypet-text-light);
}

.canje-btn ion-icon {
  font-size: 16px;
  margin-left: 4px;
}

/* Historial */
.historial-section {
  padding: 0 16px 20px 16px;
}

.historial-card {
  margin: 0;
  border-radius: 16px;
  box-shadow: 0 2px 8px var(--mypet-shadow);
}

.historial-content {
  padding: 16px;
}

.historial-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: var(--mypet-cream);
  border-radius: 12px;
  margin-bottom: 12px;
}

.historial-item:last-child {
  margin-bottom: 0;
}

.historial-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--mypet-accent-light);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.historial-icon ion-icon {
  font-size: 20px;
  color: #f39c12;
}

.historial-info {
  flex: 1;
  min-width: 0;
}

.historial-accion {
  font-size: 14px;
  font-weight: 600;
  color: var(--mypet-text);
  margin: 0 0 4px 0;
}

.historial-fecha {
  font-size: 12px;
  color: var(--mypet-text-light);
}

.historial-puntos {
  flex-shrink: 0;
}

.puntos-ganados {
  font-size: 16px;
  font-weight: 700;
  color: #27ae60;
}

/* Modal */
.reward-modal {
  --height: auto;
  --border-radius: 24px 24px 0 0;
  --max-height: 85vh;
}

.reward-modal-content {
  background: var(--mypet-white);
  border-radius: 24px 24px 0 0;
  position: relative;
}

.close-modal-btn {
  position: absolute;
  top: 16px;
  right: 16px;
  z-index: 10;
  --background: rgba(255, 255, 255, 0.9);
  --border-radius: 50%;
  width: 40px;
  height: 40px;
  margin: 0;
}

.close-modal-btn ion-icon {
  font-size: 24px;
  color: var(--mypet-text);
}

.modal-image {
  height: 240px;
  overflow: hidden;
}

.modal-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.modal-body {
  padding: 24px;
  text-align: center;
}

.modal-icon {
  font-size: 48px;
  color: var(--mypet-primary);
  margin-bottom: 16px;
}

.modal-body h2 {
  font-size: 22px;
  font-weight: 700;
  color: var(--mypet-text);
  margin: 0 0 12px 0;
}

.modal-body p {
  font-size: 14px;
  color: var(--mypet-text-light);
  line-height: 1.5;
  margin: 0 0 20px 0;
}

.tienda-chip-modal {
  --background: var(--mypet-accent);
  --color: var(--mypet-primary);
  margin-bottom: 24px;
}

.modal-points-info {
  background: var(--mypet-cream);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
}

.points-required,
.points-remaining {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.points-remaining {
  margin-bottom: 0;
}

.modal-points-info .label {
  font-size: 13px;
  color: var(--mypet-text-light);
  font-weight: 600;
}

.points-value {
  display: flex;
  align-items: center;
  gap: 6px;
}

.points-value ion-icon {
  font-size: 20px;
  color: #f39c12;
}

.points-value span {
  font-size: 18px;
  font-weight: 700;
  color: var(--mypet-primary);
}

.points-remaining .value {
  font-size: 18px;
  font-weight: 700;
  color: var(--mypet-text);
}

.confirm-canje-btn {
  --background: var(--mypet-primary);
  --color: var(--mypet-white);
  --border-radius: 12px;
  height: 52px;
  font-weight: 600;
  font-size: 16px;
  margin: 0;
  text-transform: none;
}

.confirm-canje-btn ion-icon {
  font-size: 22px;
}

/* Responsive */
@media (max-width: 576px) {
  .petpuntos-title {
    font-size: 20px;
  }
  
  .header-icon-puntos {
    font-size: 28px;
  }
  
  .rewards-grid {
    grid-template-columns: 1fr;
  }
  
  .points-circle {
    width: 160px;
    height: 160px;
  }
  
  .trophy-icon {
    font-size: 40px;
  }
  
  .points-number {
    font-size: 36px;
  }
}

@media (min-width: 768px) {
  .rewards-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (min-width: 1024px) {
  .rewards-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = styles;
document.head.appendChild(styleSheet);

export default PetPuntosPage;