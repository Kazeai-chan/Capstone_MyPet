
import React, { useState, useEffect, useContext } from 'react';
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonAvatar, IonSpinner, IonIcon, IonSearchbar, IonBadge, IonLabel, IonSegment, IonSegmentButton } from '@ionic/react';
import { useHistory } from 'react-router-dom';
import { collection, query, where, onSnapshot, getDoc, doc, Timestamp } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './ConversationsPage.css';
import { chatbubbleOutline, chatbubblesOutline, checkmarkDoneOutline, checkmarkOutline, searchOutline } from 'ionicons/icons';

// Interfaces
interface Message {
  id: string;
  de: string;
  para: string;
  mensaje: string;
  fecha: Timestamp;
  leido:boolean;
}

interface UserData {
  id: string;
  nombre: string;
  fotouser: string;
}

interface Conversation {
  otherUser: UserData;
  lastMessage: Message;
  unreadCount: number;
}

const ConversationsPage: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useContext<UserContextType>(UserContext);
  const history = useHistory();
  const [searchText, setSearchText] = useState('');
  const [segmentValue, setSegmentValue] = useState('all');
  

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);

    const sentQuery = query(collection(firestore, 'mensajes'), where('de', '==', user.uid));
    const receivedQuery = query(collection(firestore, 'mensajes'), where('para', '==', user.uid));

    let sentMessages: Message[] = [];
    let receivedMessages: Message[] = [];

    const processAllMessages = async () => {
        const allMessages = [...sentMessages, ...receivedMessages];
        
        const conversationsMap = new Map<string, Message>();
        allMessages.forEach(msg => {
            const otherUserId = msg.de === user.uid ? msg.para : msg.de;
            const existing = conversationsMap.get(otherUserId);
            if (msg.fecha && (!existing || !existing.fecha || msg.fecha.seconds > existing.fecha.seconds)) {
                conversationsMap.set(otherUserId, msg);
            }
        });

        if (conversationsMap.size === 0) {
            setConversations([]);
            setLoading(false);
            return;
        }

        const otherUserIds = Array.from(conversationsMap.keys());
        const usersDataPromises = otherUserIds.map(uid => getDoc(doc(firestore, 'usuarios', uid)));
        const usersDocs = await Promise.all(usersDataPromises);

        const usersDataMap = new Map<string, UserData>();
        usersDocs.forEach(userDoc => {
            if (userDoc.exists()) {
                const data = userDoc.data();
                usersDataMap.set(userDoc.id, { id: userDoc.id, nombre: data.nombre, fotouser: data.fotouser });
            }
        });

        const finalConversations: Conversation[] = [];
        conversationsMap.forEach((lastMessage, otherUserId) => {
            const unreadMessages = allMessages.filter(
              (msg) => msg.para === user.uid && msg.de === otherUserId && !msg.leido
            ).length;
            const otherUser = usersDataMap.get(otherUserId);
            if (otherUser) {
                finalConversations.push({ otherUser, lastMessage, unreadCount: unreadMessages });
            }
        });

        finalConversations.sort((a, b) => b.lastMessage.fecha.seconds - a.lastMessage.fecha.seconds);
        
        setConversations(finalConversations);
        setLoading(false);
    };

    const unsubscribeSent = onSnapshot(sentQuery, snapshot => {
        sentMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
        processAllMessages();
    }, (error) => {
        console.error('Error en la consulta de mensajes enviados:', error);
    });

    const unsubscribeReceived = onSnapshot(receivedQuery, snapshot => {
        receivedMessages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
        processAllMessages();
    }, (error) => {
        console.error('Error en la consulta de mensajes recibidos:', error);
    });

    return () => {
        unsubscribeSent();
        unsubscribeReceived();
    };
  }, [user]);

  const handleConversationClick = (otherUserId: string) => {
    history.push(`/chat/${otherUserId}`);
  };

  const filteredConversations = conversations.filter(({ otherUser, lastMessage }) => {
    const matchesSearch = otherUser.nombre.toLowerCase().includes(searchText.toLowerCase()) ||
                         lastMessage.mensaje.toLowerCase().includes(searchText.toLowerCase());
    
    if (segmentValue === 'unread') {
      return matchesSearch && !lastMessage.leido && lastMessage.para === user?.uid;
    }
    
    return matchesSearch;
  });

  const formatTime = (timestamp: Timestamp) => {
    const date = timestamp.toDate();
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      return 'Ayer';
    } else {
      return date.toLocaleDateString();
    }
  };

  const unreadCount = conversations.filter(
    ({ lastMessage }) => !lastMessage.leido && lastMessage.para === user?.uid
  ).length;

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="conversations-toolbar">
          <div className="conversations-header">
            <div className="header-left">
              <div className="header-icon-wrapper">
                <IonIcon icon={chatbubblesOutline} className="header-main-icon" />
                <div className="header-paw-decoration">🐾</div>
              </div>
              <div className="header-text">
                <IonTitle className="conversations-title">Mensajes</IonTitle>
                <span className="conversations-subtitle">
                  {unreadCount > 0 ? `${unreadCount} sin leer` : 'Todo al día'}
                </span>
              </div>
            </div>
          </div>
        </IonToolbar>

        {/* Search Bar Mejorada */}
        <div className="search-section-modern">
          <div className="search-wrapper">
            <IonIcon icon={searchOutline} className="search-icon-left" />
            <IonSearchbar
              value={searchText}
              onIonInput={e => setSearchText(e.detail.value!)}
              placeholder="Buscar conversaciones..."
              className="conversations-searchbar"
              mode="ios"
            />
          </div>
        </div>

        {/* Segmento de Filtros */}
        <div className="segment-section-conversations">
          <IonSegment
            value={segmentValue}
            onIonChange={e => setSegmentValue(String(e.detail.value ?? 'all'))}
            className="conversations-segment"
            mode="ios"
          >
            <IonSegmentButton value="all">
              <IonLabel>Todos</IonLabel>
            </IonSegmentButton>
            <IonSegmentButton value="unread">
              <IonLabel>
                Sin leer
                {unreadCount > 0 && (
                  <IonBadge className="segment-badge">{unreadCount}</IonBadge>
                )}
              </IonLabel>
            </IonSegmentButton>
          </IonSegment>
        </div>
      </IonHeader>

      <IonContent className="conversations-content">
        {loading ? (
          <div className="loading-center-modern">
            <div className="loading-animation">
              <IonSpinner name="circular" className="loading-spinner-modern" />
              <p className="loading-text-modern">Cargando conversaciones...</p>
            </div>
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="empty-state-modern">
            <div className="empty-illustration">
              <div className="empty-icon-circle">
                <IonIcon icon={chatbubbleOutline} className="empty-icon-modern" />
              </div>
            </div>
            <h3 className="empty-title">
              {searchText ? 'Sin resultados' : 'No hay conversaciones'}
            </h3>
            <p className="empty-description">
              {searchText
                ? 'Intenta con otros términos de búsqueda'
                : 'Inicia una conversación desde el perfil de otros usuarios'}
            </p>
          </div>
        ) : (
          <div className="conversations-list-modern">
            {filteredConversations.map(({ otherUser, lastMessage, unreadCount }) => (
              <div
                key={otherUser.id}
                className={`conversation-item-modern ${
                  !lastMessage.leido && lastMessage.para === user?.uid ? 'unread-item' : ''
                }`}
                onClick={() => handleConversationClick(otherUser.id)}
              >
                {/* Avatar con Badge */}
                <div className="avatar-section-modern">
                  <IonAvatar className="conversation-avatar-new">
                    <img src={otherUser.fotouser} alt={otherUser.nombre} />
                  </IonAvatar>
                  {!lastMessage.leido && lastMessage.para === user?.uid && (
                    <div className="unread-badge-avatar"></div>
                  )}
                </div>

                {/* Contenido */}
                <div className="conversation-body-modern">
                  <div className="conversation-top-row">
                    <h3 className="contact-name-modern">{otherUser.nombre}</h3>
                    <div className="time-section-modern">
                      <span className="message-time-modern">
                        {formatTime(lastMessage.fecha)}
                      </span>
                    </div>
                  </div>

                  <div className="conversation-bottom-row">
                    <div className="message-preview-modern">
                      {lastMessage.de === user?.uid && (
                        <IonIcon
                          icon={lastMessage.leido ? checkmarkDoneOutline : checkmarkOutline}
                          className={`check-icon ${lastMessage.leido ? 'read' : 'sent'}`}
                        />
                      )}
                      <p className={`last-message-text ${
                        !lastMessage.leido && lastMessage.para === user?.uid ? 'unread-message' : ''
                      }`}>
                        {lastMessage.mensaje}
                      </p>
                    </div>
                    {unreadCount > 0 && (
                      <IonBadge className="unread-count-badge">{unreadCount}</IonBadge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Espaciado para bottom nav */}
        <div style={{ height: '80px' }}></div>
      </IonContent>
{/*
      <IonContent className="mensajes-content">
        {loading ? (
          <div className="loading-center">
            <IonSpinner name="crescent" className="loading-spinner" />
            <p>Cargando conversaciones...</p>
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon-container">
              <IonIcon icon={chatbubbleOutline} className="empty-icon" />
            </div>
            <h3>No hay conversaciones</h3>
            <p>
              {searchText 
                ? 'No se encontraron resultados para tu búsqueda'
                : 'Aún no tienes mensajes. ¡Inicia una conversación!'
              }
            </p>
          </div>
        ) : (
          <IonList className="conversation-list-modern">
            {filteredConversations.map(({ otherUser, lastMessage }) => (
              <div 
                key={otherUser.id} 
                className={`conversation-card ${!lastMessage.leido && lastMessage.para === user?.uid ? 'unread' : ''}`}
                onClick={() => handleConversationClick(otherUser.id)}
              >
                <div className="conversation-avatar-container">
                  <IonAvatar className="conversation-avatar-modern">
                    <img src={otherUser.fotouser || 'https://via.placeholder.com/150'} alt={otherUser.nombre} />
                  </IonAvatar>
                  {!lastMessage.leido && lastMessage.para === user?.uid && (
                    <div className="online-indicator"></div>
                  )}
                </div>

                <div className="conversation-content">
                  <div className="conversation-header">
                    <h3 className="conversation-name">{otherUser.nombre}</h3>
                    <span className="conversation-time">
                      <IonIcon icon={timeOutline} className="time-icon" />
                      {formatTime(lastMessage.fecha)}
                    </span>
                  </div>
                  
                  <div className="conversation-message-row">
                    <p className={`conversation-message ${!lastMessage.leido && lastMessage.para === user?.uid ? 'unread-text' : ''}`}>
                      {lastMessage.mensaje}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </IonList>
        )}
        <div style={{ height: '80px' }}></div>
      </IonContent>*/}
    </IonPage>
  );
};

export default ConversationsPage;
