
import {
  IonContent,
  IonPage,
  IonHeader,
  IonToolbar,
  IonAvatar,
  IonIcon,
  IonSpinner,
  IonBadge,
  IonButton,
  IonModal,
} from '@ionic/react';
import React, { useState, useContext, useEffect } from 'react';
import { person, chatbubbles, documentText, notifications, add, paw, locationOutline, search, time, close, pawOutline } from 'ionicons/icons';
import 'swiper/css';
import './HomePage.css';
import { format } from 'date-fns';
import { collection, query, where, onSnapshot, doc, getDoc, updateDoc, orderBy } from "firebase/firestore";

// IMPORTS AÑADIDOS
import NotificationsModal from '../components/NotificationsModal';
import ConsejoMascota from '../components/ConsejoMascota';

import { UserContext, UserContextType } from '../context/UserContext';
import { firestore } from '../firebase';
import AgreMascota from '../components/AgreMascota';
import ModMascota from '../components/ModMascota';
import PerfilModal from '../components/PerfilModal';
import { useHistory } from 'react-router-dom';
import './HomePage.css';


interface Pet {
  id: string;
  nombre: string;
  foto: string;
  animal: string;
  raza: string;
  nacimiento: string;
  iduser: string;
}

interface NewsItem {
  title: string;
  link: string;
  imageUrl: string; 
  source: string;
  pubDate?: Date | string | null;
}

const HomePage: React.FC = () => {
  const [mascotas, setMascotas] = useState<Pet[]>([]);
  const [loadingPets, setLoadingPets] = useState(true);
  const [noticias, setNoticias] = useState<NewsItem[]>([]);
  const [loadingNews, setLoadingNews] = useState(true);
  const [newsError, setNewsError] = useState<string | null>(null);

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isModModalOpen, setModModalOpen] = useState(false);
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);

  const [isNotificationsModalOpen, setNotificationsModalOpen] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  
  const [consejo, setConsejo] = useState('');
  const [loadingConsejo, setLoadingConsejo] = useState(true);

  const { user } = useContext<UserContextType>(UserContext);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const { logout } = useContext(UserContext);

  const calculateAge = (nacimiento: string): string => {
    if (!nacimiento) return 'N/A';
    const birthDate = new Date(nacimiento);
    const diff_ms = Date.now() - birthDate.getTime();
    const age_dt = new Date(diff_ms);
    const years = Math.abs(age_dt.getUTCFullYear() - 1970);
    if (years > 0) return `${years} ${years === 1 ? 'año' : 'años'}`;
    const months = age_dt.getUTCMonth();
    return `${months} ${months === 1 ? 'mes' : 'meses'}`;
  };

  useEffect(() => {
    if (user && user.uid) {
      const notificationsQuery = query(
        collection(firestore, 'notificaciones'),
        where('userId', '==', user.uid),
        where('read', '==', false)
      );
  
      const unsubscribe = onSnapshot(notificationsQuery, (snapshot) => {
        setUnreadNotifications(snapshot.size);
      }, (error) => {
        console.error("Error fetching unread notifications count:", error);
      });
  
      return () => unsubscribe();
    }
  }, [user]);
  
  useEffect(() => {
    setLoadingNews(true);
    const newsQuery = query(collection(firestore, 'news'), orderBy('pubDate', 'desc'));

    const unsubscribe = onSnapshot(newsQuery, (snapshot) => {
      const newsData: NewsItem[] = [];
      snapshot.forEach((doc) => {
        newsData.push(doc.data() as NewsItem);
      });
      setNoticias(newsData);
      setLoadingNews(false);
    }, (error) => {
      console.error("Error fetching news from Firestore:", error);
      setNewsError("No se pudieron cargar las noticias.");
      setLoadingNews(false);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) {
      setMascotas([]);
      setLoadingPets(false);
      return;
    }

    if (user && user.uid) {
      setLoadingPets(true);
      const q = query(collection(firestore, 'mascotas'), where('iduser', '==', user.uid));

      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const petsData: Pet[] = [];
        querySnapshot.forEach((doc) => {
          petsData.push({ id: doc.id, ...doc.data() } as Pet);
        });
        setMascotas(petsData);
        setLoadingPets(false);
      }, (error) => {
        console.error("Error al obtener mascotas:", error);
        setLoadingPets(false);
      });

      return () => unsubscribe();
    }
  }, [user]);

  useEffect(() => {
    const fetchAndSaveConsejo = async (pets: Pet[], userDocRef: any, today: string) => {
        setLoadingConsejo(true);
        try {
          const response = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/getPetAdviceHttp', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ pets }),
          });

          if (!response.ok) {
            const errorBody = await response.text();
            console.error("Error response from function:", errorBody);
            throw new Error(`Network response was not ok: ${response.statusText}`);
          }

          const data = await response.json() as { advice: string };

          if (data.advice && user) {
            setConsejo(data.advice);
            await updateDoc(userDocRef, {
              consejoDelDia: data.advice,
              fechaConsejo: today,
            });
          } else {
            throw new Error("No advice returned from function");
          }
        } catch (error) {
          console.error('Error fetching new pet advice:', error);
          setConsejo('No se pudo obtener un consejo en este momento.');
        } finally {
          setLoadingConsejo(false);
        }
    };

    const handleConsejo = async () => {
      if (mascotas.length > 0 && user && user.uid) {
        const userDocRef = doc(firestore, 'usuarios', user.uid);
        const today = new Date().toISOString().split('T')[0];

        try {
          const userDoc = await getDoc(userDocRef);
          const userData = userDoc.data();

          if (userData && userData.fechaConsejo === today && userData.consejoDelDia) {
            setConsejo(userData.consejoDelDia);
            setLoadingConsejo(false);
          } else {
            await fetchAndSaveConsejo(mascotas, userDocRef, today);
          }
        } catch (error) {
          console.error("Error managing pet advice:", error);
          setConsejo('No se pudo obtener un consejo en este momento.');
          setLoadingConsejo(false);
        }
      } else if (!user) {
        setLoadingConsejo(false);
      }
    };

    handleConsejo();
  }, [mascotas, user]);


  const openModMascota = (id: string) => {
    setSelectedPetId(id);
    setModModalOpen(true);
  };

  const formatDate = (date: Date | string | null): string => {
    if (!date) return '';
    try {
      const dateObj = (typeof date === 'string') ? new Date(date) : date;
      return format(dateObj, 'dd/MM/yyyy HH:mm');
    } catch (error) {
      console.error("Error formatting date:", error);
      return String(date);
    }
  }

  const handleLogout = () => {
    setShowProfileModal(false);
    logout();
  };

  const formatBadgeCount = (count: number) => {
    if (count > 99) return '99+';
    return count.toString();
  };

  const history = useHistory();

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
      <IonToolbar className="header-toolbar">
        <div className="header-mobile">
          <img
            src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9"
            alt="MyPet"
            className="logo-mobile"
          />
          <div className="header-actions">
            <IonButton 
              fill="clear" 
              className="icon-btn" 
              onClick={() => setNotificationsModalOpen(true)}
            >
              <IonIcon icon={notifications} />
              {unreadNotifications > 0 && (
                <IonBadge 
                  className={`badge-notification ${unreadNotifications >= 10 ? 'double-digit' : ''}`}
                >
                  {formatBadgeCount(unreadNotifications)}
                </IonBadge>
              )}
            </IonButton>

            <IonAvatar 
              className="avatar-small" 
              onClick={() => setShowProfileModal(true)}
            >
              <img 
                src={user?.fotouser || 'https://via.placeholder.com/150'} 
                alt="Perfil" 
              />
            </IonAvatar>
          </div>
        </div>
      </IonToolbar>
    </IonHeader>
      
      <IonContent fullscreen>
        {user && <PerfilModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} user={user} />}
        <AgreMascota isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} />
        {selectedPetId && <ModMascota isOpen={isModModalOpen} onClose={() => { setModModalOpen(false); setSelectedPetId(null); }} petId={selectedPetId} />}

        <div className="welcome-banner">
          <div className="welcome-info">
            <h1>¡Hola, {user?.name.split(' ')[0]}! 👋</h1>
            <p>Tus mascotas te esperan</p>
          </div>
        </div>

        <section className="section-mobile">
          <div className="section-title">
            <h2>Mis Mascotas</h2>
          </div>

          {loadingPets ? (
            <div style={{ textAlign: 'center', padding: '20px' }}><IonSpinner name="crescent" /></div>
          ) : (
            <div className="mascotas-scroll">
              {mascotas.map((mascota) => (
                <div key={mascota.id} className="mascota-item">
                  <div className="mascota-photo">
                    <IonAvatar onClick={() => openModMascota(mascota.id)} className="mascota-avatar-large">
                      <img src={mascota.foto} alt={mascota.nombre} />
                    </IonAvatar>
                    <div className="paw-badge">
                      <IonIcon icon={paw} />
                    </div>
                  </div>
                  <h3>{mascota.nombre}</h3>
                  <p className="mascota-meta">{mascota.animal} · {calculateAge(mascota.nacimiento)}</p>
                </div>
              ))}
              
              <div className="mascota-item add-pet">
                <div className="add-pet-circle">
                  <IonIcon icon={add} onClick={() => setAddModalOpen(true)} />
                </div>
                <h3>Agregar</h3>
                <p className="mascota-meta">Nueva mascota</p>
              </div>
            </div>
          )}
        </section>

        <ConsejoMascota consejo={consejo} loading={loadingConsejo} />

        <section className="quick-actions-mobile">
          <div className="action-btn-large" onClick={() => console.log('Buscar perdidos')}>
            <div className="action-icon">
              <IonIcon icon={search} />
            </div>
            <div className="action-text">
              <h4>Mascotas Perdidas</h4>
              <p>Ayuda a encontrarlas</p>
            </div>
          </div>
          
          <div className="action-btn-large" onClick={() => console.log('Foro')}>
            <div className="action-icon">
              <IonIcon icon={chatbubbles} />
            </div>
            <div className="action-text">
              <h4>Foro Comunidad</h4>
              <p>Conecta con otros</p>
            </div>
          </div>

          <div className="action-btn-large" onClick={() => console.log('Veterinarias')}>
            <div className="action-icon">
              <IonIcon icon={locationOutline} />
            </div>
            <div className="action-text">
              <h4>Veterinarias</h4>
              <p>Encuentra cercanas</p>
            </div>
          </div>
        </section>

        <section className="section-mobile">
          <div className="section-title">
            <h2>Últimas Noticias</h2>
          </div>

          <div className="news-feed-mobile">
            {loadingNews && (
              <div style={{ textAlign: 'center', padding: '20px' }}>
                <IonSpinner name="crescent" />
                <p>Cargando noticias...</p>
              </div>
            )}
            {newsError && (
              <div style={{ textAlign: 'center', padding: '20px', color: 'red' }}>
                <p>{newsError}</p>
              </div>
            )}
            {!loadingNews && !newsError && noticias.length === 0 && (
              <div style={{ textAlign: 'center', padding: '20px' }}>
                <p>No hay noticias disponibles en este momento.</p>
              </div>
            )}
            {!loadingNews && !newsError && noticias.map((noticia,index) => (
              <div key={index} className="news-card-mobile" onClick={() => window.open(noticia.link, '_blank')}>
                <div className="news-image">
                  <img src={noticia.imageUrl} alt={noticia.title} />
                  <span className="news-badge">{noticia.source}</span>
                </div>
                <div className="news-body">
                  <h3>{noticia.title}</h3>
                  <p>{noticia.source}</p>
                  <div className="news-meta">
                    <span>
                      <IonIcon icon={time} />
                      {noticia.pubDate && formatDate(noticia.pubDate)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
        
        <div style={{ height: '80px' }}></div>
      </IonContent>

      <IonModal isOpen={showProfileModal} onDidDismiss={() => setShowProfileModal(false)} className="profile-modal">
        <div className="modal-content">
          <div className="modal-header">
            <h2>Mis Conexiones</h2>
            <IonButton fill="clear" onClick={() => setShowProfileModal(false)}>
              <IonIcon icon={close} />
            </IonButton>
          </div>
          
          <div className="profile-content">
            <IonAvatar className="profile-avatar-large">
              <img src={user?.fotouser} alt={user?.name} />
            </IonAvatar>
            <h3>{user?.name}</h3>
            <p className="profile-email">{user?.correo}</p>

            <div className="profile-menu">
              <div className="menu-item" onClick={() => setProfileModalOpen(true)}>
                <IonIcon icon={person} />
                <span>Editar Perfil</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/conversations'); }}>
                <IonIcon icon={chatbubbles} />
                <span>Mis Conversaciones</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/dato'); }}>
                <IonIcon icon={documentText} />
                <span>Datos de Reportes</span>
              </div>
              
              <div className="menu-item" onClick={() => { setShowProfileModal(false); history.push('/app/mascotavirtual'); }}>
                <IonIcon icon={pawOutline} />
                <span>Mi Mascota</span>
              </div>
            </div>

            <IonButton expand="block" className="logout-btn" color="danger" fill="outline" onClick={handleLogout}>
              Cerrar Sesión
            </IonButton>
          </div>
        </div>
      </IonModal>

      <NotificationsModal 
        isOpen={isNotificationsModalOpen} 
        onClose={() => setNotificationsModalOpen(false)} 
      />

    </IonPage>
  );
};

export default HomePage;
