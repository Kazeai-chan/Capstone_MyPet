
import React, { useState, useEffect, useContext } from 'react';
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButton, IonIcon, IonAvatar, IonSpinner, IonBackButton, IonButtons, IonCard, IonCardContent, IonChip } from '@ionic/react';
import { useParams, useHistory } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext } from '../context/UserContext';
import * as QRCode from 'qrcode'; // --- IMPORT a qrcode
import { qrCodeOutline, sendOutline, downloadOutline, alertCircleOutline, calendarOutline, heartOutline, locationOutline, pawOutline, shareOutline } from 'ionicons/icons';
import './CarnetMascota.css';

interface PublicOwnerData {
  uid: string;
  name: string;
  fotouser: string;
  contacto?: string;
}

interface PublicPetData {
  id: string;
  nombre: string;
  raza: string;
  nacimiento: any; 
  animal: string;
  foto: string;
  ownerData: PublicOwnerData;
}

const CarnetMascota = () => {
  const { id: petId } = useParams<{ id: string }>();
  const { user: loggedInUser } = useContext(UserContext);
  const history = useHistory();

  const [publicData, setPublicData] = useState<PublicPetData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState(''); // --- NUEVO estado para el QR

  const publicUrl = `https://instant-vent-423002-f1.web.app/carnet-mascota/${petId}`;

  // --- NUEVO useEffect para generar el QR cuando se muestra ---
  useEffect(() => {
    if (showQr) {
      QRCode.toDataURL(publicUrl, { errorCorrectionLevel: 'H', margin: 1, width: 200 })
        .then(url => setQrCodeDataUrl(url))
        .catch(err => console.error("Error generating display QR:", err));
    }
  }, [showQr, publicUrl]);

  useEffect(() => {
    const fetchPublicPetData = async () => {
      if (!petId) return;
      setIsLoading(true);
      try {
        const publicPetDocRef = doc(firestore, 'mascota_publica', petId);
        const publicPetDocSnap = await getDoc(publicPetDocRef);
        if (publicPetDocSnap.exists()) {
          setPublicData({ id: publicPetDocSnap.id, ...publicPetDocSnap.data() } as PublicPetData);
        } else {
          setPublicData(null);
        }
      } catch (error) {
        console.error("Error fetching public pet data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPublicPetData();
  }, [petId]);

  const calculateAge = (nacimiento: any) => {
    if (!nacimiento) return 'N/A';
    let birthDate: Date;
    if (nacimiento.seconds) {
      birthDate = new Date(nacimiento.seconds * 1000);
    } else if (typeof nacimiento === 'string') {
      birthDate = new Date(nacimiento.replace(/-/g, '/'));
    } else {
      return 'N/A';
    }
    if (isNaN(birthDate.getTime())) return 'N/A';

    const today = new Date();
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    if (months < 0 || (months === 0 && today.getDate() < birthDate.getDate())) {
        years--;
        months = (months + 12) % 12;
    }
    if (years > 0) return `${years} año${years > 1 ? 's' : ''}`;
    if (months > 0) return `${months} mes${months > 1 ? 'es' : ''}`;
    const days = Math.floor((today.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24));
    if (days > 0) return `${days} día${days > 1 ? 's' : ''}`;
    return 'Recién nacido';
  };

  const handleContact = () => {
    if (!publicData) return;
    const chatUrl = `/app/chat/${publicData.ownerData.uid}`;
    if (loggedInUser) {
      history.push(chatUrl);
    } else {
      history.push(`/login?redirect=${encodeURIComponent(chatUrl)}`);
    }
  };

  const handleOwnerProfileClick = () => {
    if (!publicData) return;
    const profileUrl = `/app/perfil/${publicData.ownerData.uid}`;
    if (loggedInUser) {
      history.push(profileUrl);
    } else {
      history.push(`/login?redirect=${encodeURIComponent(profileUrl)}`);
    }
  };

  // --- MODIFICADO: Función de descarga con QR local ---
  const handleDownloadQr = async () => {
    if (!publicData) return;
    setIsDownloading(true);

    const logoUrl = 'https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9';

    try {
      const qrCodeDataUrlForDownload = await QRCode.toDataURL(publicUrl, { 
        errorCorrectionLevel: 'H', 
        margin: 2, 
        scale: 8, // Mayor resolución para descarga
        width: 400 
      });

      const loadImage = (src: string): Promise<HTMLImageElement> => new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
        img.src = src;
      });

      const [logoImage, qrImage] = await Promise.all([
        loadImage(logoUrl),
        loadImage(qrCodeDataUrlForDownload) // Carga el QR desde el data URL
      ]);
      
      const canvas = document.createElement('canvas');
      const padding = 30;
      const logoHeight = 80;
      const spacing = 20;
      const textHeight = 25;
      
      canvas.width = qrImage.width + (padding * 2);
      canvas.height = logoHeight + qrImage.height + textHeight + spacing * 2 + padding;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      ctx.fillStyle = 'white';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const logoWidth = logoImage.width * (logoHeight / logoImage.height);
      ctx.drawImage(logoImage, (canvas.width - logoWidth) / 2, padding, logoWidth, logoHeight);
      ctx.drawImage(qrImage, padding, padding + logoHeight + spacing, qrImage.width, qrImage.height);
      ctx.fillStyle = '#444';
      ctx.font = 'bold 18px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Generado por MyPet', canvas.width / 2, canvas.height - padding + 5);

      const link = document.createElement('a');
      link.href = canvas.toDataURL('image/png');
      link.download = `QR_Carnet_${publicData.nombre.replace(/ /g, '_')}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    } catch (error) {
      console.error("Error creating downloadable QR:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Carnet de ${publicData?.nombre}`,
          text: `Conoce a ${publicData?.nombre}, mi ${publicData?.animal}`,
          url: publicUrl
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    }
  };

  if (isLoading) {
    return (
      <IonPage>
        <IonContent className="ion-text-center">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
            <IonSpinner name="crescent" />
          </div>
        </IonContent>
      </IonPage>
    );
  }

  if (!publicData) {
    return (
      <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Error</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding">
          <p>No se pudo encontrar el carnet de la mascota.</p>
          <IonButton onClick={() => history.goBack()}>Volver</IonButton>
        </IonContent>
      </IonPage>
    );
  }

  const isOwner = loggedInUser?.uid === publicData.ownerData.uid;

  return (
    <IonPage className="carnet-page-mypet">
      <IonHeader className="ion-no-border">
        <IonToolbar className="carnet-header-toolbar">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/" text="" className="back-btn-carnet" />
          </IonButtons>
          <IonTitle className="carnet-title-header">
            Carnet de {publicData.nombre}
          </IonTitle>
          <IonButtons slot="end">
            <IonButton fill="clear" onClick={handleShare}>
              <IonIcon icon={shareOutline} />
            </IonButton>
          </IonButtons>
        </IonToolbar>
      </IonHeader>

      <IonContent fullscreen className="carnet-content-mypet">
        {/* Hero Section Rediseñado */}
        <div className="carnet-hero-mypet">
          <div 
            className="hero-image-mypet" 
            style={{ backgroundImage: `url(${publicData.foto})` }}
          >
            <div className="hero-overlay-mypet"></div>
          </div>
          
          {/* Badge de Animal */}
          <div className="pet-type-badge">
            <IonIcon icon={pawOutline} />
            <span>{publicData.animal}</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="carnet-main-content">
          {/* Pet Avatar y Nombre */}
          <div className="pet-profile-section">
            <div className="pet-avatar-wrapper-mypet">
              <IonAvatar className="carnet-pet-avatar-mypet">
                <img src={publicData.foto} alt={publicData.nombre} />
              </IonAvatar>
              <div className="avatar-decoration">
                <div className="paw-print">🐾</div>
              </div>
            </div>
            
            <h1 className="pet-name-mypet">{publicData.nombre}</h1>
            <IonChip className="breed-chip-mypet">
              <span>{publicData.raza}</span>
            </IonChip>
          </div>

          {/* Información Card */}
          <IonCard className="info-card-mypet">
            <IonCardContent>
              <div className="info-grid-mypet">
                <div className="info-item-mypet">
                  <div className="info-icon-wrapper">
                    <IonIcon icon={pawOutline} />
                  </div>
                  <div className="info-content">
                    <span className="info-label">Tipo</span>
                    <strong className="info-value">{publicData.animal}</strong>
                  </div>
                </div>

                <div className="info-item-mypet">
                  <div className="info-icon-wrapper">
                    <IonIcon icon={calendarOutline} />
                  </div>
                  <div className="info-content">
                    <span className="info-label">Edad</span>
                    <strong className="info-value">{calculateAge(publicData.nacimiento)}</strong>
                  </div>
                </div>

                <div className="info-item-mypet">
                  <div className="info-icon-wrapper">
                    <IonIcon icon={locationOutline} />
                  </div>
                  <div className="info-content">
                    <span className="info-label">Raza</span>
                    <strong className="info-value">{publicData.raza}</strong>
                  </div>
                </div>
              </div>
            </IonCardContent>
          </IonCard>

          {/* Divider con patita */}
          <div className="section-divider-mypet">
            <div className="divider-line-mypet"></div>
            <div className="divider-icon-mypet">🐾</div>
            <div className="divider-line-mypet"></div>
          </div>

          {/* Owner Section Rediseñado */}
          <div className="owner-section-mypet">
            <h2 className="section-title-mypet">
              <IonIcon icon={heartOutline} />
              <span>Dueño Responsable</span>
            </h2>
            
            <div className="owner-card-mypet" onClick={handleOwnerProfileClick}>
              <IonAvatar className="owner-avatar-mypet">
                <img src={publicData.ownerData.fotouser} alt={publicData.ownerData.name} />
              </IonAvatar>
              
              <div className="owner-info-mypet">
                <h3 className="owner-name-mypet">{publicData.ownerData.name}</h3>
                {publicData.ownerData.contacto && (
                  <p className="owner-contact-mypet">
                    <IonIcon icon={alertCircleOutline} />
                    {publicData.ownerData.contacto}
                  </p>
                )}
                <IonChip className="verified-chip">
                  <span>✓ Verificado</span>
                </IonChip>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="carnet-actions-mypet">
            <IonButton 
              expand="block" 
              className="contact-btn-mypet" 
              onClick={handleContact}
              disabled={isOwner}
            >
              <IonIcon icon={sendOutline} slot="start" />
              Contactar al Dueño
            </IonButton>

            {isOwner && (
              <IonButton 
                expand="block" 
                fill="outline" 
                className="qr-btn-mypet" 
                onClick={() => setShowQr(!showQr)}
              >
                <IonIcon icon={qrCodeOutline} slot="start" />
                {showQr ? 'Ocultar QR' : 'Compartir QR'}
              </IonButton>
            )}
          </div>

          {/* QR Section Rediseñada */}
          {showQr && isOwner && (
            <div className="qr-section-mypet">
              <div className="qr-header-mypet">
                <h3>Código QR del Carnet</h3>
                <p>Comparte este código para que otros vean el carnet</p>
              </div>

              <div className="qr-display-mypet">
                <div className="qr-card-mypet">
                  <div className="qr-logo-header">
                    <img 
                      src="https://firebasestorage.googleapis.com/v0/b/instant-vent-423002-f1.appspot.com/o/iconos%2Flogo.png?alt=media&token=9a25f008-06c9-4351-a602-2b44776cb0f9" 
                      alt="MyPet Logo" 
                      className="qr-logo"
                    />
                  </div>
                  
                  <div className="qr-code-wrapper">
                    {qrCodeDataUrl ? (
                      <img src={qrCodeDataUrl} alt="QR Code" className="qr-image-mypet" />
                    ) : (
                      <IonSpinner name="crescent" />
                    )}
                  </div>

                  <div className="qr-pet-info">
                    <IonAvatar className="qr-pet-avatar">
                      <img src={publicData.foto} alt={publicData.nombre} />
                    </IonAvatar>
                    <div>
                      <strong>{publicData.nombre}</strong>
                      <span>{publicData.animal} · {publicData.raza}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="share-options-mypet">
                <div className="share-link-section">
                  <p className="share-label">O comparte este enlace:</p>
                  <div className="link-box-mypet">
                    <span>{publicUrl}</span>
                    <IonButton fill="clear" size="small">
                      Copiar
                    </IonButton>
                  </div>
                </div>

                <IonButton 
                  expand="block" 
                  className="download-qr-btn-mypet"
                  onClick={handleDownloadQr}
                  disabled={isDownloading}
                >
                  {isDownloading ? (
                    <IonSpinner name="crescent" />
                  ) : (
                    <>
                      <IonIcon icon={downloadOutline} slot="start" />
                      Descargar QR
                    </>
                  )}
                </IonButton>
              </div>
            </div>
          )}

          {/* Decorative Elements */}
          <div className="carnet-decoration paw-decoration-1">🐾</div>
          <div className="carnet-decoration paw-decoration-2">🐾</div>
          <div className="carnet-decoration paw-decoration-3">🐾</div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default CarnetMascota;
