
import React, { useState, useEffect, useContext, useRef, useLayoutEffect } from 'react';
import { IonPage, IonHeader, IonToolbar, IonContent, IonFooter, IonInput, IonButton, IonIcon, IonSpinner, IonAvatar, IonBackButton, IonButtons, IonInfiniteScroll, IonInfiniteScrollContent } from '@ionic/react';
import { useParams } from 'react-router-dom';
import { collection, query, onSnapshot, addDoc, serverTimestamp, Timestamp, orderBy, doc, getDoc, where, getDocs, writeBatch, limit, startAfter, DocumentData, updateDoc } from 'firebase/firestore';
import { checkmark, checkmarkDone, ellipsisVertical, send } from 'ionicons/icons';

import { firestore, auth } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './ChatPage.css';

interface Message {
    id: string;
    de: string;
    para: string;
    mensaje: string;
    fecha: Timestamp | null;
    leido: boolean;
    chatId: string;
}

interface UserData {
    id: string;
    nombre: string;
    fotouser: string;
    activeChatWith?: string;
}

const MESSAGES_PER_PAGE = 25;

const ChatPage: React.FC = () => {
    const { userId: otherUserId } = useParams<{ userId: string }>();
    const { user } = useContext<UserContextType>(UserContext);
    
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [otherUser, setOtherUser] = useState<UserData | null>(null);
    const [loading, setLoading] = useState(true);
    const [isFetchingMore, setIsFetchingMore] = useState(false);

    const [lastVisible, setLastVisible] = useState<DocumentData | null>(null);
    const [hasMoreMessages, setHasMoreMessages] = useState(true);

    const contentRef = useRef<HTMLIonContentElement>(null);
    const infiniteScrollRef = useRef<HTMLIonInfiniteScrollElement>(null);
    const justLoadedMore = useRef(false);

    const getChatId = (uid1: string, uid2: string) => [uid1, uid2].sort().join('-');

    useEffect(() => {
        if (!otherUserId) return;
        const fetchOtherUser = async () => {
            const userDoc = await getDoc(doc(firestore, 'usuarios', otherUserId));
            if (userDoc.exists()) {
                setOtherUser({ id: userDoc.id, ...userDoc.data() } as UserData);
            } else {
                console.error("No se encontró al usuario del chat.");
            }
        };
        fetchOtherUser();
    }, [otherUserId]);

    // <-- INICIO DE LA MEJORA: Gestionar el estado de activeChatWith
    useEffect(() => {
        if (!user || !otherUserId) return;

        const userDocRef = doc(firestore, 'usuarios', user.uid);

        const setActiveChat = async () => {
            await updateDoc(userDocRef, { activeChatWith: otherUserId });
        };
        setActiveChat();

        // Limpiar el estado al salir del chat
        return () => {
            const clearActiveChat = async () => {
                // Usamos una comprobación para evitar errores al cerrar sesión
                if (auth.currentUser && auth.currentUser.uid === user.uid) {
                    const userDocSnap = await getDoc(userDocRef);
                    // Solo limpiar si el chat activo era este
                    if (userDocSnap.data()?.activeChatWith === otherUserId) {
                         await updateDoc(userDocRef, { activeChatWith: null });
                    }
                }
            };
            clearActiveChat();
        };
    }, [user, otherUserId]);
    // <-- FIN DE LA MEJORA

    useEffect(() => {
        if (!user || !otherUserId) return;

        setLoading(true);
        setMessages([]); 
        setHasMoreMessages(true); 

        const markNotificationsAsRead = async () => {
            const notifQuery = query(
                collection(firestore, 'notificaciones'),
                where('userId', '==', user.uid),
                where('fromId', '==', otherUserId),
                where('type', '==', 'message'),
                where('read', '==', false)
            );
            const querySnapshot = await getDocs(notifQuery);
            if (!querySnapshot.empty) {
                const batch = writeBatch(firestore);
                querySnapshot.forEach(doc => {
                    batch.update(doc.ref, { read: true });
                });
                await batch.commit();
            }
        };
        markNotificationsAsRead();

        const chatId = getChatId(user.uid, otherUserId);
        const q = query(
            collection(firestore, 'mensajes'),
            where('chatId', '==', chatId),
            orderBy('fecha', 'desc'),
            limit(MESSAGES_PER_PAGE)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
            setMessages(msgs);

            const lastDoc = snapshot.docs[snapshot.docs.length - 1];
            setLastVisible(lastDoc);
            
            setHasMoreMessages(snapshot.docs.length === MESSAGES_PER_PAGE);
            setLoading(false);
        }, (error) => {
            console.error("Error al escuchar mensajes: ", error);
            setLoading(false);
        });

        return () => unsubscribe();
    }, [user, otherUserId]);

    useLayoutEffect(() => {
        if (justLoadedMore.current) {
            justLoadedMore.current = false;
            return;
        }

        setTimeout(() => {
            contentRef.current?.scrollToBottom(0);
        }, 50);

    }, [messages]);

    const loadMoreMessages = async () => {
        if (isFetchingMore || !hasMoreMessages || !lastVisible || !user || !otherUserId) {
            infiniteScrollRef.current?.complete();
            return;
        }
        
        justLoadedMore.current = true;
        setIsFetchingMore(true);

        const chatId = getChatId(user.uid, otherUserId);

        const q = query(
            collection(firestore, 'mensajes'),
            where('chatId', '==', chatId),
            orderBy('fecha', 'desc'),
            startAfter(lastVisible),
            limit(MESSAGES_PER_PAGE)
        );

        const snapshot = await getDocs(q);

        if (snapshot.empty) {
            setHasMoreMessages(false);
        } else {
            const newMsgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
            setMessages(prev => [...prev, ...newMsgs]);

            const lastDoc = snapshot.docs[snapshot.docs.length - 1];
            setLastVisible(lastDoc);
            setHasMoreMessages(snapshot.docs.length === MESSAGES_PER_PAGE);
        }

        setIsFetchingMore(false);
        infiniteScrollRef.current?.complete();
    };

    const handleSendMessage = async () => {
        if (newMessage.trim() === '' || !user || !otherUser) return;

        const tempMessage = newMessage;
        setNewMessage('');
        
        const chatId = getChatId(user.uid, otherUserId);

        try {
            await addDoc(collection(firestore, 'mensajes'), {
                chatId: chatId,
                de: user.uid,
                para: otherUserId,
                mensaje: tempMessage,
                fecha: serverTimestamp(),
                leido: false
            });

            const otherUserDoc = await getDoc(doc(firestore, 'usuarios', otherUser.id));
            const otherUserData = otherUserDoc.data() as UserData;

            if (otherUserData?.activeChatWith !== user.uid) {
                const notifQuery = query(
                    collection(firestore, 'notificaciones'),
                    where('userId', '==', otherUserId),
                    where('fromId', '==', user.uid),
                    where('type', '==', 'message'),
                    where('read', '==', false)
                );
                const existingNotifs = await getDocs(notifQuery);

                if (existingNotifs.empty) {
                    await addDoc(collection(firestore, 'notificaciones'), {
                        userId: otherUserId,
                        fromId: user.uid,
                        type: 'message',
                        title: `Nuevo mensaje de ${user.name}`,
                        body: tempMessage,
                        createdAt: serverTimestamp(),
                        read: false,
                        icon: '💬',
                        link: `/chat/${user.uid}`
                    });
                }
            }
        } catch (error) {
            console.error("Error al enviar mensaje:", error);
            setNewMessage(tempMessage);
        }
    };

    useEffect(() => {
        if (!user || !otherUserId || messages.length === 0) return;
        const markMessagesAsRead = async () => {
            const q = query(
                collection(firestore, 'mensajes'),
                where('para', '==', user.uid),
                where('de', '==', otherUserId),
                where('leido', '==', false)
            );

            const querySnapshot = await getDocs(q);
            if (!querySnapshot.empty) {
                const batch = writeBatch(firestore);
                querySnapshot.forEach((document) => {
                    batch.update(doc(firestore, 'mensajes', document.id), { leido: true });
                });
                await batch.commit();
            }
        };
        markMessagesAsRead();
    }, [messages, user, otherUserId]);

    const formatTime = (timestamp: Timestamp | null) => {
        if (!timestamp) return '';
        return timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
        <IonPage>
            <IonHeader className="ion-no-border">
                <IonToolbar className="chat-header-toolbar">
                    <IonButtons slot="start">
                        <IonBackButton defaultHref="/app/conversations" className="chat-back-button" text="" />
                    </IonButtons>
                    {otherUser ? (
                        <div className="chat-header-content">
                            <IonAvatar className="chat-header-avatar">
                                <img src={otherUser.fotouser} alt={otherUser.nombre} />
                            </IonAvatar>
                            <div className="chat-header-info">
                                <h3>{otherUser.nombre}</h3>
                            </div>
                        </div>
                    ) : <IonSpinner name="dots" />}
                    <IonButtons slot="end">
                        <IonButton fill="clear" className="chat-options-btn"><IonIcon icon={ellipsisVertical} /></IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>

            <IonContent ref={contentRef} className="chat-content-modern">
                <IonInfiniteScroll
                    ref={infiniteScrollRef}
                    position="top"
                    onIonInfinite={loadMoreMessages}
                    disabled={!hasMoreMessages || loading}
                >
                    <IonInfiniteScrollContent loadingSpinner="crescent" />
                </IonInfiniteScroll>

                {loading && messages.length === 0 ? (
                    <div className="loading-center-chat"><IonSpinner name="crescent" /></div>
                ) : (
                    <div className="messages-container">
                        {messages.map((msg) => {
                            const isSent = msg.de === user?.uid;
                            return (
                                <div key={msg.id} className={`message-wrapper-modern ${isSent ? 'sent' : 'received'}`}>
                                    {!isSent && otherUser && <IonAvatar className="message-avatar"><img src={otherUser.fotouser} alt="avatar" /></IonAvatar>}
                                    <div className={`message-bubble-modern ${isSent ? 'sent-bubble' : 'received-bubble'}`}>
                                        <p className="message-text">{msg.mensaje}</p>
                                        <div className="message-footer">
                                            <span className="message-time">{formatTime(msg.fecha)}</span>
                                            {isSent && <IonIcon icon={msg.leido ? checkmarkDone : checkmark} className={`read-status ${msg.leido ? 'read' : 'sent'}`} />}
                                        </div>
                                    </div>
                                    {isSent && user && <IonAvatar className="message-avatar"><img src={user.fotouser} alt="avatar" /></IonAvatar>}
                                </div>
                            );
                        })}
                    </div>
                )}
            </IonContent>

            <IonFooter className="ion-no-border">
                <IonToolbar className="chat-footer-toolbar-modern">
                    <div className="chat-input-container">
                        <IonInput
                            value={newMessage}
                            onIonInput={(e) => setNewMessage(e.detail.value!)}
                            placeholder="Escribe un mensaje..."
                            className="chat-input-modern"
                            onKeyPress={(e) => { if (e.key === 'Enter') handleSendMessage(); }}
                        />
                        <IonButton fill="clear" onClick={handleSendMessage} className="send-button-modern" disabled={!newMessage.trim()}>
                            <IonIcon icon={send} />
                        </IonButton>
                    </div>
                </IonToolbar>
            </IonFooter>
        </IonPage>
    );
};

export default ChatPage;
