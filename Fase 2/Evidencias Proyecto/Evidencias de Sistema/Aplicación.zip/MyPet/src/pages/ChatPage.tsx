
import React, { useState, useEffect, useContext, useRef } from 'react';
import { IonPage, IonHeader, IonToolbar, IonContent, IonFooter, IonInput, IonButton, IonIcon, IonSpinner, IonAvatar, IonBackButton, IonButtons } from '@ionic/react';
import { useParams } from 'react-router-dom';
import { collection, query, onSnapshot, addDoc, serverTimestamp, Timestamp, orderBy, doc, getDoc, updateDoc, where } from 'firebase/firestore';
import { checkmark, checkmarkDone, ellipsisVertical, send } from 'ionicons/icons';

import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import './ChatPage.css';

// Interfaces para nuestros datos
interface Message {
    id: string;
    de: string;
    para: string;
    mensaje: string;
    fecha: Timestamp | null;
    leido: boolean;
}

interface UserData {
    id: string;
    nombre: string;
    fotouser: string;
}

const ChatPage: React.FC = () => {
    const { userId: otherUserId } = useParams<{ userId: string }>();
    const { user } = useContext<UserContextType>(UserContext);
    
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState('');
    const [otherUser, setOtherUser] = useState<UserData | null>(null);
    const [loading, setLoading] = useState(true);

    const contentRef = useRef<HTMLIonContentElement>(null);

    // 1. Obtener datos del otro usuario
    useEffect(() => {
        if (!otherUserId) return;
        const fetchOtherUser = async () => {
            const userDoc = await getDoc(doc(firestore, 'usuarios', otherUserId));
            if (userDoc.exists()) {
                setOtherUser({ id: userDoc.id, ...userDoc.data() } as UserData);
            } else {
                console.error("No se encontró al usuario del chat.");
            }
        };
        fetchOtherUser();
    }, [otherUserId]);

    // 2. Cargar mensajes en tiempo real
    useEffect(() => {
        if (!user || !otherUser) return;

        setLoading(true);

        const q = query(
            collection(firestore, 'mensajes'),
            orderBy('fecha', 'asc')
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const msgs = snapshot.docs
                .map(doc => ({ id: doc.id, ...doc.data() } as Message))
                .filter(msg => 
                    (msg.de === user.uid && msg.para === otherUserId) ||
                    (msg.de === otherUserId && msg.para === user.uid)
                );
            
            setMessages(msgs);
            setLoading(false);
            scrollToBottom();
        });

        return () => unsubscribe();
    }, [user, otherUser, otherUserId]);

    // 3. Marcar mensajes como leídos
    useEffect(() => {
        if (!user || !otherUserId) return;

        const q = query(
            collection(firestore, 'mensajes'),
            where('para', '==', user.uid),
            where('de', '==', otherUserId),
            where('leido', '==', false)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            snapshot.docs.forEach(async (document) => {
                await updateDoc(doc(firestore, 'mensajes', document.id), {
                    leido: true
                });
            });
        });

        return () => unsubscribe();
    }, [user, otherUserId]);

    // 4. Scroll automático al final
    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const scrollToBottom = () => {
        contentRef.current?.scrollToBottom(500);
    };

    // 5. Enviar un nuevo mensaje
    const handleSendMessage = async () => {
        if (newMessage.trim() === '' || !user) return;

        try {
            await addDoc(collection(firestore, 'mensajes'), {
                de: user.uid,
                para: otherUserId,
                mensaje: newMessage,
                fecha: serverTimestamp(),
                leido: false
            });
            setNewMessage('');
            scrollToBottom();
        } catch (error) {
            console.error("Error al enviar mensaje:", error);
        }
    };

    const formatTime = (timestamp: Timestamp | null) => {
        if (!timestamp) return ''; // Si la fecha es null, retorna un string vacío

        const date = timestamp.toDate();
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        const diffDays = Math.floor(diff / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else if (diffDays === 1) {
            return 'Ayer';
        } else {
            return date.toLocaleDateString();
        }
    };

    return (
        <IonPage>
            {/* Header */}
            <IonHeader className="ion-no-border">
                <IonToolbar className="chat-header-toolbar">
                    <IonButtons slot="start">
                    <IonBackButton 
                        defaultHref="/conversations" 
                        className="chat-back-button"
                        text=""
                    />
                    </IonButtons>
                    
                    {otherUser ? (
                    <div className="chat-header-content">
                        <IonAvatar className="chat-header-avatar">
                        <img src={otherUser.fotouser} alt={otherUser.nombre} />
                        </IonAvatar>
                        <div className="chat-header-info">
                        <h3>{otherUser.nombre}</h3>
                        <span className="online-status">En línea</span>
                        </div>
                    </div>
                    ) : (
                    <IonSpinner name="dots" />
                    )}
        
                    <IonButtons slot="end">
                    <IonButton fill="clear" className="chat-options-btn">
                        <IonIcon icon={ellipsisVertical} />
                    </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>

            {/* Content */}
            <IonContent ref={contentRef} className="chat-content-modern">
            {loading ? (
                <div className="loading-center-chat">
                <IonSpinner name="crescent" className="loading-spinner-chat" />
                <p>Cargando mensajes...</p>
                </div>
            ) : (
                <div className="messages-container">
                {messages.map((msg) => {
                    const isSent = msg.de === user?.uid;
                    const sender = isSent ? user : otherUser;
    
                    return (
                    <div key={msg.id} className={`message-wrapper-modern ${isSent ? 'sent' : 'received'}`}>
                        {!isSent && (
                        <IonAvatar className="message-avatar">
                            <img src={sender?.fotouser || 'https://via.placeholder.com/150'} alt="avatar" />
                        </IonAvatar>
                        )}
                        
                        <div className={`message-bubble-modern ${isSent ? 'sent-bubble' : 'received-bubble'}`}>
                        <p className="message-text">{msg.mensaje}</p>
                        <div className="message-footer">
                            <span className="message-time">{formatTime(msg.fecha)}</span>
                            {isSent && (
                            <IonIcon 
                                icon={msg.leido ? checkmarkDone : checkmark} 
                                className={`read-status ${msg.leido ? 'read' : 'sent'}`}
                            />
                            )}
                        </div>
                        </div>
    
                        {isSent && (
                        <IonAvatar className="message-avatar">
                            <img src={sender?.fotouser || 'https://via.placeholder.com/150'} alt="avatar" />
                        </IonAvatar>
                        )}
                    </div>
                    );
                })}
                </div>
            )}
            </IonContent>
            {/* Footer */}
            <IonFooter className="ion-no-border">
                <IonToolbar className="chat-footer-toolbar-modern">
                    <div className="chat-input-container">
                    <IonInput
                        value={newMessage}
                        onIonChange={(e) => setNewMessage(e.detail.value!)}
                        placeholder="Escribe un mensaje..."
                        className="chat-input-modern"
                        onKeyPress={(e) => { 
                        if (e.key === 'Enter') handleSendMessage(); 
                        }}
                    />
                    <IonButton 
                        fill="clear" 
                        onClick={handleSendMessage} 
                        className="send-button-modern"
                        disabled={!newMessage.trim()}
                    >
                        <IonIcon icon={send} />
                    </IonButton>
                    </div>
                </IonToolbar>
            </IonFooter>
        </IonPage>
    );
};

export default ChatPage;
