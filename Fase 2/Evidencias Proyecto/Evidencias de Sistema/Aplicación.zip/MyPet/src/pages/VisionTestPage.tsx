
import React, { useState, useRef } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonImg,
  IonSpinner,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonIcon,
  IonItem,
  IonLabel,
  IonText,
  IonList,
} from '@ionic/react';
import { imageOutline, pawOutline, cameraOutline } from 'ionicons/icons';
import { getFunctions, httpsCallable } from 'firebase/functions';

// Base analysis fields
interface PetAnalysis {
  animalType: string;
  breed: string;
  color: string;
  eyeColor: string;
  size: string;
  fur: string;
  error?: string;
}

// Corrected interface for the camera response
interface CameraPetAnalysis {
  petDetected: boolean;
  activity: string;
  imageUrl: string;
  analysis: PetAnalysis; // Nested analysis object
}

const VisionTestPage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [base64Image, setBase64Image] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<PetAnalysis | null>(null);
  const [cameraAnalysisResult, setCameraAnalysisResult] = useState<CameraPetAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const originalBase64 = e.target?.result as string;
      setSelectedImage(originalBase64); 
      setAnalysisResult(null);
      setCameraAnalysisResult(null);
      setError(null);

      const img = document.createElement('img');
      img.onload = () => {
        const MAX_DIMENSION = 384;
        let { width, height } = img;

        if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
          if (width > height) {
            height = Math.round((height * MAX_DIMENSION) / width);
            width = MAX_DIMENSION;
          } else {
            width = Math.round((width * MAX_DIMENSION) / height);
            height = MAX_DIMENSION;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);

        const resizedBase64 = canvas.toDataURL('image/jpeg', 0.9);
        setBase64Image(resizedBase64.split(',')[1]);
      };
      img.src = originalBase64;
    };
    reader.onerror = () => {
      setError('Falló la lectura del archivo.');
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyzeClick = async () => {
    if (!base64Image) {
      setError('Por favor, selecciona y espera a que la imagen se procese.');
      return;
    }

    setLoading(true);
    setError(null);
    setAnalysisResult(null);
    setCameraAnalysisResult(null);

    try {
      const response = await fetch('https://us-central1-instant-vent-423002-f1.cloudfunctions.net/analyzePetImage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Image }),
      });

      if (!response.ok) {
        const errorBody = await response.json();
        throw new Error(errorBody.details || errorBody.error || `Error HTTP: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.analysis) {
        if (data.analysis.error) {
          throw new Error(`Error en el análisis: ${data.analysis.error}`);
        }
        setAnalysisResult(data.analysis);
      } else {
        throw new Error('La respuesta del análisis no tuvo el formato esperado.');
      }

    } catch (err: any) {
      setError(err.message || 'Ocurrió un error desconocido.');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestCameraPhoto = async () => {
    setLoading(true);
    setError(null);
    setAnalysisResult(null);
    setSelectedImage(null);
    setCameraAnalysisResult(null);

    try {
      const functions = getFunctions();
      const requestPetCameraPhoto = httpsCallable(functions, 'requestPetCameraPhoto');
      const result = await requestPetCameraPhoto();
      const data = result.data as CameraPetAnalysis;
      setCameraAnalysisResult(data);
    } catch (err: any) {
      setError(err.message || 'Ocurrió un error desconocido al solicitar la foto de la cámara.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectImageClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Análisis con IA de Mascotas</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonCard>
          <IonCardHeader>
            <IonCardTitle>Sube o Solicita una Foto</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              style={{ display: 'none' }}
              ref={fileInputRef}
              id="file-upload"
            />
            <IonButton expand="block" fill="outline" onClick={handleSelectImageClick}>
              <IonIcon slot="start" icon={imageOutline} />
              Seleccionar Imagen
            </IonButton>

            <IonButton
              expand="block"
              onClick={handleRequestCameraPhoto}
              disabled={loading}
              style={{ marginTop: '10px' }}
            >
              <IonIcon slot="start" icon={cameraOutline} />
              Solicitar Foto de Cámara
            </IonButton>

            {selectedImage && (
              <div style={{ marginTop: '20px', textAlign: 'center' }}>
                <IonImg src={selectedImage} style={{ maxWidth: '300px', margin: '0 auto', borderRadius: '8px' }} />
              </div>
            )}

            <IonButton
              expand="block"
              onClick={handleAnalyzeClick}
              disabled={!selectedImage || loading}
              style={{ marginTop: '20px' }}
            >
              {loading && !cameraAnalysisResult ? <IonSpinner /> : 'Analizar Mascota'}
            </IonButton>

            {error && <IonText color="danger"><p style={{ textAlign: 'center', marginTop: '10px' }}>Error: {error}</p></IonText>}
          </IonCardContent>
        </IonCard>

        {analysisResult && (
          <IonCard style={{ marginTop: '20px' }}>
            <IonCardHeader>
              <IonCardTitle>
                <IonIcon icon={pawOutline} slot="start" />
                Datos de la Mascota
              </IonCardTitle>
            </IonCardHeader>
            <IonCardContent>
              <IonList lines="full">
                <IonItem>
                  <IonLabel><strong>Tipo de Animal</strong></IonLabel>
                  <IonText slot="end">{analysisResult.animalType}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Raza</strong></IonLabel>
                  <IonText slot="end">{analysisResult.breed}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Color de Pelaje</strong></IonLabel>
                  <IonText slot="end">{analysisResult.color}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Color de Ojos</strong></IonLabel>
                  <IonText slot="end">{analysisResult.eyeColor}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Tamaño</strong></IonLabel>
                  <IonText slot="end">{analysisResult.size}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Tipo de Pelaje</strong></IonLabel>
                  <IonText slot="end">{analysisResult.fur}</IonText>
                </IonItem>
              </IonList>
            </IonCardContent>
          </IonCard>
        )}

        {cameraAnalysisResult && (
          <IonCard style={{ marginTop: '20px' }}>
            <IonCardHeader>
              <IonCardTitle>
                <IonIcon icon={cameraOutline} slot="start" />
                Análisis de la Cámara
              </IonCardTitle>
            </IonCardHeader>
            <IonCardContent>
              <div style={{ textAlign: 'center', marginBottom: '15px' }}>
                <IonImg src={cameraAnalysisResult.imageUrl} style={{ maxWidth: '300px', margin: '0 auto', borderRadius: '8px' }} />
              </div>
              <IonList lines="full">
                <IonItem>
                  <IonLabel><strong>Mascota Detectada</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.petDetected ? 'Sí' : 'No'}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Actividad</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.activity}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Tipo de Animal</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.animalType}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Raza</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.breed}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Color de Pelaje</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.color}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Color de Ojos</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.eyeColor}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Tamaño</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.size}</IonText>
                </IonItem>
                <IonItem>
                  <IonLabel><strong>Tipo de Pelaje</strong></IonLabel>
                  <IonText slot="end">{cameraAnalysisResult.analysis.fur}</IonText>
                </IonItem>
              </IonList>
            </IonCardContent>
          </IonCard>
        )}
      </IonContent>
    </IonPage>
  );
};

export default VisionTestPage;
