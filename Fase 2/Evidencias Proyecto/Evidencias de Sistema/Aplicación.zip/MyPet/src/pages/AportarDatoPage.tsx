import React, { useState, useEffect, useContext } from 'react';
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonSpinner,
  IonAccordion,
  IonAccordionGroup,
  IonAvatar,
  IonIcon,
  IonBadge,
  IonChip,
  IonItem,
  IonLabel,
  IonButtons,
  IonBackButton
} from '@ionic/react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { firestore } from '../firebase';
import { UserContext, UserContextType } from '../context/UserContext';
import '../pages/AportarDatoPage.css';
import { calendarOutline, informationCircleOutline, pawOutline, personOutline, timeOutline } from 'ionicons/icons';

// Interfaces adaptadas para usar el objeto Date estándar
interface Pista {
  id: string;
  idmarker: string;
  fecha: Date; // Usamos Date en lugar de un string o Timestamp
  nombreUsuario: string;
  pista: string;
}

interface Marcador {
  id: string;
  fecha: Date; // Usamos Date
  foto?: string;
  tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
}

interface GroupedData {
  [idmarker: string]: {
    fecha: Date; // Usamos Date
    foto?: string;
    tipo_r: 'Mascota Perdida' | 'Mascota Encontrada';
    pistas: Pista[];
  };
}

const AportarDatoPage: React.FC = () => {
  const [groupedData, setGroupedData] = useState<GroupedData>({});
  const [loading, setLoading] = useState(true);
  const { user } = useContext<UserContextType>(UserContext);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);

    const markersQuery = query(
      collection(firestore, 'marcadores'),
      where('iduser', '==', user.uid),
      where('tipo', '==', 'mascota')
    );

    const unsubscribeMarkers = onSnapshot(markersQuery, (markerSnapshot) => {
      // Convertimos el string de fecha a un objeto Date
      const markers = markerSnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          fecha: new Date(data.fecha), // Conversión de String a Date
        } as Marcador;
      });

      const markerIds = markers.map(m => m.id);

      if (markerIds.length === 0) {
        setGroupedData({});
        setLoading(false);
        return;
      }

      const newGroupedData: GroupedData = {};
      markers.forEach(marker => {
        newGroupedData[marker.id] = {
          fecha: marker.fecha,
          foto: marker.foto,
          tipo_r: marker.tipo_r,
          pistas: []
        };
      });

      const pistasQuery = query(collection(firestore, 'pistas'), where('idmarker', 'in', markerIds));
      
      const unsubscribePistas = onSnapshot(pistasQuery, (pistaSnapshot) => {
        const finalGroups = { ...newGroupedData };

        Object.keys(finalGroups).forEach(markerId => {
            finalGroups[markerId].pistas = [];
        });

        pistaSnapshot.docs.forEach(doc => {
          const data = doc.data();
          // Conversión de String a Date para las pistas
          const pista = {
            ...data,
            id: doc.id,
            fecha: new Date(data.fecha),
          } as Pista;

          if (finalGroups[pista.idmarker]) {
            finalGroups[pista.idmarker].pistas.push(pista);
          }
        });

        for (const markerId in finalGroups) {
            finalGroups[markerId].pistas.sort((a, b) => b.fecha.getTime() - a.fecha.getTime());
        }

        setGroupedData(finalGroups);
        setLoading(false);
      });

      return () => unsubscribePistas();

    }, (error) => {
      console.error("Error al obtener los reportes (marcadores):", error);
      setLoading(false);
    });

    return () => unsubscribeMarkers();
  }, [user]);

  const formatDate = (date: Date): string => {
    if (!date || !(date instanceof Date) || isNaN(date.getTime())) return 'Fecha inválida';

    try {
      return date.toLocaleDateString('es-ES', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
    } catch {
      return 'Fecha con formato inválido';
    }
  };

  const getTimeAgo = (date: Date): string => {
    if (!date || !(date instanceof Date) || isNaN(date.getTime())) return 'fecha inválida';

    try {
        const now = new Date();
        const diffTime = now.getTime() - date.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) return 'Próximamente';
        if (diffDays === 0) return 'Hoy';
        if (diffDays === 1) return 'Ayer';
        if (diffDays < 7) return `Hace ${diffDays} días`;
        
        const diffWeeks = Math.floor(diffDays / 7);
        if (diffWeeks < 4) return `Hace ${diffWeeks} semana${diffWeeks > 1 ? 's' : ''}`;

        return formatDate(date);
    } catch {
        return 'fecha inválida';
    }
  };

  return (
    <IonPage>
      <IonHeader className="ion-no-border">
        <IonToolbar className="datos-toolbar">
          <IonButtons slot="start">
            <IonBackButton defaultHref="/perfil" text="" />
          </IonButtons>
          <div className="datos-header-title-wrapper">
            <IonIcon icon={informationCircleOutline} className="header-icon-datos" />
            <IonTitle className="datos-title">Datos Recibidos</IonTitle>
          </div>
        </IonToolbar>
      </IonHeader>

      <IonContent className="datos-content" fullscreen>
        {loading ? (
          <div className="loading-state">
            <IonSpinner name="crescent" className="loading-spinner-datos" />
            <p>Cargando reportes...</p>
          </div>
        ) : Object.keys(groupedData).length === 0 ? (
          <div className="empty-state-datos">
            <div className="empty-icon-circle">
              <IonIcon icon={pawOutline} className="empty-icon-datos" />
            </div>
            <h3>No hay reportes activos</h3>
            <p>No tienes reportes de mascotas perdidas en este momento.</p>
          </div>
        ) : (
          <div className="reportes-container">
            <div className="reportes-stats">
              <IonChip className="stats-chip">
                <IonIcon icon={pawOutline} />
                <IonLabel>{Object.keys(groupedData).length} Reportes</IonLabel>
              </IonChip>
            </div>

            <IonAccordionGroup className="datos-accordion-modern">
              {Object.entries(groupedData).map(([idmarker, groupData]) => (
                <IonAccordion key={idmarker} value={idmarker} className="reporte-accordion">
                  <IonItem slot="header" className="accordion-header-modern" lines="none">
                    <IonAvatar slot="start" className="reporte-avatar-modern">
                      <img src={groupData.foto} alt="Mascota" />
                    </IonAvatar>
                    
                    <IonLabel className="accordion-label-modern">
                      <h3>{groupData.tipo_r}</h3>
                      <div className="accordion-meta">
                        <span className="time-ago">
                          <IonIcon icon={timeOutline} />
                          {getTimeAgo(groupData.fecha)}
                        </span>
                        <IonBadge className={`pistas-badge ${groupData.pistas.length > 0 ? 'has-data' : 'no-data'}`}>
                          {groupData.pistas.length} {groupData.pistas.length === 1 ? 'dato' : 'datos'}
                        </IonBadge>
                      </div>
                    </IonLabel>
                  </IonItem>

                  <div className="accordion-content-modern" slot="content">
                    {groupData.pistas.length === 0 ? (
                      <div className="no-pistas-message">
                        <IonIcon icon={informationCircleOutline} />
                        <p>Aún no has recibido datos para este reporte.</p>
                      </div>
                    ) : (
                      <div className="pistas-list">
                        {groupData.pistas.map((pista) => (
                          <div key={pista.id} className="pista-card">
                            <div className="pista-header">
                              <div className="pista-user">
                                <IonIcon icon={personOutline} className="user-icon-dato" />
                                <span className="user-name-dato">{pista.nombreUsuario}</span>
                              </div>
                              <span className="pista-date">
                                <IonIcon icon={calendarOutline} />
                                {formatDate(pista.fecha)}
                              </span>
                            </div>
                            <div className="pista-content">
                              <p>{pista.pista}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </IonAccordion>
              ))}
            </IonAccordionGroup>
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default AportarDatoPage;
