
import React, { createContext, useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, firestore } from '../firebase';

export interface User {
  uid: string;
  name: string;
  correo: string;
  fotouser: string;
  fechainicio: any;
  puntos: number;
  direccion?: string;
  ciudad?: string;
  lat?: number;
  lng?: number;
  alertaMascotas?: boolean;
  // New fields for user profile
  descripcion: string;
  portada: string;
}

export interface UserContextType {
  user: User | null;
  loading: boolean;
  refreshUser: () => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

export const UserContext = createContext<UserContextType>({ 
  user: null, 
  loading: true, 
  refreshUser: async () => {},
  loginWithGoogle: async () => {},
  logout: async () => {},
});

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    const currentUser = auth.currentUser;
    if (currentUser) {
      setLoading(true);
      try {
        const userDocRef = doc(firestore, 'usuarios', currentUser.uid);
        const userDocSnap = await getDoc(userDocRef);
        if (userDocSnap.exists()) {
          setUser({ uid: currentUser.uid, ...userDocSnap.data() } as User);
        }
      } catch (error) {
        console.error("Error refreshing user:", error);
      } finally {
        setLoading(false);
      }
    }
  }, []);

  const loginWithGoogle = useCallback(async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      window.location.href = '/home';
    } catch (error) { // Si el usuario cierra el popup, por ejemplo
      console.error("Error during Google login popup: ", error);
      setLoading(false); 
    }
  }, []);

  const logout = useCallback(async () => {
    await auth.signOut();
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          localStorage.setItem('user_email', firebaseUser.email || '');
          const userDocRef = doc(firestore, 'usuarios', firebaseUser.uid);
          let userDocSnap = await getDoc(userDocRef);

          if (!userDocSnap.exists()) {
            const newUser: Omit<User, 'uid'> = {
              name: firebaseUser.displayName || 'Usuario',
              correo: firebaseUser.email || '',
              fotouser: firebaseUser.photoURL || '',
              fechainicio: serverTimestamp(),
              puntos: 0,
              direccion: '',
              ciudad: '',
              alertaMascotas: false,
              // Default values for new fields
              descripcion: '¡Hola! Soy nuevo en MyPet.',
              portada: 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=1200',
            };
            await setDoc(userDocRef, newUser);
            userDocSnap = await getDoc(userDocRef);
          }

          if (userDocSnap.exists()) {
            setUser({ uid: firebaseUser.uid, ...userDocSnap.data() } as User);
          } else {
             console.error("Fatal: Could not create or find user document after login.");
          }
        } catch (error) {
          console.error("Error processing auth state change:", error);
        } finally {
          setLoading(false);
        }
      } else {
        localStorage.removeItem('user_email');
        setUser(null);
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const value = { user, loading, refreshUser, loginWithGoogle, logout };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};
