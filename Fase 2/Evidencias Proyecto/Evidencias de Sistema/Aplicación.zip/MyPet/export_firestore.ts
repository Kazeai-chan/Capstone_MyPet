// export_firestore.js
import admin from "firebase-admin";
import { writeFileSync, readFileSync } from "fs";

// Lee y parsea el archivo JSON de la cuenta de servicio
const serviceAccount = JSON.parse(
  readFileSync("./serviceAccountKey.json", "utf8")
);
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

async function exportAllCollections() {
  // Usamos listCollections() del SDK de Admin
  const collections = await db.listCollections();
  let data: { [key: string]: any } = {};

  for (const col of collections) {
    const snapshot = await col.get();
    data[col.id] = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
  }

  writeFileSync("firestore_export.json", JSON.stringify(data, null, 2));
  console.log("✅ Archivo firestore_export.json generado correctamente.");
}

exportAllCollections();
